
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'sx126x_gfsk_long_pkt' 
 * Target:  'RX Fixed Length' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32l4xx.h"

/*  Keil::Device:Startup:1.3.1 */
#define RTE_DEVICE_STARTUP_STM32L4XX    /* Device Startup for STM32L4 */


#endif /* RTE_COMPONENTS_H */
