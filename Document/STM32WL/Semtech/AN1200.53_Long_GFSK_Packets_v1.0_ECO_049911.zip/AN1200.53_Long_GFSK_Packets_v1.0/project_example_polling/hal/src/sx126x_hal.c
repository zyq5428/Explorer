#include "sx126x_bsp.h"
#include "spi.h"
#include "stm32l4xx_ll_rcc.h"
#include "stm32l4xx_ll_utils.h"

sx126x_bsp_status_t sx126x_bsp_write( const void* context, const uint8_t* command, const uint16_t command_length,
                                      const uint8_t* data, const uint16_t data_length )
{
    unsigned int tx_i  = 0;
    spi_t*       radio = ( spi_t* ) context;

    while( LL_GPIO_IsInputPinSet( radio->busy_port, radio->busy_pin ) )
        ;

    LL_GPIO_ResetOutputPin( radio->nss_port, radio->nss_pin );

    // Always keep the FIFO full
    while( tx_i < command_length + data_length )
    {
        if( LL_SPI_IsActiveFlag_TXE( radio->spi ) )
        {
            uint8_t d = ( tx_i < command_length ) ? command[tx_i] : data[tx_i - command_length];
            LL_SPI_TransmitData8( radio->spi, d );
            tx_i++;
        }
    }

    // Wait until done
    while( LL_SPI_GetTxFIFOLevel( radio->spi ) != LL_SPI_TX_FIFO_EMPTY )
        ;
    while( LL_SPI_IsActiveFlag_BSY( radio->spi ) )
        ;
    while( LL_SPI_GetRxFIFOLevel( radio->spi ) != LL_SPI_TX_FIFO_EMPTY )
    {
        LL_SPI_ReceiveData8( radio->spi );
    }

    LL_GPIO_SetOutputPin( radio->nss_port, radio->nss_pin );

    return SX126X_BSP_STATUS_OK;
}

sx126x_bsp_status_t sx126x_bsp_read( const void* context, const uint8_t* command, const uint16_t command_length,
                                     uint8_t* data, const uint16_t data_length )
{
    spi_t*           radio = ( spi_t* ) context;
    unsigned int     rx_i  = 0;
    unsigned int     tx_i  = 0;
    volatile uint8_t dummy;

    while( LL_GPIO_IsInputPinSet( radio->busy_port, radio->busy_pin ) )
        ;

    LL_GPIO_ResetOutputPin( radio->nss_port, radio->nss_pin );

    // Always keep the FIFO full
    while( rx_i < command_length + data_length )
    {
        if( ( LL_SPI_IsActiveFlag_TXE( radio->spi ) ) && ( tx_i < command_length + data_length ) )
        {
            uint8_t d = tx_i < command_length ? command[tx_i] : 0;
            LL_SPI_TransmitData8( radio->spi, d );
            tx_i++;
        }
        if( LL_SPI_IsActiveFlag_RXNE( radio->spi ) )
        {
            uint8_t d = LL_SPI_ReceiveData8( radio->spi );
            if( rx_i >= command_length ) data[rx_i - command_length] = d;
            rx_i++;
        }
    }

    LL_GPIO_SetOutputPin( radio->nss_port, radio->nss_pin );

    return SX126X_BSP_STATUS_OK;
}

void sx126x_bsp_reset( const void* context )
{
    spi_t* radio = ( spi_t* ) context;

    LL_GPIO_ResetOutputPin( radio->reset_port, radio->reset_pin );
    LL_mDelay( 1 );
    LL_GPIO_SetOutputPin( radio->reset_port, radio->reset_pin );
}

sx126x_bsp_status_t sx126x_bsp_wakeup( const void* context )
{
    return SX126X_BSP_STATUS_ERROR;
}
