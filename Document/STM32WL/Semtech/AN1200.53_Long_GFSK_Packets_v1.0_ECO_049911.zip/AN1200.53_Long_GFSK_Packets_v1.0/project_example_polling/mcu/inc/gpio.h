#ifndef __GPIO_H__
#define __GPIO_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32l476xx.h"
#include "stm32l4xx_ll_bus.h"
#include "stm32l4xx_ll_gpio.h"

void GpioInit_Input(GPIO_TypeDef *port, uint32_t pin);
void GpioInit_Output(GPIO_TypeDef *port, uint32_t pin, uint8_t initialState);

#ifdef __cplusplus
}
#endif

#endif  // __GPIO_H__
