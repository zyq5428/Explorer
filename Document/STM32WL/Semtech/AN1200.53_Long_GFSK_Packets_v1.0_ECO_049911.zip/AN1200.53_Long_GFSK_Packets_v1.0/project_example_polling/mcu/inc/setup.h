#ifndef SETUP_H_
#define SETUP_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Set this flag to '1' to use Tx or to '0' to use Rx */
#ifndef TRANSMITTER
#define TRANSMITTER ( 1 )
#endif

#define RECEIVER !TRANSMITTER

#define LED_TX_PORT GPIOC
#define LED_TX_PIN LL_GPIO_PIN_1

#define LED_RX_PORT GPIOC
#define LED_RX_PIN LL_GPIO_PIN_0

#if RECEIVER == 1

#define SX126X_SPI SPI1
#define SX126X_NSS_PORT GPIOA
#define SX126X_NSS_PIN LL_GPIO_PIN_8
#define SX126X_BUSY_PORT GPIOB
#define SX126X_BUSY_PIN LL_GPIO_PIN_3
#define SX126X_IRQ_PORT GPIOB
#define SX126X_IRQ_PIN LL_GPIO_PIN_4
#define SX126X_RESET_PORT GPIOA
#define SX126X_RESET_PIN LL_GPIO_PIN_0

#else

#define SX126X_SPI SPI1
#define SX126X_NSS_PORT GPIOA
#define SX126X_NSS_PIN LL_GPIO_PIN_8
#define SX126X_BUSY_PORT GPIOB
#define SX126X_BUSY_PIN LL_GPIO_PIN_3
#define SX126X_IRQ_PORT GPIOB
#define SX126X_IRQ_PIN LL_GPIO_PIN_4
#define SX126X_RESET_PORT GPIOA
#define SX126X_RESET_PIN LL_GPIO_PIN_0
#define SX126X_DIO2_PORT GPIOB
#define SX126X_DIO2_PIN LL_GPIO_PIN_13
#define SX126X_DIO3_PORT GPIOB
#define SX126X_DIO3_PIN LL_GPIO_PIN_14

#endif

#endif
