#ifndef __SPI_H__
#define __SPI_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32l476xx.h"
#include "stm32l4xx_ll_bus.h"
#include "stm32l4xx_ll_gpio.h"
#include "stm32l4xx_ll_spi.h"

typedef struct{
  SPI_TypeDef *spi;
  GPIO_TypeDef *nss_port;
  uint32_t nss_pin;
  GPIO_TypeDef *busy_port;
  uint32_t busy_pin;
  GPIO_TypeDef *irq_port;
  uint32_t irq_pin;
  GPIO_TypeDef *reset_port;
  uint32_t reset_pin;
} spi_t;

void SpiInit( SPI_TypeDef *spi );

#ifdef __cplusplus
}
#endif

#endif  // __SPI_H__
