#ifndef COMMON_STM32_H_
#define COMMON_STM32_H_

#include <stdbool.h>

#include "stm32l4xx.h"
#include "clock.h"
#include "spi.h"
#include "gpio.h"
#include "sx126x.h"
#include "stm32l4xx_ll_utils.h"
#include "setup.h"
#include "sx126x_long_pkt/sx126x_long_pkt.h"

extern spi_t      radio_1;

#ifdef __cplusplus
extern "C" {
#endif

#if TRANSMITTER == 1
void send_bit_and_wait( bool bit );
#endif

void poll_on_radio_interrupt_and_clear( spi_t*             context,
                                        sx126x_irq_mask_t* irq_status );
void mcu_long_pkt_bitbang_activate( );
void mcu_init( const spi_t* radio );

void led_tx_on();
void led_tx_off();
void led_rx_on();
void led_rx_off();

#ifdef __cplusplus
}
#endif

#endif  // COMMON_STM32_H_
