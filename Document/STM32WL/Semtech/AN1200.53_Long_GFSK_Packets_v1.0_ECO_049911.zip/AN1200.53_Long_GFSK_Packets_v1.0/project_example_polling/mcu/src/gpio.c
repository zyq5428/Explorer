#include "gpio.h"

void GpioInit_Input(GPIO_TypeDef *port, uint32_t pin)
{
  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
  
  if( port == GPIOA ){
    LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOA);
  }
  else if( port == GPIOB ){
    LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOB);
  }
  else if( port == GPIOC ){
    LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOC);
  }
  else if( port == GPIOD ){
    LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOD);
  }
  
  GPIO_InitStruct.Pin = pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(port, &GPIO_InitStruct);
}

void GpioInit_Output(GPIO_TypeDef *port, uint32_t pin, uint8_t initialState)
{
  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
  
  if( port == GPIOA ){
    LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOA);
  }
  else if( port == GPIOB ){
    LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOB);
  }
  else if( port == GPIOC ){
    LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOC);
  }
  else if( port == GPIOD ){
    LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOD);
  }
  
  if( initialState == 1 ){
    LL_GPIO_SetOutputPin(port, pin);
  }
  else{
    LL_GPIO_ResetOutputPin(port, pin);
  }
  
  GPIO_InitStruct.Pin = pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(port, &GPIO_InitStruct);
}
