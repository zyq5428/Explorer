#include "misc.h"

#include "stm32l4xx_ll_rcc.h"

spi_t radio_1 = { .spi        = SX126X_SPI,
                  .nss_port   = SX126X_NSS_PORT,
                  .nss_pin    = SX126X_NSS_PIN,
                  .busy_port  = SX126X_BUSY_PORT,
                  .busy_pin   = SX126X_BUSY_PIN,
                  .irq_port   = SX126X_IRQ_PORT,
                  .irq_pin    = SX126X_IRQ_PIN,
                  .reset_port = SX126X_RESET_PORT,
                  .reset_pin  = SX126X_RESET_PIN };

#if TRANSMITTER == 1
void send_bit_and_wait( bool bit )
{
    if( bit )
    {
        LL_GPIO_SetOutputPin( SX126X_DIO3_PORT, SX126X_DIO3_PIN );
    }
    else
    {
        LL_GPIO_ResetOutputPin( SX126X_DIO3_PORT, SX126X_DIO3_PIN );
    }
    while( !LL_GPIO_IsInputPinSet( SX126X_DIO2_PORT, SX126X_DIO2_PIN ) )
        ;
    while( LL_GPIO_IsInputPinSet( SX126X_DIO2_PORT, SX126X_DIO2_PIN ) )
        ;
}

void mcu_long_pkt_bitbang_activate( )
{
    /* Configure pin connected to DIO3 as output */
    GpioInit_Output( SX126X_DIO3_PORT, SX126X_DIO3_PIN, 1 );
    /* Configure pin connected to DIO2 as input */
    GpioInit_Input( SX126X_DIO2_PORT, SX126X_DIO2_PIN );
}
#endif

void poll_on_radio_interrupt_and_clear( spi_t*             context,
                                        sx126x_irq_mask_t* irq_status )
{
    while( !LL_GPIO_IsInputPinSet( context->irq_port, context->irq_pin ) )
        ;
    sx126x_get_irq_status( context, irq_status );
    sx126x_clear_irq_status( context, *irq_status );
    while( LL_GPIO_IsInputPinSet( context->irq_port, context->irq_pin ) )
        ;
}

void led_tx_on()
{
    LL_GPIO_SetOutputPin( LED_TX_PORT, LED_TX_PIN );
}

void led_tx_off()
{
    LL_GPIO_ResetOutputPin( LED_TX_PORT, LED_TX_PIN );
}

void led_rx_on()
{
    LL_GPIO_SetOutputPin( LED_RX_PORT, LED_RX_PIN );
}

void led_rx_off()
{
    LL_GPIO_ResetOutputPin( LED_RX_PORT, LED_RX_PIN );
}

void mcu_init( const spi_t* radio )
{
    /* Configure the system clock */
    SystemClock_Config( );

    /* Enable needed clocks */
    LL_APB2_GRP1_EnableClock( LL_APB2_GRP1_PERIPH_SYSCFG );
    LL_APB1_GRP1_EnableClock( LL_APB1_GRP1_PERIPH_PWR );

    LL_RCC_ClocksTypeDef rcc_clock;
    LL_RCC_GetSystemClocksFreq( &rcc_clock );
    LL_Init1msTick( rcc_clock.SYSCLK_Frequency );

    /* Hardware interface initialisation */
    SpiInit( radio->spi );
    GpioInit_Output( radio->reset_port, radio->reset_pin, 1 );
    GpioInit_Output( radio->nss_port, radio->nss_pin, 1 );
    GpioInit_Input( radio->busy_port, radio->busy_pin );
    GpioInit_Input( radio->irq_port, radio->irq_pin );

    /* LEDS */
    GpioInit_Output( LED_TX_PORT, LED_TX_PIN, 0 );
    GpioInit_Output( LED_RX_PORT, LED_RX_PIN, 0 );
    
    /* Set antenna switch to RX. HW mod will be made for TX */
    GpioInit_Output( GPIOA, LL_GPIO_PIN_9, 1 );
}
