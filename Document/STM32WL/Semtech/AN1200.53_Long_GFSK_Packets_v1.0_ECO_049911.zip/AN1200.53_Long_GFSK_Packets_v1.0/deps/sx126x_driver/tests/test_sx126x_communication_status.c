/*!
 * \file      test_sx126x_communication_status.c
 *
 * \brief     SX126x test cases for communication status related commands
 *
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */

#include "unity.h"
#include "sx126x.h"

#include "mock_sx126x_bsp.h"

#if defined( TEST_PP )
#define TEST_VALUE( ... ) TEST_CASE( __VA_ARGS__ )
#else
#define TEST_VALUE( ... )
#endif

void*           radio;
sx126x_status_t status;

void setUp( void ) {}

void tearDown( void ) {}

void test_sx126x_get_status( void )
{
    uint8_t cbuffer_expected[]     = { 0xC0 };
    uint8_t rbuffer_expected[]     = { 0x00 };
    uint8_t cbuffer_out_expected[] = { 0x3A };

    sx126x_chip_status_t chip_status;

    /*
     * Case 1
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 1, 1,
                                              rbuffer_expected, 1, 1,
                                              SX126X_BSP_STATUS_OK );
    sx126x_bsp_read_ReturnArrayThruPtr_data( cbuffer_out_expected, 1 );

    status = sx126x_get_status( radio, &chip_status );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );
    TEST_ASSERT_EQUAL_UINT8( SX126X_CHIP_MODE_STBY_XOSC,
                             chip_status.chip_mode );
    TEST_ASSERT_EQUAL_UINT8( SX126X_CMD_STATUS_CMD_EXEC_FAILURE,
                             chip_status.cmd_status );

    /*
     * Case 2
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 1, 1,
                                              rbuffer_expected, 1, 1,
                                              SX126X_BSP_STATUS_ERROR );

    status = sx126x_get_status( radio, &chip_status );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_get_rx_buffer_status( void )
{
    uint8_t cbuffer_expected[] = { 0x13, 0x00 };
    uint8_t rbuffer_expected[] = { 0x00, 0x00 };
    uint8_t response[]         = { 0xAB, 0xCD };

    sx126x_rx_buffer_status_t rx_buffer_status;

    /*
     * Case 1
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 2, 2,
                                              rbuffer_expected, 2, 2,
                                              SX126X_BSP_STATUS_OK );
    sx126x_bsp_read_ReturnArrayThruPtr_data( response, 2 );

    status = sx126x_get_rx_buffer_status( radio, &rx_buffer_status );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );
    TEST_ASSERT_EQUAL_UINT8( 0xAB, rx_buffer_status.pld_len_in_bytes );
    TEST_ASSERT_EQUAL_UINT8( 0xCD, rx_buffer_status.buffer_start_pointer );

    /*
     * Case 2
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 2, 2,
                                              rbuffer_expected, 2, 2,
                                              SX126X_BSP_STATUS_ERROR );

    status = sx126x_get_rx_buffer_status( radio, &rx_buffer_status );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_get_gfsk_pkt_status( void )
{
    uint8_t cbuffer_expected[] = { 0x14, 0x00 };
    uint8_t rbuffer_expected[] = { 0x00, 0x00, 0x00 };
    uint8_t response[]         = { 0x56, 0x67, 0x78 };

    sx126x_pkt_status_gfsk_t pkt_status;

    /*
     * Case 1
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 2, 2,
                                              rbuffer_expected, 3, 3,
                                              SX126X_BSP_STATUS_OK );
    sx126x_bsp_read_ReturnArrayThruPtr_data( response, 3 );

    status = sx126x_get_gfsk_pkt_status( radio, &pkt_status );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );
    TEST_ASSERT_EQUAL_INT8( 0x56, pkt_status.rx_status );
    TEST_ASSERT_EQUAL_INT8( -52, pkt_status.rssi_sync );
    TEST_ASSERT_EQUAL_INT8( -60, pkt_status.rssi_avg );

    /*
     * Case 2
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 2, 2,
                                              rbuffer_expected, 3, 3,
                                              SX126X_BSP_STATUS_ERROR );

    status = sx126x_get_gfsk_pkt_status( radio, &pkt_status );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_get_lora_pkt_status( void )
{
    uint8_t cbuffer_expected[] = { 0x14, 0x00 };
    uint8_t rbuffer_expected[] = { 0x00, 0x00, 0x00 };
    uint8_t response[]         = { 0x23, 0x34, 0x45 };

    sx126x_pkt_status_lora_t pkt_status;

    /*
     * Case 1
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 2, 2,
                                              rbuffer_expected, 3, 3,
                                              SX126X_BSP_STATUS_OK );
    sx126x_bsp_read_ReturnArrayThruPtr_data( response, 3 );

    status = sx126x_get_lora_pkt_status( radio, &pkt_status );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );
    TEST_ASSERT_EQUAL_INT8( -18, pkt_status.rssi_pkt );
    TEST_ASSERT_EQUAL_INT8( 13, pkt_status.snr_pkt );
    TEST_ASSERT_EQUAL_INT8( -35, pkt_status.signal_rssi_pkt );

    /*
     * Case 2
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 2, 2,
                                              rbuffer_expected, 3, 3,
                                              SX126X_BSP_STATUS_ERROR );

    status = sx126x_get_lora_pkt_status( radio, &pkt_status );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_get_rssi_inst( void )
{
    uint8_t cbuffer_expected[] = { 0x15, 0x00 };
    uint8_t rbuffer_expected[] = { 0x00 };
    uint8_t response[]         = { 0x78 };
    int16_t rssi_in_dbm;

    /*
     * Case 1
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 2, 2,
                                              rbuffer_expected, 1, 1,
                                              SX126X_BSP_STATUS_OK );
    sx126x_bsp_read_ReturnArrayThruPtr_data( response, 1 );

    status = sx126x_get_rssi_inst( radio, &rssi_in_dbm );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );
    TEST_ASSERT_EQUAL_INT8( -60, rssi_in_dbm );

    /*
     * Case 2
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 2, 2,
                                              rbuffer_expected, 1, 1,
                                              SX126X_BSP_STATUS_ERROR );

    status = sx126x_get_rssi_inst( radio, &rssi_in_dbm );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_get_gfsk_stats( void )
{
    uint8_t cbuffer_expected[] = { 0x10, 0x00 };
    uint8_t rbuffer_expected[] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
    uint8_t response[]         = { 0xCD, 0xDE, 0xEF, 0xF0, 0x01, 0x12 };

    sx126x_stats_gfsk_t stats;

    /*
     * Case 1
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 2, 2,
                                              rbuffer_expected, 6, 6,
                                              SX126X_BSP_STATUS_OK );
    sx126x_bsp_read_ReturnArrayThruPtr_data( response, 6 );

    status = sx126x_get_gfsk_stats( radio, &stats );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );
    TEST_ASSERT_EQUAL_UINT16( 0xCDDE, stats.nb_pkt_received );
    TEST_ASSERT_EQUAL_UINT16( 0xEFF0, stats.nb_pkt_crc_error );
    TEST_ASSERT_EQUAL_UINT16( 0x0112, stats.nb_pkt_len_error );

    /*
     * Case 2
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 2, 2,
                                              rbuffer_expected, 6, 6,
                                              SX126X_BSP_STATUS_ERROR );

    status = sx126x_get_gfsk_stats( radio, &stats );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_get_lora_stats( void )
{
    uint8_t cbuffer_expected[] = { 0x10, 0x00 };
    uint8_t rbuffer_expected[] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
    uint8_t response[]         = { 0x23, 0x34, 0x45, 0x56, 0x67, 0x78 };

    sx126x_stats_lora_t stats;

    /*
     * Case 1
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 2, 2,
                                              rbuffer_expected, 6, 6,
                                              SX126X_BSP_STATUS_OK );
    sx126x_bsp_read_ReturnArrayThruPtr_data( response, 6 );

    status = sx126x_get_lora_stats( radio, &stats );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );
    TEST_ASSERT_EQUAL_UINT16( 0x2334, stats.nb_pkt_received );
    TEST_ASSERT_EQUAL_UINT16( 0x4556, stats.nb_pkt_crc_error );
    TEST_ASSERT_EQUAL_UINT16( 0x6778, stats.nb_pkt_hdr_error );

    /*
     * Case 2
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 2, 2,
                                              rbuffer_expected, 6, 6,
                                              SX126X_BSP_STATUS_ERROR );

    status = sx126x_get_lora_stats( radio, &stats );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_reset_stats( void )
{
    uint8_t length;
    uint8_t cbuffer_expected[] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn(
        radio, 0, cbuffer_expected, 7, 7, NULL, 0, 0, SX126X_BSP_STATUS_OK );

    status = sx126x_reset_stats( radio );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn(
        radio, 0, cbuffer_expected, 7, 7, NULL, 0, 0, SX126X_BSP_STATUS_ERROR );

    status = sx126x_reset_stats( radio );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}
