/*!
 * \file      test_sx126x_extra.c
 *
 * \brief     SX126x test cases for operational modes related commands
 *
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */

#include "unity.h"
#include "sx126x.h"

#include "mock_sx126x_bsp.h"

#if defined( TEST_PP )
#define TEST_VALUE( ... ) TEST_CASE( __VA_ARGS__ )
#else
#define TEST_VALUE( ... )
#endif

void*           radio;
sx126x_status_t status;

void setUp( void ) {}

void tearDown( void ) {}

void test_sx126x_cfg_rx_boosted( void )
{
    uint8_t cbuffer_expected_1[] = { 0x0D, 0x08, 0xAC };
    uint8_t cdata_expected_1[]   = { 0x96 };
    uint8_t cbuffer_expected_2[] = { 0x0D, 0x08, 0xAC };
    uint8_t cdata_expected_2[]   = { 0x94 };

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_1, 3,
                                               3, cdata_expected_1, 1, 1,
                                               SX126X_BSP_STATUS_OK );

    status = sx126x_cfg_rx_boosted( radio, true );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Second case
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 3,
                                               3, cdata_expected_2, 1, 1,
                                               SX126X_BSP_STATUS_ERROR );

    status = sx126x_cfg_rx_boosted( radio, false );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_set_gfsk_sync_word( void )
{
    uint8_t cbuffer_expected_1[] = { 0x0D, 0x06, 0xC0 };
    uint8_t cdata_expected_1[]   = { 0x01, 0x12, 0x23, 0x00,
                                   0x00, 0x00, 0x00, 0x00 };
    uint8_t cbuffer_expected_2[] = { 0x0D, 0x06, 0xC0 };
    uint8_t cdata_expected_2[]   = { 0x78, 0x89, 0x9A, 0xAB,
                                   0xBC, 0xCD, 0x00, 0x00 };

    uint8_t syncword_1[] = { 0x01, 0x12, 0x23 };
    uint8_t syncword_2[] = { 0x78, 0x89, 0x9A, 0xAB, 0xBC, 0xCD };
    uint8_t syncword_3[] = { 0x78, 0x89, 0x9A, 0xAB, 0xBC,
                             0xCD, 0xEF, 0x01, 0x23 };

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_1, 3,
                                               3, cdata_expected_1, 8, 8,
                                               SX126X_BSP_STATUS_OK );

    status = sx126x_set_gfsk_sync_word( radio, syncword_1, 3 );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 3,
                                               3, cdata_expected_2, 8, 8,
                                               SX126X_BSP_STATUS_ERROR );

    status = sx126x_set_gfsk_sync_word( radio, syncword_2, 6 );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );

    /*
     * Case 3
     */
    status = sx126x_set_gfsk_sync_word( radio, syncword_2, 9 );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_set_lora_sync_word( void )
{
    uint8_t cbuffer_expected_1[] = { 0x0D, 0x07, 0x40 };
    uint8_t cdata_expected_1[]   = { 0x14, 0x24 };
    uint8_t cbuffer_expected_2[] = { 0x0D, 0x07, 0x40 };
    uint8_t cdata_expected_2[]   = { 0x34, 0x44 };

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_1, 3,
                                               3, cdata_expected_1, 2, 2,
                                               SX126X_BSP_STATUS_OK );

    status = sx126x_set_lora_sync_word( radio, 0x12 );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 3,
                                               3, cdata_expected_2, 2, 2,
                                               SX126X_BSP_STATUS_ERROR );

    status = sx126x_set_lora_sync_word( radio, 0x34 );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_set_gfsk_crc_seed( void )
{
    uint8_t cbuffer_expected_1[] = { 0x0D, 0x06, 0xBC };
    uint8_t cdata_expected_1[]   = { 0x12, 0x34 };
    uint8_t cbuffer_expected_2[] = { 0x0D, 0x06, 0xBC };
    uint8_t cdata_expected_2[]   = { 0xAB, 0xCD };

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_1, 3,
                                               3, cdata_expected_1, 2, 2,
                                               SX126X_BSP_STATUS_OK );

    status = sx126x_set_gfsk_crc_seed( radio, 0x1234 );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 3,
                                               3, cdata_expected_2, 2, 2,
                                               SX126X_BSP_STATUS_ERROR );

    status = sx126x_set_gfsk_crc_seed( radio, 0xABCD );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_set_gfsk_crc_polynomial( void )
{
    uint8_t cbuffer_expected_1[] = { 0x0D, 0x06, 0xBE };
    uint8_t cdata_expected_1[]   = { 0x56, 0x78 };
    uint8_t cbuffer_expected_2[] = { 0x0D, 0x06, 0xBE };
    uint8_t cdata_expected_2[]   = { 0xCD, 0xEF };

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_1, 3,
                                               3, cdata_expected_1, 2, 2,
                                               SX126X_BSP_STATUS_OK );

    status = sx126x_set_gfsk_crc_polynomial( radio, 0x5678 );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 3,
                                               3, cdata_expected_2, 2, 2,
                                               SX126X_BSP_STATUS_ERROR );

    status = sx126x_set_gfsk_crc_polynomial( radio, 0xCDEF );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_set_gfsk_whitening_seed( void )
{
    uint8_t cbuffer_expected_1[] = { 0x1D, 0x06, 0xB8, 0x00 };
    uint8_t rbuffer_expected_1[] = { 0x00 };
    uint8_t response_1[]         = { 0x45 };
    uint8_t cbuffer_expected_2[] = { 0x0D, 0x06, 0xB8 };
    uint8_t cdata_expected_2[]   = { 0x44 };
    uint8_t cbuffer_expected_3[] = { 0x0D, 0x06, 0xB9 };
    uint8_t cdata_expected_3[]   = { 0x23 };

    /*
     * Case 1
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_1, 4,
                                              4, rbuffer_expected_1, 1, 1,
                                              SX126X_BSP_STATUS_OK );
    sx126x_bsp_read_ReturnArrayThruPtr_data( response_1, 1 );

    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 3,
                                               3, cdata_expected_2, 1, 1,
                                               SX126X_BSP_STATUS_OK );

    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_3, 3,
                                               3, cdata_expected_3, 1, 1,
                                               SX126X_BSP_STATUS_OK );

    status = sx126x_set_gfsk_whitening_seed( radio, 0x0023 );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_1, 4,
                                              4, rbuffer_expected_1, 1, 1,
                                              SX126X_BSP_STATUS_ERROR );
    ;

    status = sx126x_set_gfsk_whitening_seed( radio, 0x0023 );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );

    /*
     * Case 3
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_1, 4,
                                              4, rbuffer_expected_1, 1, 1,
                                              SX126X_BSP_STATUS_OK );
    sx126x_bsp_read_ReturnArrayThruPtr_data( response_1, 1 );

    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 3,
                                               3, cdata_expected_2, 1, 1,
                                               SX126X_BSP_STATUS_ERROR );

    status = sx126x_set_gfsk_whitening_seed( radio, 0x0023 );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}
