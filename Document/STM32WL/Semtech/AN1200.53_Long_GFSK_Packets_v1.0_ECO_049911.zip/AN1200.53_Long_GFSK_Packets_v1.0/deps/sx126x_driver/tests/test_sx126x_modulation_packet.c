/*!
 * \file      test_sx126x_modulation_packet.c
 *
 * \brief     SX126x test cases for modulation and packet related commands
 *
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */

#include "unity.h"
#include "sx126x.h"

#include "mock_sx126x_bsp.h"

#if defined( TEST_PP )
#define TEST_VALUE( ... ) TEST_CASE( __VA_ARGS__ )
#else
#define TEST_VALUE( ... )
#endif

void*           radio;
sx126x_status_t status;

void setUp( void ) {}

void tearDown( void ) {}

void test_sx126x_set_rf_freq( void )
{
    uint8_t cbuffer_expected_1[] = { 0x86, 0x36, 0x40, 0x00, 0x00 };
    uint8_t cbuffer_expected_2[] = { 0x86, 0x39, 0x30, 0x00, 0x00 };

    uint32_t freq_in_hz = 868000000;

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn(
        radio, 0, cbuffer_expected_1, 5, 5, NULL, 0, 0, SX126X_BSP_STATUS_OK );

    freq_in_hz = 868000000;
    status     = sx126x_set_rf_freq( radio, freq_in_hz );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 5,
                                               5, NULL, 0, 0,
                                               SX126X_BSP_STATUS_ERROR );

    freq_in_hz = 915000000;
    status     = sx126x_set_rf_freq( radio, freq_in_hz );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_set_pkt_type( void )
{
    uint8_t cbuffer_expected_1[] = { 0x8A, 0x01 };
    uint8_t cbuffer_expected_2[] = { 0x8A, 0x00 };

    sx126x_pkt_type_t packet_type;

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn(
        radio, 0, cbuffer_expected_1, 2, 2, NULL, 0, 0, SX126X_BSP_STATUS_OK );

    packet_type = SX126X_PKT_TYPE_LORA;
    status      = sx126x_set_pkt_type( radio, packet_type );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 2,
                                               2, NULL, 0, 0,
                                               SX126X_BSP_STATUS_ERROR );

    packet_type = SX126X_PKT_TYPE_GFSK;
    status      = sx126x_set_pkt_type( radio, packet_type );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_get_pkt_type( void )
{
    uint8_t cbuffer_expected[] = { 0x11, 0x00, 0x00 };
    uint8_t rbuffer_expected[] = { 0x00 };
    uint8_t response_1[]       = { 0x00 };

    sx126x_pkt_type_t packet_type = 0x00;

    /*
     * Case 1
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 3, 3,
                                              rbuffer_expected, 1, 1,
                                              SX126X_BSP_STATUS_OK );
    sx126x_bsp_read_ReturnArrayThruPtr_data( response_1, 1 );

    status = sx126x_get_pkt_type( radio, &packet_type );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );
    TEST_ASSERT_EQUAL_UINT8( SX126X_PKT_TYPE_GFSK, packet_type );

    /*
     * Case 2
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 3, 3,
                                              rbuffer_expected, 1, 1,
                                              SX126X_BSP_STATUS_ERROR );

    status = sx126x_get_pkt_type( radio, &packet_type );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_set_tx_params( void )
{
    uint8_t cbuffer_expected_1[] = { 0x8E, 0xFB, 0x07 };
    uint8_t cbuffer_expected_2[] = { 0x8E, 0x0E, 0x02 };

    int8_t             pwr_in_dbm;
    sx126x_ramp_time_t ramp_time;

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn(
        radio, 0, cbuffer_expected_1, 3, 3, NULL, 0, 0, SX126X_BSP_STATUS_OK );

    pwr_in_dbm = -5;
    ramp_time  = SX126X_RAMP_3400_US;
    status     = sx126x_set_tx_params( radio, pwr_in_dbm, ramp_time );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 3,
                                               3, NULL, 0, 0,
                                               SX126X_BSP_STATUS_ERROR );

    pwr_in_dbm = 14;
    ramp_time  = SX126X_RAMP_40_US;
    status     = sx126x_set_tx_params( radio, pwr_in_dbm, ramp_time );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_set_gfsk_mod_params( void )
{
    uint8_t cbuffer_expected_1[] = { 0x8B, 0x00, 0x1A, 0xAA, 0x0A,
                                     0x11, 0x00, 0xCC, 0xCC };
    uint8_t cbuffer_expected_2[] = { 0x8B, 0x00, 0x1A, 0xAA, 0x08,
                                     0x09, 0x00, 0xCC, 0xCC };

    sx126x_mod_params_gfsk_t mod_params;

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn(
        radio, 0, cbuffer_expected_1, 9, 9, NULL, 0, 0, SX126X_BSP_STATUS_OK );

    mod_params.br_in_bps    = 150000;
    mod_params.bw_dsb_param = SX126X_GFSK_BW_373600;
    mod_params.fdev_in_hz   = 50000;
    mod_params.mod_shape    = SX126X_GFSK_MOD_SHAPE_BT_07;
    status                  = sx126x_set_gfsk_mod_params( radio, &mod_params );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 9,
                                               9, NULL, 0, 0,
                                               SX126X_BSP_STATUS_ERROR );

    mod_params.br_in_bps    = 150000;
    mod_params.bw_dsb_param = SX126X_GFSK_BW_467000;
    mod_params.fdev_in_hz   = 50000;
    mod_params.mod_shape    = SX126X_GFSK_MOD_SHAPE_BT_03;
    status                  = sx126x_set_gfsk_mod_params( radio, &mod_params );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_set_lora_mod_params( void )
{
    uint8_t cbuffer_expected_1[] = { 0x8B, 0x06, 0x04, 0x02, 0x00 };
    uint8_t cbuffer_expected_2[] = { 0x8B, 0x0C, 0x06, 0x03, 0x01 };

    sx126x_mod_params_lora_t mod_params;

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn(
        radio, 0, cbuffer_expected_1, 5, 5, NULL, 0, 0, SX126X_BSP_STATUS_OK );

    mod_params.bw   = SX126X_LORA_BW_125;
    mod_params.cr   = SX126X_LORA_CR_4_6;
    mod_params.ldro = 0;
    mod_params.sf   = SX126X_LORA_SF6;
    status          = sx126x_set_lora_mod_params( radio, &mod_params );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 5,
                                               5, NULL, 0, 0,
                                               SX126X_BSP_STATUS_ERROR );

    mod_params.bw   = SX126X_LORA_BW_500;
    mod_params.cr   = SX126X_LORA_CR_4_7;
    mod_params.ldro = 1;
    mod_params.sf   = SX126X_LORA_SF12;
    status          = sx126x_set_lora_mod_params( radio, &mod_params );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_set_gfsk_pkt_params( void )
{
    uint8_t cbuffer_expected_1[] = { 0x8C, 0x01, 0x89, 0x05, 0x20,
                                     0x02, 0x01, 0xAB, 0x06, 0x01 };
    uint8_t cbuffer_expected_2[] = { 0x8C, 0xAB, 0xCD, 0x04, 0x40,
                                     0x01, 0x00, 0xEF, 0x01, 0x00 };

    sx126x_pkt_params_gfsk_t pkt_params;

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_1, 10,
                                               10, NULL, 0, 0,
                                               SX126X_BSP_STATUS_OK );

    pkt_params.addr_cmp              = SX126X_GFSK_ADDR_CMP_FILT_NODE_BROAD;
    pkt_params.crc_type              = SX126X_CRC_2_BYTES_INV;
    pkt_params.dc_free               = SX126X_DC_FREE_WHITENING;
    pkt_params.hdr_type              = SX126X_GFSK_PKT_VAR_LEN;
    pkt_params.pbl_len_in_bits       = 0x0189;
    pkt_params.pbl_min_det           = SX126X_GFSK_PBL_DET_16_BITS;
    pkt_params.pld_len_in_bytes      = 0xAB;
    pkt_params.sync_word_len_in_bits = 0x20;
    status = sx126x_set_gfsk_pkt_params( radio, &pkt_params );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 10,
                                               10, NULL, 0, 0,
                                               SX126X_BSP_STATUS_ERROR );

    pkt_params.addr_cmp              = SX126X_GFSK_ADDR_CMP_FILT_NODE;
    pkt_params.crc_type              = SX126X_CRC_OFF;
    pkt_params.dc_free               = SX126X_DC_FREE_OFF;
    pkt_params.hdr_type              = SX126X_GFSK_PKT_FIX_LEN;
    pkt_params.pbl_len_in_bits       = 0xABCD;
    pkt_params.pbl_min_det           = SX126X_GFSK_PBL_DET_08_BITS;
    pkt_params.pld_len_in_bytes      = 0xEF;
    pkt_params.sync_word_len_in_bits = 0x40;
    status = sx126x_set_gfsk_pkt_params( radio, &pkt_params );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_set_lora_pkt_params( void )
{
    uint8_t cbuffer_expected_1[] = { 0x8C, 0xAB, 0xCD, 0x01, 0xA5, 0x01, 0x00 };
    uint8_t cbuffer_expected_2[] = { 0x8C, 0xAB, 0xCD, 0x01, 0xA5, 0x00, 0x01 };

    sx126x_pkt_params_lora_t pkt_params;

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn(
        radio, 0, cbuffer_expected_1, 7, 7, NULL, 0, 0, SX126X_BSP_STATUS_OK );

    pkt_params.crc_is_on        = true;
    pkt_params.hdr_type         = SX126X_LORA_PKT_IMPLICIT;
    pkt_params.invert_iq_is_on  = false;
    pkt_params.pbl_len_in_symb  = 0xABCD;
    pkt_params.pld_len_in_bytes = 0xA5;
    status = sx126x_set_lora_pkt_params( radio, &pkt_params );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn(
        radio, 0, cbuffer_expected_2, 7, 7, NULL, 0, 0, SX126X_BSP_STATUS_OK );

    pkt_params.crc_is_on        = false;
    pkt_params.hdr_type         = SX126X_LORA_PKT_IMPLICIT;
    pkt_params.invert_iq_is_on  = true;
    pkt_params.pbl_len_in_symb  = 0xABCD;
    pkt_params.pld_len_in_bytes = 0xA5;
    status = sx126x_set_lora_pkt_params( radio, &pkt_params );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );
}

void test_sx126x_set_cad_params( void )
{
    uint8_t cbuffer_expected_1[] = { 0x88, 0x03, 0x34, 0x12,
                                     0x10, 0xAB, 0xCD, 0xEF };
    uint8_t cbuffer_expected_2[] = { 0x88, 0x02, 0xCD, 0xAB,
                                     0x00, 0x23, 0x45, 0x67 };

    sx126x_lora_cad_params_t cad_params;

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn(
        radio, 0, cbuffer_expected_1, 8, 8, NULL, 0, 0, SX126X_BSP_STATUS_OK );

    cad_params.cad_det_min   = 0x12;
    cad_params.cad_det_peak  = 0x34;
    cad_params.cad_exit_mode = SX126X_LORA_CAD_LBT;
    cad_params.cad_symb_nb   = SX126X_LORA_CAD_08_SYMB;
    cad_params.cad_timeout   = 0x89ABCDEF;
    status                   = sx126x_set_cad_params( radio, &cad_params );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 8,
                                               8, NULL, 0, 0,
                                               SX126X_BSP_STATUS_ERROR );

    cad_params.cad_det_min   = 0xAB;
    cad_params.cad_det_peak  = 0xCD;
    cad_params.cad_exit_mode = SX126X_LORA_CAD_ONLY;
    cad_params.cad_symb_nb   = SX126X_LORA_CAD_04_SYMB;
    cad_params.cad_timeout   = 0x01234567;
    status                   = sx126x_set_cad_params( radio, &cad_params );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_set_buffer_base_addr( void )
{
    uint8_t cbuffer_expected_1[] = { 0x8F, 0xAB, 0xEF };
    uint8_t cbuffer_expected_2[] = { 0x8F, 0xCD, 0x01 };
    uint8_t tx_base_address;
    uint8_t rx_base_address;

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn(
        radio, 0, cbuffer_expected_1, 3, 3, NULL, 0, 0, SX126X_BSP_STATUS_OK );

    tx_base_address = 0xAB;
    rx_base_address = 0xEF;
    status =
        sx126x_set_buffer_base_addr( radio, tx_base_address, rx_base_address );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 3,
                                               3, NULL, 0, 0,
                                               SX126X_BSP_STATUS_ERROR );

    tx_base_address = 0xCD;
    rx_base_address = 0x01;
    status =
        sx126x_set_buffer_base_addr( radio, tx_base_address, rx_base_address );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_set_lora_symb_nb_timeout( void )
{
    uint8_t cbuffer_expected_1[] = { 0xA0, 0x23 };
    uint8_t cbuffer_expected_2[] = { 0xA0, 0x45 };

    uint8_t symb_num = 0x23;

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn(
        radio, 0, cbuffer_expected_1, 2, 2, NULL, 0, 0, SX126X_BSP_STATUS_OK );

    symb_num = 0x23;
    status   = sx126x_set_lora_symb_nb_timeout( radio, symb_num );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 2,
                                               2, NULL, 0, 0,
                                               SX126X_BSP_STATUS_ERROR );

    symb_num = 0x45;
    status   = sx126x_set_lora_symb_nb_timeout( radio, symb_num );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}
