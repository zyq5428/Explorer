#!/bin/bash

# cleanup
cd ..
rm -f _tests/project.yml
rm _tests/vendor/ceedling/vendor/unity/auto/generate_test_runner.rb

# create project
ceedling new _tests
cp tests/project.yml _tests

# apply temporary patch
git apply --directory _tests/vendor/ceedling/vendor/unity tests/0001-Fix-the-generation-of-test-runners-by-handling-multi.patch

# execute tests
cd _tests
ceedling clobber
ceedling gcov:all utils:gcov
