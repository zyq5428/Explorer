/*!
 * \file      test_sx126x_miscellaneous.c
 *
 * \brief     SX126x test cases for miscellaneous commands
 *
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */

#include "unity.h"
#include "sx126x.h"

#include "mock_sx126x_bsp.h"

#include "time_on_air_simulations.h"

#if defined( TEST_PP )
#define TEST_VALUE( ... ) TEST_CASE( __VA_ARGS__ )
#else
#define TEST_VALUE( ... )
#endif

#define CEILING( x ) \
    ( int ) ( x ) + ( 1 - ( int ) ( ( int ) ( ( x ) + 1 ) - ( x ) ) )

void*           radio;
sx126x_status_t status;

void setUp( void ) {}

void tearDown( void ) {}

void test_sx126x_reset( void )
{
    sx126x_bsp_reset_Expect( radio );

    status = sx126x_reset( radio );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );
}

void test_sx126x_wakeup( void )
{
    sx126x_bsp_wakeup_ExpectAndReturn( radio, SX126X_BSP_STATUS_OK );

    status = sx126x_wakeup( radio );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );
}

void test_sx126x_get_device_errors( void )
{
    uint8_t cbuffer_expected[] = { 0x17, 0x00 };
    uint8_t rbuffer_expected[] = { 0x00, 0x00 };
    uint8_t response[]         = { 0x01, 0x55 };

    sx126x_errors_mask_t errors;

    /*
     * Case 1
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 2, 2,
                                              rbuffer_expected, 2, 2,
                                              SX126X_BSP_STATUS_OK );
    sx126x_bsp_read_ReturnArrayThruPtr_data( response, 2 );

    status = sx126x_get_device_errors( radio, &errors );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );
    TEST_ASSERT_EQUAL_UINT8( SX126X_ERRORS_PA_RAMP | SX126X_ERRORS_PLL_LOCK |
                                 SX126X_ERRORS_IMG_CALIBRATION |
                                 SX126X_ERRORS_PLL_CALIBRATION |
                                 SX126X_ERRORS_RC64K_CALIBRATION,
                             errors );

    /*
     * Case 2
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 2, 2,
                                              rbuffer_expected, 2, 2,
                                              SX126X_BSP_STATUS_ERROR );

    status = sx126x_get_device_errors( radio, &errors );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_clear_device_errors( void )
{
    uint8_t cbuffer_expected[] = { 0x07, 0x00, 0x00 };

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn(
        radio, 0, cbuffer_expected, 3, 3, NULL, 0, 0, SX126X_BSP_STATUS_OK );

    status = sx126x_clear_device_errors( radio );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn(
        radio, 0, cbuffer_expected, 3, 3, NULL, 0, 0, SX126X_BSP_STATUS_ERROR );

    status = sx126x_clear_device_errors( radio );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

TEST_VALUE( 0, SX126X_STATUS_ERROR, 0 )
TEST_VALUE( 3000, SX126X_STATUS_OK, SX126X_GFSK_BW_4800 )
TEST_VALUE( 4800, SX126X_STATUS_OK, SX126X_GFSK_BW_4800 )
TEST_VALUE( 12000, SX126X_STATUS_OK, SX126X_GFSK_BW_14600 )
TEST_VALUE( 467000, SX126X_STATUS_OK, SX126X_GFSK_BW_467000 )
TEST_VALUE( 600000, SX126X_STATUS_UNKNOWN_VALUE, 0 )
void test_sx126x_get_gfsk_bw_param( uint32_t        bw,
                                    sx126x_status_t status_expected,
                                    uint8_t         param_expected )
{
    uint8_t         param = 0;
    sx126x_status_t status;

    status = sx126x_get_gfsk_bw_param( bw, &param );

    TEST_ASSERT_EQUAL_UINT8( status_expected, status );

    if( status == SX126X_STATUS_OK )
    {
        TEST_ASSERT_EQUAL_UINT8( param_expected, param );
    }
}

TEST_VALUE( SX126X_LORA_BW_007, 7812UL )
TEST_VALUE( SX126X_LORA_BW_010, 10417UL )
TEST_VALUE( SX126X_LORA_BW_015, 15625UL )
TEST_VALUE( SX126X_LORA_BW_020, 20833UL )
TEST_VALUE( SX126X_LORA_BW_031, 31250UL )
TEST_VALUE( SX126X_LORA_BW_041, 41667UL )
TEST_VALUE( SX126X_LORA_BW_062, 62500UL )
TEST_VALUE( SX126X_LORA_BW_125, 125000UL )
TEST_VALUE( SX126X_LORA_BW_250, 250000UL )
TEST_VALUE( SX126X_LORA_BW_500, 500000UL )
TEST_VALUE( 255, 0 )
void test_sx126x_get_bandwidth_in_hz( sx126x_lora_bw_t bw,
                                      uint32_t         bw_in_hz_expected )
{
    uint32_t bw_in_hz = 0;

    bw_in_hz = sx126x_get_bandwidth_in_hz( bw );

    TEST_ASSERT_EQUAL_UINT32( bw_in_hz_expected, bw_in_hz );
}
#if 0  // Disabled up until time_on_air_simulations.h is updated
void test_sx126x_get_lora_time_on_air_in_ms( void )
{
    uint32_t                 time_on_air_in_ms = 0;
    sx126x_pkt_params_lora_t pkt_p;
    sx126x_mod_params_lora_t mod_p;
    uint32_t                 size = sizeof( assets ) / sizeof( assets[0] );

    for( uint32_t i = 0; i < size; i++ )
    {
        pkt_p.pbl_len_in_symb = assets[i].pbl;
        pkt_p.hdr_type = ( assets[i].impl == 1 ) ? SX126X_LORA_PKT_IMPLICIT
                                                 : SX126X_LORA_PKT_EXPLICIT;
        pkt_p.pld_len_in_bytes = assets[i].pld;
        pkt_p.crc_is_on        = ( assets[i].crc == 1 ) ? true : false;
        pkt_p.invert_iq_is_on  = false;

        mod_p.sf = ( sx126x_lora_sf_t )( assets[i].sf << 4 );
        mod_p.bw = SX126X_LORA_BW_125;
        mod_p.cr = ( sx126x_lora_cr_t )( assets[i].cr );

        time_on_air_in_ms = sx126x_get_lora_time_on_air_in_ms( &pkt_p, &mod_p );

        uint32_t time_on_air_in_ms_expected = CEILING( assets[i].toa * 1000 );

        TEST_ASSERT_EQUAL_UINT32( time_on_air_in_ms_expected,
                                  time_on_air_in_ms );
    }
}

// NOTE: Same value due to the rounding to ms.
TEST_VALUE( SX126X_GFSK_PKT_FIX_LEN, SX126X_CRC_OFF, 42 )
TEST_VALUE( SX126X_GFSK_PKT_VAR_LEN, SX126X_CRC_1_BYTES, 42 )
TEST_VALUE( SX126X_GFSK_PKT_FIX_LEN, SX126X_CRC_2_BYTES, 42 )
TEST_VALUE( SX126X_GFSK_PKT_VAR_LEN, SX126X_CRC_1_BYTES_INV, 42 )
TEST_VALUE( SX126X_GFSK_PKT_VAR_LEN, SX126X_CRC_2_BYTES_INV, 43 )
TEST_VALUE( SX126X_GFSK_PKT_VAR_LEN, 255, 42 )
void test_sx126x_get_gfsk_time_on_air_in_ms(
    sx126x_gfsk_pkt_len_modes_t hdr_type, sx126x_gfsk_crc_types_t crc_type,
    uint32_t time_on_air_in_ms_expected )
{
    uint32_t                 time_on_air_in_ms = 0;
    sx126x_pkt_params_gfsk_t pkt_p             = {
        .pbl_len_in_bits       = 40,
        .pbl_min_det           = SX126X_GFSK_PBL_DET_08_BITS,
        .sync_word_len_in_bits = 24,
        .addr_cmp              = SX126X_GFSK_ADDR_CMP_FILT_OFF,
        .hdr_type              = hdr_type,
        .pld_len_in_bytes      = 252,
        .crc_type              = crc_type,
        .dc_free               = SX126X_DC_FREE_WHITENING,
    };
    sx126x_mod_params_gfsk_t mod_p = {
        .br_in_bps    = 50000,
        .fdev_in_hz   = 25000,
        .mod_shape    = SX126X_GFSK_MOD_SHAPE_BT_1,
        .bw_dsb_param = SX126X_GFSK_BW_117300,
    };

    time_on_air_in_ms = sx126x_get_gfsk_time_on_air_in_ms( &pkt_p, &mod_p );

    TEST_ASSERT_EQUAL_UINT32( time_on_air_in_ms_expected, time_on_air_in_ms );
}
#endif
