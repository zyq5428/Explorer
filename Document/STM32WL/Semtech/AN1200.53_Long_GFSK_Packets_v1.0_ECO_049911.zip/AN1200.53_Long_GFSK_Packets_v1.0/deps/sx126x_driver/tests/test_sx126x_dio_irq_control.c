/*!
 * \file      test_sx126x_dio_irq_control.c
 *
 * \brief     SX126x test cases for DIO and interrupt related commands
 *
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */

#include "unity.h"
#include "sx126x.h"

#include "mock_sx126x_bsp.h"

#if defined( TEST_PP )
#define TEST_VALUE( ... ) TEST_CASE( __VA_ARGS__ )
#else
#define TEST_VALUE( ... )
#endif

void*           radio;
sx126x_status_t status;

void setUp( void ) {}

void tearDown( void ) {}

void test_sx126x_set_dio_irq_params( void )
{
    uint8_t  cbuffer_expected_1[] = { 0x08, 0x03, 0xFF, 0x02, 0x49,
                                     0x00, 0x92, 0x01, 0x24 };
    uint8_t  cbuffer_expected_2[] = { 0x08, 0x00, 0x00, 0x00, 0x00,
                                     0x00, 0x00, 0x00, 0x00 };
    uint16_t irq_mask;
    uint16_t dio1_mask;
    uint16_t dio2_mask;
    uint16_t dio3_mask;

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn(
        radio, 0, cbuffer_expected_1, 9, 9, NULL, 0, 0, SX126X_BSP_STATUS_OK );

    irq_mask  = SX126X_IRQ_ALL;
    dio1_mask = SX126X_IRQ_TX_DONE | SX126X_IRQ_SYNC_WORD_VALID |
                SX126X_IRQ_CRC_ERROR | SX126X_IRQ_TIMEOUT;
    dio2_mask =
        SX126X_IRQ_RX_DONE | SX126X_IRQ_HEADER_VALID | SX126X_IRQ_CAD_DONE;
    dio3_mask =
        SX126X_IRQ_PBL_DET | SX126X_IRQ_HEADER_ERROR | SX126X_IRQ_CAD_DET;

    status = sx126x_set_dio_irq_params( radio, irq_mask, dio1_mask, dio2_mask,
                                        dio3_mask );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 9,
                                               9, NULL, 0, 0,
                                               SX126X_BSP_STATUS_ERROR );

    irq_mask  = SX126X_IRQ_NONE;
    dio1_mask = SX126X_IRQ_NONE;
    dio2_mask = SX126X_IRQ_NONE;
    dio3_mask = SX126X_IRQ_NONE;
    status = sx126x_set_dio_irq_params( radio, irq_mask, dio1_mask, dio2_mask,
                                        dio3_mask );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_get_irq_status( void )
{
    uint8_t           cbuffer_expected[] = { 0x12, 0x00 };
    uint8_t           rbuffer_expected[] = { 0x00, 0x00 };
    uint8_t           response[]         = { 0x03, 0xFF };
    sx126x_irq_mask_t irq_status;

    /*
     * Case 1
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 2, 2,
                                              rbuffer_expected, 2, 2,
                                              SX126X_BSP_STATUS_OK );
    sx126x_bsp_read_ReturnArrayThruPtr_data( response, 2 );

    status = sx126x_get_irq_status( radio, &irq_status );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );
    TEST_ASSERT_EQUAL_UINT16( 0x03FF, irq_status );

    /*
     * Case 2
     */
    sx126x_bsp_read_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected, 2, 2,
                                              rbuffer_expected, 2, 2,
                                              SX126X_BSP_STATUS_ERROR );

    status = sx126x_get_irq_status( radio, &irq_status );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_clear_irq_status( void )
{
    uint8_t  cbuffer_expected_1[] = { 0x02, 0x03, 0xFF };
    uint8_t  cbuffer_expected_2[] = { 0x02, 0x00, 0x00 };
    uint16_t irq_mask;

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn(
        radio, 0, cbuffer_expected_1, 3, 3, NULL, 0, 0, SX126X_BSP_STATUS_OK );

    irq_mask = SX126X_IRQ_ALL;
    status   = sx126x_clear_irq_status( radio, irq_mask );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 3,
                                               3, NULL, 0, 0,
                                               SX126X_BSP_STATUS_ERROR );

    irq_mask = SX126X_IRQ_NONE;
    status   = sx126x_clear_irq_status( radio, irq_mask );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_set_dio2_as_rf_sw_ctrl( void )
{
    uint8_t cbuffer_expected_1[] = { 0x9D, 0x01 };
    uint8_t cbuffer_expected_2[] = { 0x9D, 0x00 };

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn(
        radio, 0, cbuffer_expected_1, 2, 2, NULL, 0, 0, SX126X_BSP_STATUS_OK );

    status = sx126x_set_dio2_as_rf_sw_ctrl( radio, true );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 2,
                                               2, NULL, 0, 0,
                                               SX126X_BSP_STATUS_ERROR );

    status = sx126x_set_dio2_as_rf_sw_ctrl( radio, false );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}

void test_sx126x_set_dio3_as_tcxo_ctrl( void )
{
    uint8_t cbuffer_expected_1[] = { 0x97, 0x04, 0x23, 0x45, 0x67 };
    uint8_t cbuffer_expected_2[] = { 0x97, 0x07, 0xAB, 0xCD, 0xEF };
    sx126x_tcxo_ctrl_voltages_t tcxo_ctrl_voltage;
    uint32_t                    timeout;

    /*
     * Case 1
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn(
        radio, 0, cbuffer_expected_1, 5, 5, NULL, 0, 0, SX126X_BSP_STATUS_OK );

    timeout           = 0x01234567;
    tcxo_ctrl_voltage = SX126X_TCXO_CTRL_2_4V;
    status = sx126x_set_dio3_as_tcxo_ctrl( radio, tcxo_ctrl_voltage, timeout );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_OK, status );

    /*
     * Case 2
     */
    sx126x_bsp_write_ExpectWithArrayAndReturn( radio, 0, cbuffer_expected_2, 5,
                                               5, NULL, 0, 0,
                                               SX126X_BSP_STATUS_ERROR );

    timeout           = 0x89ABCDEF;
    tcxo_ctrl_voltage = SX126X_TCXO_CTRL_3_3V;
    status = sx126x_set_dio3_as_tcxo_ctrl( radio, tcxo_ctrl_voltage, timeout );

    TEST_ASSERT_EQUAL_UINT8( SX126X_STATUS_ERROR, status );
}
