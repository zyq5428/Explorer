/*!
 * \file      sx126x_regs.h
 *
 * \brief     SX126x registers definition
 *
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef __SX126X_REGS_H__
#define __SX126X_REGS_H__

/*!
 * The address of the register holding the first byte defining the CRC
 * seed
 */
#define SX126X_REG_CRCSEEDBASEADDR 0x06BC

/*!
 * The address of the register holding the first byte defining the CRC
 * polynomial
 */
#define SX126X_REG_CRCPOLYBASEADDR 0x06BE

/*!
 * The address of the register holding the first byte defining the
 * whitening seed
 */
#define SX126X_REG_WHITSEEDBASEADDR 0x06B8

/*!
 * The address of the register holding the packet configuration
 */
#define SX126X_REG_PACKETPARAMS 0x0704

/*!
 * The addresses of the registers holding SyncWords values
 */
#define SX126X_REG_SYNCWORDBASEADDRESS 0x06C0

/*!
 * The addresses of the register holding LoRa Modem SyncWord value
 *     0x1424: LoRaWAN private network,
 *     0x3444: LoRaWAN public network
 */
#define SX126X_REG_LR_SYNCWORD 0x0740

/*!
 * The address of the register giving a 4 bytes random number
 */
#define SX126X_REG_RNGBASEADDR 0x0819

/*!
 * The address of the register holding RX Gain value
 *     0x94: power saving,
 *     0x96: rx boosted
 */
#define SX126X_REG_RXGAIN 0x08AC

/*!
 * Change the value on the device internal trimming capacitor
 */
#define SX126X_REG_XTATRIM 0x0911

/*!
 * Set the current max value in the over current protection
 */
#define SX126X_REG_OCP 0x08E7

#endif  // __SX126X_REGS_H__
