/*!
 * \file      sx126x_bsp.h
 *
 * \brief     SX126x BSP functions to be implemented
 *
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef __SX126X_BSP_H__
#define __SX126X_BSP_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>

typedef enum sx126x_bsp_status_e
{
    SX126X_BSP_STATUS_OK    = 0,
    SX126X_BSP_STATUS_ERROR = 3,
} sx126x_bsp_status_t;

/*
 * ============================================================================
 * API definitions to be implemented by the user
 * ============================================================================
 */

/*!
 * Radio data transfer - write
 *
 * \remark Must be implemented by the upper layer
 * \remark Do not forget to call \ref sx126x_bsp_wakeup function at the very
 * beginning of the implementation.
 *
 * \param [in] context          Radio implementation parameters
 * \param [in] command          Pointer to the buffer to be transmitted
 * \param [in] command_length   Buffer size to be transmitted
 * \param [in] data             Pointer to the buffer to be transmitted
 * \param [in] data_length      Buffer size to be transmitted
 *
 * \retval status     Operation status
 */
sx126x_bsp_status_t sx126x_bsp_write( const void*    context,
                                      const uint8_t* command,
                                      const uint16_t command_length,
                                      const uint8_t* data,
                                      const uint16_t data_length );

/*!
 * Radio data transfer - read
 *
 * \remark Must be implemented by the upper layer
 * \remark Do not forget to call \ref sx126x_bsp_wakeup function at the very
 * beginning of the implementation.
 *
 * \param [in] context          Radio implementation parameters
 * \param [in] command          Pointer to the buffer to be transmitted
 * \param [in] command_length   Buffer size to be transmitted
 * \param [in] data             Pointer to the buffer to be received
 * \param [in] data_length      Buffer size to be received
 *
 * \retval status     Operation status
 */
sx126x_bsp_status_t sx126x_bsp_read( const void*    context,
                                     const uint8_t* command,
                                     const uint16_t command_length,
                                     uint8_t*       data,
                                     const uint16_t data_length );

/*!
 * Reset the radio
 *
 * \remark Must be implemented by the upper layer
 *
 * \param [in] context Radio implementation parameters
 */
void sx126x_bsp_reset( const void* context );

/*!
 * Wake the radio up.
 *
 * \remark Must be implemented by the upper layer
 *
 * \param [in] context Radio implementation parameters

 * \retval status    Operation status
 */
sx126x_bsp_status_t sx126x_bsp_wakeup( const void* context );

#ifdef __cplusplus
}
#endif

#endif  // __SX126X_BSP_H__
