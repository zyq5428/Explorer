/*!
 * \file      sx126x.c
 *
 * \brief     SX126x radio driver implementation
 *
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <string.h>  // memcpy
#include "sx126x_bsp.h"
#include "sx126x_regs.h"
#include "sx126x.h"

#if 0  // TODO: Implement fixed point computations
#define XTAL_FREQ 32000000u
#define XTAL_FREQ_STEP_DIV_POWER 25
#define FREQ_STEP_8 ( XTAL_FREQ >> ( XTAL_FREQ_STEP_DIV_POWER - 8 ) )  // 244

// Freq = channel * FREQ_STEP
#define SX_CHANNEL_TO_FREQ( channel, freq )                          \
    do                                                               \
    {                                                                \
        uint32_t initialChanInt, initialChanFrac;                    \
        initialChanInt  = channel >> 8;                              \
        initialChanFrac = channel - ( initialChanInt << 8 );         \
        freq            = initialChanInt * FREQ_STEP_8 +             \
               ( ( initialChanFrac * FREQ_STEP_8 + ( 128 ) ) >> 8 ); \
    } while( 0 )

// channel = Freq / FREQ_STEP
#define SX_FREQ_TO_CHANNEL( channel, freq )                              \
    do                                                                   \
    {                                                                    \
        uint32_t initialFreqInt, initialFreqFrac;                        \
        initialFreqInt  = freq / FREQ_STEP_8;                            \
        initialFreqFrac = freq - ( initialFreqInt * FREQ_STEP_8 );       \
        channel         = ( initialFreqInt << 8 ) +                      \
                  ( ( ( initialFreqFrac << 8 ) + ( FREQ_STEP_8 / 2 ) ) / \
                    FREQ_STEP_8 );                                       \
    } while( 0 )
#else

/*!
 *  Provides the frequency of the chip running on the radio and the
 * frequency step
 *
 * \remark These defines are used for computing the frequency divider to set the
 * RF frequency
 */
#define XTAL_FREQ ( 32000000.0f )
#define FREQ_DIV ( double ) ( 1 << 25 )
#define FREQ_STEP ( double ) ( XTAL_FREQ / FREQ_DIV )

#endif

/*!
 * Commands Interface
 */
typedef enum sx126x_commands_e
{
    // Operational Modes Functions
    SX126X_SET_SLEEP                = 0x84,
    SX126X_SET_STANDBY              = 0x80,
    SX126X_SET_FS                   = 0xC1,
    SX126X_SET_TX                   = 0x83,
    SX126X_SET_RX                   = 0x82,
    SX126X_SET_STOPTIMERONPREAMBLE  = 0x9F,
    SX126X_SET_RXDUTYCYCLE          = 0x94,
    SX126X_SET_CAD                  = 0xC5,
    SX126X_SET_TXCONTINUOUSWAVE     = 0xD1,
    SX126X_SET_TXCONTINUOUSPREAMBLE = 0xD2,
    SX126X_SET_REGULATORMODE        = 0x96,
    SX126X_CALIBRATE                = 0x89,
    SX126X_CALIBRATEIMAGE           = 0x98,
    SX126X_SET_PACONFIG             = 0x95,
    SX126X_SET_RXTXFALLBACKMODE     = 0x93,
    // Registers and buffer Access
    SX126X_WRITE_REGISTER = 0x0D,
    SX126X_READ_REGISTER  = 0x1D,
    SX126X_WRITE_BUFFER   = 0x0E,
    SX126X_READ_BUFFER    = 0x1E,
    // DIO and IRQ Control Functions
    SX126X_SET_DIOIRQPARAMS       = 0x08,
    SX126X_GET_IRQSTATUS          = 0x12,
    SX126X_CLR_IRQSTATUS          = 0x02,
    SX126X_SET_DIO2ASRFSWITCHCTRL = 0x9D,
    SX126X_SET_DIO3ASTCXOCTRL     = 0x97,
    // RF Modulation and Packet-Related Functions
    SX126X_SET_RFFREQUENCY        = 0x86,
    SX126X_SET_PACKETTYPE         = 0x8A,
    SX126X_GET_PACKETTYPE         = 0x11,
    SX126X_SET_TXPARAMS           = 0x8E,
    SX126X_SET_MODULATIONPARAMS   = 0x8B,
    SX126X_SET_PACKETPARAMS       = 0x8C,
    SX126X_SET_CADPARAMS          = 0x88,
    SX126X_SET_BUFFERBASEADDRESS  = 0x8F,
    SX126X_SET_LORASYMBNUMTIMEOUT = 0xA0,
    // Communication Status Information
    SX126X_GET_STATUS         = 0xC0,
    SX126X_GET_RXBUFFERSTATUS = 0x13,
    SX126X_GET_PACKETSTATUS   = 0x14,
    SX126X_GET_RSSIINST       = 0x15,
    SX126X_GET_STATS          = 0x10,
    SX126X_RESET_STATS        = 0x00,
    // Miscellaneous
    SX126X_GET_DEVICEERRORS = 0x17,
    SX126X_CLR_DEVICEERRORS = 0x07,
} sx126x_commands_t;

/*!
 * Commands Interface buffer sizes
 */
typedef enum sx126x_commands_size_e
{
    // Operational Modes Functions
    SX126X_SIZE_SET_SLEEP                = 2,
    SX126X_SIZE_SET_STANDBY              = 2,
    SX126X_SIZE_SET_FS                   = 1,
    SX126X_SIZE_SET_TX                   = 4,
    SX126X_SIZE_SET_RX                   = 4,
    SX126X_SIZE_SET_STOPTIMERONPREAMBLE  = 2,
    SX126X_SIZE_SET_RXDUTYCYCLE          = 7,
    SX126X_SIZE_SET_CAD                  = 1,
    SX126X_SIZE_SET_TXCONTINUOUSWAVE     = 1,
    SX126X_SIZE_SET_TXCONTINUOUSPREAMBLE = 1,
    SX126X_SIZE_SET_REGULATORMODE        = 2,
    SX126X_SIZE_CALIBRATE                = 2,
    SX126X_SIZE_CALIBRATEIMAGE           = 3,
    SX126X_SIZE_SET_PACONFIG             = 5,
    SX126X_SIZE_SET_RXTXFALLBACKMODE     = 2,
    // Registers and buffer Access
    // Full size: this value plus buffer size
    SX126X_SIZE_WRITE_REGISTER = 3,
    // Full size: this value plus buffer size
    SX126X_SIZE_READ_REGISTER = 4,
    // Full size: this value plus buffer size
    SX126X_SIZE_WRITE_BUFFER = 2,
    // Full size: this value plus buffer size
    SX126X_SIZE_READ_BUFFER = 3,
    // DIO and IRQ Control Functions
    SX126X_SIZE_SET_DIOIRQPARAMS       = 9,
    SX126X_SIZE_GET_IRQSTATUS          = 2,
    SX126X_SIZE_CLR_IRQSTATUS          = 3,
    SX126X_SIZE_SET_DIO2ASRFSWITCHCTRL = 2,
    SX126X_SIZE_SET_DIO3ASTCXOCTRL     = 5,
    // RF Modulation and Packet-Related Functions
    SX126X_SIZE_SET_RFFREQUENCY           = 5,
    SX126X_SIZE_SET_PACKETTYPE            = 2,
    SX126X_SIZE_GET_PACKETTYPE            = 3,
    SX126X_SIZE_SET_TXPARAMS              = 3,
    SX126X_SIZE_SET_MODULATIONPARAMS_GFSK = 9,
    SX126X_SIZE_SET_MODULATIONPARAMS_LORA = 5,
    SX126X_SIZE_SET_PACKETPARAMS_GFSK     = 10,
    SX126X_SIZE_SET_PACKETPARAMS_LORA     = 7,
    SX126X_SIZE_SET_CADPARAMS             = 8,
    SX126X_SIZE_SET_BUFFERBASEADDRESS     = 3,
    SX126X_SIZE_SET_LORASYMBNUMTIMEOUT    = 2,
    // Communication Status Information
    SX126X_SIZE_GET_STATUS         = 1,
    SX126X_SIZE_GET_RXBUFFERSTATUS = 2,
    SX126X_SIZE_GET_PACKETSTATUS   = 2,
    SX126X_SIZE_GET_RSSIINST       = 2,
    SX126X_SIZE_GET_STATS          = 2,
    SX126X_SIZE_RESET_STATS        = 7,
    // Miscellaneous
    SX126X_SIZE_GET_DEVICEERRORS = 2,
    SX126X_SIZE_CLR_DEVICEERRORS = 3,
    SX126X_SIZE_MAX_BUFFER       = 255,
    SX126X_SIZE_DUMMY_BYTE       = 1,
} sx126x_commands_size_t;

typedef struct
{
    uint32_t bw;
    uint8_t  param;
} gfsk_bw_t;

gfsk_bw_t gfsk_bw[] = {
    { 4800, SX126X_GFSK_BW_4800 },     { 5800, SX126X_GFSK_BW_5800 },
    { 7300, SX126X_GFSK_BW_7300 },     { 9700, SX126X_GFSK_BW_9700 },
    { 11700, SX126X_GFSK_BW_11700 },   { 14600, SX126X_GFSK_BW_14600 },
    { 19500, SX126X_GFSK_BW_19500 },   { 23400, SX126X_GFSK_BW_23400 },
    { 29300, SX126X_GFSK_BW_29300 },   { 39000, SX126X_GFSK_BW_39000 },
    { 46900, SX126X_GFSK_BW_46900 },   { 58600, SX126X_GFSK_BW_58600 },
    { 78200, SX126X_GFSK_BW_78200 },   { 93800, SX126X_GFSK_BW_93800 },
    { 117300, SX126X_GFSK_BW_117300 }, { 156200, SX126X_GFSK_BW_156200 },
    { 187200, SX126X_GFSK_BW_187200 }, { 234300, SX126X_GFSK_BW_234300 },
    { 312000, SX126X_GFSK_BW_312000 }, { 373600, SX126X_GFSK_BW_373600 },
    { 467000, SX126X_GFSK_BW_467000 },
};

sx126x_status_t sx126x_set_sleep( const void*              context,
                                  const sx126x_sleep_cfg_t cfg )
{
    uint8_t buf[SX126X_SIZE_SET_SLEEP] = { 0 };

    buf[0] = SX126X_SET_SLEEP;

    buf[1] = ( uint8_t ) cfg;

    return ( sx126x_status_t ) sx126x_bsp_write( context, buf,
                                                 SX126X_SIZE_SET_SLEEP, 0, 0 );
}

sx126x_status_t sx126x_set_standby( const void*                context,
                                    const sx126x_standby_cfg_t cfg )
{
    uint8_t buf[SX126X_SIZE_SET_STANDBY] = { 0 };

    buf[0] = SX126X_SET_STANDBY;

    buf[1] = ( uint8_t ) cfg;

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_STANDBY, 0, 0 );
}

sx126x_status_t sx126x_set_fs( const void* context )
{
    uint8_t buf[SX126X_SIZE_SET_FS] = { 0 };

    buf[0] = SX126X_SET_FS;

    return ( sx126x_status_t ) sx126x_bsp_write( context, buf,
                                                 SX126X_SIZE_SET_FS, 0, 0 );
}

sx126x_status_t sx126x_set_tx( const void* context, const uint32_t timeout )
{
    uint8_t buf[SX126X_SIZE_SET_TX] = { 0 };

    buf[0] = SX126X_SET_TX;

    buf[1] = ( uint8_t )( timeout >> 16 );
    buf[2] = ( uint8_t )( timeout >> 8 );
    buf[3] = ( uint8_t )( timeout >> 0 );

    return ( sx126x_status_t ) sx126x_bsp_write( context, buf,
                                                 SX126X_SIZE_SET_TX, 0, 0 );
}

sx126x_status_t sx126x_set_rx( const void* context, const uint32_t timeout )
{
    uint8_t buf[SX126X_SIZE_SET_RX] = { 0 };

    buf[0] = SX126X_SET_RX;

    buf[1] = ( uint8_t )( timeout >> 16 );
    buf[2] = ( uint8_t )( timeout >> 8 );
    buf[3] = ( uint8_t )( timeout >> 0 );

    return ( sx126x_status_t ) sx126x_bsp_write( context, buf,
                                                 SX126X_SIZE_SET_RX, 0, 0 );
}

sx126x_status_t sx126x_stop_tmr_on_pbl( const void* context, const bool enable )
{
    uint8_t buf[SX126X_SIZE_SET_STOPTIMERONPREAMBLE] = { 0 };

    buf[0] = SX126X_SET_STOPTIMERONPREAMBLE;

    buf[1] = ( enable == true ) ? 1 : 0;

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_STOPTIMERONPREAMBLE, 0, 0 );
}

sx126x_status_t sx126x_set_rx_duty_cycle( const void*    context,
                                          const uint32_t rx_time,
                                          const uint32_t sleep_time )
{
    uint8_t buf[SX126X_SIZE_SET_RXDUTYCYCLE] = { 0 };

    buf[0] = SX126X_SET_RXDUTYCYCLE;

    buf[1] = ( uint8_t )( rx_time >> 16 );
    buf[2] = ( uint8_t )( rx_time >> 8 );
    buf[3] = ( uint8_t )( rx_time >> 0 );

    buf[4] = ( uint8_t )( sleep_time >> 16 );
    buf[5] = ( uint8_t )( sleep_time >> 8 );
    buf[6] = ( uint8_t )( sleep_time >> 0 );

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_RXDUTYCYCLE, 0, 0 );
}

sx126x_status_t sx126x_set_cad( const void* context )
{
    uint8_t buf[SX126X_SIZE_SET_CAD] = { 0 };

    buf[0] = SX126X_SET_CAD;

    return ( sx126x_status_t ) sx126x_bsp_write( context, buf,
                                                 SX126X_SIZE_SET_CAD, 0, 0 );
}

sx126x_status_t sx126x_set_tx_cw( const void* context )
{
    uint8_t buf[SX126X_SIZE_SET_TXCONTINUOUSWAVE] = { 0 };

    buf[0] = SX126X_SET_TXCONTINUOUSWAVE;

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_TXCONTINUOUSWAVE, 0, 0 );
}

sx126x_status_t sx126x_set_tx_cpbl( const void* context )
{
    uint8_t buf[SX126X_SIZE_SET_TXCONTINUOUSPREAMBLE] = { 0 };

    buf[0] = SX126X_SET_TXCONTINUOUSPREAMBLE;

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_TXCONTINUOUSPREAMBLE, 0, 0 );
}

sx126x_status_t sx126x_set_reg_mode( const void*            context,
                                     const sx126x_reg_mod_t mode )
{
    uint8_t buf[SX126X_SIZE_SET_REGULATORMODE] = { 0 };

    buf[0] = SX126X_SET_REGULATORMODE;

    buf[1] = ( uint8_t ) mode;

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_REGULATORMODE, 0, 0 );
}

sx126x_status_t sx126x_cal( const void* context, const sx126x_cal_mask_t param )
{
    uint8_t buf[SX126X_SIZE_CALIBRATE] = { 0 };

    buf[0] = SX126X_CALIBRATE;

    buf[1] = param;

    return ( sx126x_status_t ) sx126x_bsp_write( context, buf,
                                                 SX126X_SIZE_CALIBRATE, 0, 0 );
}

sx126x_status_t sx126x_cal_img( const void* context, const uint32_t freq_in_hz )
{
    uint8_t buf[SX126X_SIZE_CALIBRATEIMAGE] = { 0 };

    buf[0] = SX126X_CALIBRATEIMAGE;

    if( freq_in_hz > 900000000 )
    {
        buf[1] = 0xE1;
        buf[2] = 0xE9;
    }
    else if( freq_in_hz > 850000000 )
    {
        buf[1] = 0xD7;
        buf[2] = 0xDB;
    }
    else if( freq_in_hz > 770000000 )
    {
        buf[1] = 0xC1;
        buf[2] = 0xC5;
    }
    else if( freq_in_hz > 460000000 )
    {
        buf[1] = 0x75;
        buf[2] = 0x81;
    }
    else
    {
        buf[1] = 0x6B;
        buf[2] = 0x6F;
    }

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_CALIBRATEIMAGE, 0, 0 );
}

sx126x_status_t sx126x_set_pa_cfg( const void*                   context,
                                   const sx126x_pa_cfg_params_t* params )
{
    uint8_t buf[SX126X_SIZE_SET_PACONFIG] = { 0 };

    buf[0] = SX126X_SET_PACONFIG;

    buf[1] = params->pa_duty_cycle;
    buf[2] = params->hp_max;
    buf[3] = params->device_sel;
    buf[4] = params->pa_lut;

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_PACONFIG, 0, 0 );
}

sx126x_status_t sx126x_set_rx_tx_fallback_mode(
    const void* context, const sx126x_fallback_modes_t fallback_mode )
{
    uint8_t buf[SX126X_SIZE_SET_RXTXFALLBACKMODE] = { 0 };

    buf[0] = SX126X_SET_RXTXFALLBACKMODE;

    buf[1] = ( uint8_t ) fallback_mode;

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_RXTXFALLBACKMODE, 0, 0 );
}

//
// Registers and buffer Access
//

sx126x_status_t sx126x_write_register( const void* context, const uint16_t addr,
                                       const uint8_t* buffer,
                                       const uint8_t  size )
{
    uint8_t buf[SX126X_SIZE_WRITE_REGISTER] = { 0 };

    buf[0] = SX126X_WRITE_REGISTER;

    buf[1] = ( uint8_t )( addr >> 8 );
    buf[2] = ( uint8_t )( addr >> 0 );

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_WRITE_REGISTER, buffer, size );
}

sx126x_status_t sx126x_read_register( const void* context, const uint16_t addr,
                                      uint8_t* buffer, const uint8_t size )
{
    uint8_t         buf[SX126X_SIZE_READ_REGISTER] = { 0 };
    sx126x_status_t status                         = SX126X_STATUS_ERROR;

    buf[0] = SX126X_READ_REGISTER;

    buf[1] = ( uint8_t )( addr >> 8 );
    buf[2] = ( uint8_t )( addr >> 0 );

    status = ( sx126x_status_t ) sx126x_bsp_read(
        context, buf, SX126X_SIZE_READ_REGISTER, buffer, size );

    return status;
}

sx126x_status_t sx126x_write_buffer( const void* context, const uint8_t offset,
                                     const uint8_t* buffer, const uint8_t size )
{
    uint8_t buf[SX126X_SIZE_WRITE_BUFFER] = { 0 };

    buf[0] = SX126X_WRITE_BUFFER;

    buf[1] = offset;

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_WRITE_BUFFER, buffer, size );
}

sx126x_status_t sx126x_read_buffer( const void* context, const uint8_t offset,
                                    uint8_t* buffer, const uint8_t size )
{
    uint8_t         buf[SX126X_SIZE_READ_BUFFER] = { 0 };
    sx126x_status_t status                       = SX126X_STATUS_ERROR;

    buf[0] = SX126X_READ_BUFFER;

    buf[1] = offset;

    status = ( sx126x_status_t ) sx126x_bsp_read(
        context, buf, SX126X_SIZE_READ_BUFFER, buffer, size );

    return status;
}

//
// DIO and IRQ Control Functions
//
sx126x_status_t sx126x_set_dio_irq_params( const void*    context,
                                           const uint16_t irq_mask,
                                           const uint16_t dio1_mask,
                                           const uint16_t dio2_mask,
                                           const uint16_t dio3_mask )
{
    uint8_t buf[SX126X_SIZE_SET_DIOIRQPARAMS] = { 0 };

    buf[0] = SX126X_SET_DIOIRQPARAMS;

    buf[1] = ( uint8_t )( irq_mask >> 8 );
    buf[2] = ( uint8_t )( irq_mask >> 0 );

    buf[3] = ( uint8_t )( dio1_mask >> 8 );
    buf[4] = ( uint8_t )( dio1_mask >> 0 );

    buf[5] = ( uint8_t )( dio2_mask >> 8 );
    buf[6] = ( uint8_t )( dio2_mask >> 0 );

    buf[7] = ( uint8_t )( dio3_mask >> 8 );
    buf[8] = ( uint8_t )( dio3_mask >> 0 );

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_DIOIRQPARAMS, 0, 0 );
}

sx126x_status_t sx126x_get_irq_status( const void*        context,
                                       sx126x_irq_mask_t* irq )
{
    uint8_t         buf[SX126X_SIZE_GET_IRQSTATUS]         = { 0 };
    uint8_t         irq_local[sizeof( sx126x_irq_mask_t )] = { 0x00 };
    sx126x_status_t status = SX126X_STATUS_ERROR;

    buf[0] = SX126X_GET_IRQSTATUS;

    status = ( sx126x_status_t ) sx126x_bsp_read(
        context, buf, SX126X_SIZE_GET_IRQSTATUS, irq_local,
        sizeof( sx126x_irq_mask_t ) );

    if( status == SX126X_STATUS_OK )
    {
        *irq = ( ( sx126x_irq_mask_t ) irq_local[0] << 8 ) +
               ( ( sx126x_irq_mask_t ) irq_local[1] << 0 );
    }

    return status;
}

sx126x_status_t sx126x_clear_irq_status( const void*             context,
                                         const sx126x_irq_mask_t irq_mask )
{
    uint8_t buf[SX126X_SIZE_CLR_IRQSTATUS] = { 0 };

    buf[0] = SX126X_CLR_IRQSTATUS;

    buf[1] = ( uint8_t )( irq_mask >> 8 );
    buf[2] = ( uint8_t )( irq_mask >> 0 );

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_CLR_IRQSTATUS, 0, 0 );
}

sx126x_status_t sx126x_set_dio2_as_rf_sw_ctrl( const void* context,
                                               const bool  enable )
{
    uint8_t buf[SX126X_SIZE_SET_DIO2ASRFSWITCHCTRL] = { 0 };

    buf[0] = SX126X_SET_DIO2ASRFSWITCHCTRL;

    buf[1] = ( enable == true ) ? 1 : 0;

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_DIO2ASRFSWITCHCTRL, 0, 0 );
}

sx126x_status_t sx126x_set_dio3_as_tcxo_ctrl(
    const void* context, const sx126x_tcxo_ctrl_voltages_t tcxo_voltage,
    const uint32_t timeout )
{
    uint8_t buf[SX126X_SIZE_SET_DIO3ASTCXOCTRL] = { 0 };

    buf[0] = SX126X_SET_DIO3ASTCXOCTRL;

    buf[1] = ( uint8_t ) tcxo_voltage;

    buf[2] = ( uint8_t )( timeout >> 16 );
    buf[3] = ( uint8_t )( timeout >> 8 );
    buf[4] = ( uint8_t )( timeout >> 0 );

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_DIO3ASTCXOCTRL, 0, 0 );
}

//
// RF Modulation and Packet-Related Functions
//

sx126x_status_t sx126x_set_rf_freq( const void*    context,
                                    const uint32_t freq_in_hz )
{
    uint8_t  buf[SX126X_SIZE_SET_RFFREQUENCY] = { 0 };
    uint32_t freq =
        ( uint32_t )( ( double ) freq_in_hz / ( double ) FREQ_STEP );

    buf[0] = SX126X_SET_RFFREQUENCY;

    buf[1] = ( uint8_t )( freq >> 24 );
    buf[2] = ( uint8_t )( freq >> 16 );
    buf[3] = ( uint8_t )( freq >> 8 );
    buf[4] = ( uint8_t )( freq >> 0 );

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_RFFREQUENCY, 0, 0 );
}

sx126x_status_t sx126x_set_pkt_type( const void*             context,
                                     const sx126x_pkt_type_t pkt_type )
{
    uint8_t buf[SX126X_SIZE_SET_PACKETTYPE] = { 0 };

    buf[0] = SX126X_SET_PACKETTYPE;

    buf[1] = ( uint8_t ) pkt_type;

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_PACKETTYPE, 0, 0 );
}

sx126x_status_t sx126x_get_pkt_type( const void*        context,
                                     sx126x_pkt_type_t* pkt_type )
{
    uint8_t         buf[SX126X_SIZE_GET_PACKETTYPE] = { 0 };
    sx126x_status_t status                          = SX126X_STATUS_ERROR;

    buf[0] = SX126X_GET_PACKETTYPE;

    status = ( sx126x_status_t ) sx126x_bsp_read(
        context, buf, SX126X_SIZE_GET_PACKETTYPE, ( uint8_t* ) pkt_type, 1 );

    return status;
}

sx126x_status_t sx126x_set_tx_params( const void*              context,
                                      const int8_t             pwr_in_dbm,
                                      const sx126x_ramp_time_t ramp_time )
{
    uint8_t buf[SX126X_SIZE_SET_TXPARAMS] = { 0 };

    buf[0] = SX126X_SET_TXPARAMS;

    buf[1] = ( uint8_t ) pwr_in_dbm;
    buf[2] = ( uint8_t ) ramp_time;

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_TXPARAMS, 0, 0 );
}

sx126x_status_t sx126x_set_gfsk_mod_params(
    const void* context, const sx126x_mod_params_gfsk_t* params )
{
    uint8_t  buf[SX126X_SIZE_SET_MODULATIONPARAMS_GFSK] = { 0 };
    uint32_t bitrate                                    = ( uint32_t )(
        32 * ( ( double ) XTAL_FREQ / ( double ) params->br_in_bps ) );
    uint32_t fdev =
        ( uint32_t )( ( double ) params->fdev_in_hz / ( double ) FREQ_STEP );

    buf[0] = SX126X_SET_MODULATIONPARAMS;

    buf[1] = ( uint8_t )( bitrate >> 16 );
    buf[2] = ( uint8_t )( bitrate >> 8 );
    buf[3] = ( uint8_t )( bitrate >> 0 );

    buf[4] = ( uint8_t )( params->mod_shape );

    buf[5] = params->bw_dsb_param;

    buf[6] = ( uint8_t )( fdev >> 16 );
    buf[7] = ( uint8_t )( fdev >> 8 );
    buf[8] = ( uint8_t )( fdev >> 0 );

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_MODULATIONPARAMS_GFSK, 0, 0 );
}

sx126x_status_t sx126x_set_lora_mod_params(
    const void* context, const sx126x_mod_params_lora_t* params )
{
    uint8_t buf[SX126X_SIZE_SET_MODULATIONPARAMS_LORA] = { 0 };

    buf[0] = SX126X_SET_MODULATIONPARAMS;

    buf[1] = ( uint8_t )( params->sf );
    buf[2] = ( uint8_t )( params->bw );
    buf[3] = ( uint8_t )( params->cr );
    buf[4] = params->ldro & 0x01;

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_MODULATIONPARAMS_LORA, 0, 0 );
}

sx126x_status_t sx126x_set_gfsk_pkt_params(
    const void* context, const sx126x_pkt_params_gfsk_t* params )
{
    uint8_t buf[SX126X_SIZE_SET_PACKETPARAMS_GFSK] = { 0 };

    buf[0] = SX126X_SET_PACKETPARAMS;

    buf[1] = ( uint8_t )( params->pbl_len_in_bits >> 8 );
    buf[2] = ( uint8_t )( params->pbl_len_in_bits >> 0 );
    buf[3] = ( uint8_t )( params->pbl_min_det );
    buf[4] = params->sync_word_len_in_bits;
    buf[5] = ( uint8_t )( params->addr_cmp );
    buf[6] = ( uint8_t )( params->hdr_type );
    buf[7] = params->pld_len_in_bytes;
    buf[8] = ( uint8_t )( params->crc_type );
    buf[9] = ( uint8_t )( params->dc_free );

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_PACKETPARAMS_GFSK, 0, 0 );
}

sx126x_status_t sx126x_set_lora_pkt_params(
    const void* context, const sx126x_pkt_params_lora_t* params )
{
    uint8_t buf[SX126X_SIZE_SET_PACKETPARAMS_LORA] = { 0 };

    buf[0] = SX126X_SET_PACKETPARAMS;

    buf[1] = ( uint8_t )( params->pbl_len_in_symb >> 8 );
    buf[2] = ( uint8_t )( params->pbl_len_in_symb >> 0 );
    buf[3] = ( uint8_t )( params->hdr_type );
    buf[4] = params->pld_len_in_bytes;
    buf[5] = ( uint8_t )( params->crc_is_on ? 1 : 0 );
    buf[6] = ( uint8_t )( params->invert_iq_is_on ? 1 : 0 );

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_PACKETPARAMS_LORA, 0, 0 );
}

sx126x_status_t sx126x_set_cad_params( const void*                     context,
                                       const sx126x_lora_cad_params_t* params )
{
    uint8_t buf[SX126X_SIZE_SET_CADPARAMS] = { 0 };

    buf[0] = SX126X_SET_CADPARAMS;

    buf[1] = ( uint8_t ) params->cad_symb_nb;
    buf[2] = params->cad_det_peak;
    buf[3] = params->cad_det_min;
    buf[4] = ( uint8_t ) params->cad_exit_mode;
    buf[5] = ( uint8_t )( params->cad_timeout >> 16 );
    buf[6] = ( uint8_t )( params->cad_timeout >> 8 );
    buf[7] = ( uint8_t )( params->cad_timeout >> 0 );

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_CADPARAMS, 0, 0 );
}

sx126x_status_t sx126x_set_buffer_base_addr( const void*   context,
                                             const uint8_t tx_base_addr,
                                             const uint8_t rx_base_addr )
{
    uint8_t buf[SX126X_SIZE_SET_BUFFERBASEADDRESS] = { 0 };

    buf[0] = SX126X_SET_BUFFERBASEADDRESS;

    buf[1] = tx_base_addr;
    buf[2] = rx_base_addr;

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_BUFFERBASEADDRESS, 0, 0 );
}

sx126x_status_t sx126x_set_lora_symb_nb_timeout( const void*   context,
                                                 const uint8_t nb_of_symbs )
{
    uint8_t buf[SX126X_SIZE_SET_LORASYMBNUMTIMEOUT] = { 0 };

    buf[0] = SX126X_SET_LORASYMBNUMTIMEOUT;

    buf[1] = nb_of_symbs;

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_SET_LORASYMBNUMTIMEOUT, 0, 0 );
}

//
// Communication Status Information
//

sx126x_status_t sx126x_get_status( const void*           context,
                                   sx126x_chip_status_t* radio_status )
{
    uint8_t         buf[SX126X_SIZE_GET_STATUS] = { 0 };
    uint8_t         status_local                = 0;
    sx126x_status_t status                      = SX126X_STATUS_ERROR;

    buf[0] = SX126X_GET_STATUS;

    status = ( sx126x_status_t ) sx126x_bsp_read(
        context, buf, SX126X_SIZE_GET_STATUS, &status_local, 1 );

    if( status == SX126X_STATUS_OK )
    {
        radio_status->cmd_status =
            ( status_local >> SX126X_CMD_STATUS_POS ) & SX126X_CMD_STATUS_MASK;
        radio_status->chip_mode =
            ( status_local >> SX126X_CHIP_MODES_POS ) & SX126X_CHIP_MODES_MASK;
    }

    return status;
}

sx126x_status_t sx126x_get_rx_buffer_status(
    const void* context, sx126x_rx_buffer_status_t* rx_buffer_status )
{
    uint8_t buf[SX126X_SIZE_GET_RXBUFFERSTATUS]               = { 0 };
    uint8_t status_local[sizeof( sx126x_rx_buffer_status_t )] = { 0x00 };
    sx126x_status_t status = SX126X_STATUS_ERROR;

    buf[0] = SX126X_GET_RXBUFFERSTATUS;

    status = ( sx126x_status_t ) sx126x_bsp_read(
        context, buf, SX126X_SIZE_GET_RXBUFFERSTATUS, status_local,
        sizeof( sx126x_rx_buffer_status_t ) );

    if( status == SX126X_STATUS_OK )
    {
        rx_buffer_status->pld_len_in_bytes     = status_local[0];
        rx_buffer_status->buffer_start_pointer = status_local[1];
    }

    return status;
}

sx126x_status_t sx126x_get_gfsk_pkt_status(
    const void* context, sx126x_pkt_status_gfsk_t* pkt_status )
{
    uint8_t buf[SX126X_SIZE_GET_PACKETSTATUS]                    = { 0 };
    uint8_t pkt_status_local[sizeof( sx126x_pkt_status_gfsk_t )] = { 0x00 };
    sx126x_status_t status = SX126X_STATUS_ERROR;

    buf[0] = SX126X_GET_PACKETSTATUS;

    status = ( sx126x_status_t ) sx126x_bsp_read(
        context, buf, SX126X_SIZE_GET_PACKETSTATUS, pkt_status_local,
        sizeof( sx126x_pkt_status_gfsk_t ) );

    if( status == SX126X_STATUS_OK )
    {
        pkt_status->rx_status = pkt_status_local[0];
        pkt_status->rssi_sync = ( int8_t )( -pkt_status_local[1] >> 1 );
        pkt_status->rssi_avg  = ( int8_t )( -pkt_status_local[2] >> 1 );
    }

    return status;
}

sx126x_status_t sx126x_get_lora_pkt_status(
    const void* context, sx126x_pkt_status_lora_t* pkt_status )
{
    uint8_t buf[SX126X_SIZE_GET_PACKETSTATUS]                    = { 0 };
    uint8_t pkt_status_local[sizeof( sx126x_pkt_status_lora_t )] = { 0x00 };
    sx126x_status_t status = SX126X_STATUS_ERROR;

    buf[0] = SX126X_GET_PACKETSTATUS;

    status = ( sx126x_status_t ) sx126x_bsp_read(
        context, buf, SX126X_SIZE_GET_PACKETSTATUS, pkt_status_local,
        sizeof( sx126x_pkt_status_lora_t ) );

    if( status == SX126X_STATUS_OK )
    {
        pkt_status->rssi_pkt = ( int8_t )( -pkt_status_local[0] >> 1 );
        pkt_status->snr_pkt  = ( ( ( int8_t ) pkt_status_local[1] ) + 2 ) >> 2;
        pkt_status->signal_rssi_pkt = ( int8_t )( -pkt_status_local[2] >> 1 );
    }

    return status;
}

sx126x_status_t sx126x_get_rssi_inst( const void* context,
                                      int16_t*    rssi_in_dbm )
{
    uint8_t         buf[SX126X_SIZE_GET_RSSIINST] = { 0 };
    uint8_t         rssi_local                    = 0x00;
    sx126x_status_t status                        = SX126X_STATUS_ERROR;

    buf[0] = SX126X_GET_RSSIINST;

    status = ( sx126x_status_t ) sx126x_bsp_read(
        context, buf, SX126X_SIZE_GET_RSSIINST, &rssi_local, 1 );

    if( status == SX126X_STATUS_OK )
    {
        // buf[0] is dummy, buf[1] is status
        *rssi_in_dbm = ( int8_t )( -rssi_local >> 1 );
    }

    return status;
}

sx126x_status_t sx126x_get_gfsk_stats( const void*          context,
                                       sx126x_stats_gfsk_t* stats )
{
    uint8_t         buf[SX126X_SIZE_GET_STATS]                 = { 0 };
    uint8_t         stats_local[sizeof( sx126x_stats_gfsk_t )] = { 0 };
    sx126x_status_t status = SX126X_STATUS_ERROR;

    buf[0] = SX126X_GET_STATS;

    status = ( sx126x_status_t ) sx126x_bsp_read(
        context, buf, SX126X_SIZE_GET_STATS, stats_local,
        sizeof( sx126x_stats_gfsk_t ) );

    if( status == SX126X_STATUS_OK )
    {
        stats->nb_pkt_received =
            ( ( uint16_t ) stats_local[0] << 8 ) + ( uint16_t ) stats_local[1];
        stats->nb_pkt_crc_error =
            ( ( uint16_t ) stats_local[2] << 8 ) + ( uint16_t ) stats_local[3];
        stats->nb_pkt_len_error =
            ( ( uint16_t ) stats_local[4] << 8 ) + ( uint16_t ) stats_local[5];
    }

    return status;
}

sx126x_status_t sx126x_get_lora_stats( const void*          context,
                                       sx126x_stats_lora_t* stats )
{
    uint8_t         buf[SX126X_SIZE_GET_STATS]                 = { 0 };
    uint8_t         stats_local[sizeof( sx126x_stats_lora_t )] = { 0 };
    sx126x_status_t status = SX126X_STATUS_ERROR;

    buf[0] = SX126X_GET_STATS;

    status = ( sx126x_status_t ) sx126x_bsp_read(
        context, buf, SX126X_SIZE_GET_STATS, stats_local,
        sizeof( sx126x_stats_lora_t ) );

    if( status == SX126X_STATUS_OK )
    {
        // buf[0] is dummy, buf[1] is status
        stats->nb_pkt_received =
            ( ( uint16_t ) stats_local[0] << 8 ) + ( uint16_t ) stats_local[1];
        stats->nb_pkt_crc_error =
            ( ( uint16_t ) stats_local[2] << 8 ) + ( uint16_t ) stats_local[3];
        stats->nb_pkt_hdr_error =
            ( ( uint16_t ) stats_local[4] << 8 ) + ( uint16_t ) stats_local[5];
    }
    return status;
}

sx126x_status_t sx126x_reset_stats( const void* context )
{
    uint8_t buf[SX126X_SIZE_RESET_STATS] = { 0 };

    buf[0] = SX126X_RESET_STATS;

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_RESET_STATS, 0, 0 );
}

//
// Miscellaneous
//

sx126x_status_t sx126x_reset( const void* context )
{
    sx126x_bsp_reset( context );

    return SX126X_STATUS_OK;
}

sx126x_status_t sx126x_wakeup( const void* context )
{
    sx126x_bsp_wakeup( context );

    return SX126X_STATUS_OK;
}

sx126x_status_t sx126x_get_device_errors( const void*           context,
                                          sx126x_errors_mask_t* errors )
{
    uint8_t         buf[SX126X_SIZE_GET_DEVICEERRORS]            = { 0 };
    uint8_t         errors_local[sizeof( sx126x_errors_mask_t )] = { 0x00 };
    sx126x_status_t status = SX126X_STATUS_ERROR;

    buf[0] = SX126X_GET_DEVICEERRORS;

    status = ( sx126x_status_t ) sx126x_bsp_read(
        context, buf, SX126X_SIZE_GET_DEVICEERRORS, errors_local,
        sizeof( sx126x_errors_mask_t ) );

    if( status == SX126X_STATUS_OK )
    {
        *errors = ( ( sx126x_errors_mask_t ) errors_local[0] << 8 ) +
                  ( ( sx126x_errors_mask_t ) errors_local[1] << 0 );
    }

    return status;
}

sx126x_status_t sx126x_clear_device_errors( const void* context )
{
    uint8_t buf[SX126X_SIZE_CLR_DEVICEERRORS] = { 0 };

    buf[0] = SX126X_CLR_DEVICEERRORS;

    return ( sx126x_status_t ) sx126x_bsp_write(
        context, buf, SX126X_SIZE_CLR_DEVICEERRORS, 0, 0 );
}

sx126x_status_t sx126x_get_gfsk_bw_param( const uint32_t bw, uint8_t* param )
{
    sx126x_status_t status = SX126X_STATUS_ERROR;

    if( bw != 0 )
    {
        status = SX126X_STATUS_UNKNOWN_VALUE;
        for( uint8_t i = 0; i < ( sizeof( gfsk_bw ) / sizeof( gfsk_bw_t ) );
             i++ )
        {
            if( bw <= gfsk_bw[i].bw )
            {
                *param = gfsk_bw[i].param;
                status = SX126X_STATUS_OK;
                break;
            }
        }
    }

    return status;
}

uint32_t sx126x_get_lora_time_on_air_numerator(
    const sx126x_pkt_params_lora_t* pkt_p,
    const sx126x_mod_params_lora_t* mod_p )
{
    const int32_t pld_len_in_bytes = pkt_p->pld_len_in_bytes;
    const int32_t SF               = mod_p->sf;
    const bool    pld_is_fix = pkt_p->hdr_type == SX126X_LORA_PKT_IMPLICIT;
    const int32_t CR_denom   = mod_p->cr + 4;

    int32_t ceil_denominator;
    int32_t ceil_numerator = ( pld_len_in_bytes << 3 ) +
                             ( pkt_p->crc_is_on ? 16 : 0 ) - ( 4 * SF ) +
                             ( pld_is_fix ? 0 : 20 );

    if( SF <= 6 )
    {
        ceil_denominator = 4 * SF;
    }
    else
    {
        ceil_numerator += 8;

        if( mod_p->ldro )
        {
            ceil_denominator = 4 * ( SF - 2 );
        }
        else
        {
            ceil_denominator = 4 * SF;
        }
    }

    if( ceil_numerator < 0 )
    {
        ceil_numerator = 0;
    }

    // Perform integral ceil()
    int32_t intermed =
        ( ( ceil_numerator + ceil_denominator - 1 ) / ceil_denominator ) *
            CR_denom +
        pkt_p->pbl_len_in_symb + 12;

    if( SF <= 6 )
    {
        intermed += 2;
    }

    return ( uint32_t )( ( 4 * intermed + 1 ) * ( 1 << ( SF - 2 ) ) );
}

uint32_t sx126x_get_bandwidth_in_hz( sx126x_lora_bw_t bw )
{
    switch( bw )
    {
    case SX126X_LORA_BW_007:
        return 7812UL;
    case SX126X_LORA_BW_010:
        return 10417UL;
    case SX126X_LORA_BW_015:
        return 15625UL;
    case SX126X_LORA_BW_020:
        return 20833UL;
    case SX126X_LORA_BW_031:
        return 31250UL;
    case SX126X_LORA_BW_041:
        return 41667UL;
    case SX126X_LORA_BW_062:
        return 62500UL;
    case SX126X_LORA_BW_125:
        return 125000UL;
    case SX126X_LORA_BW_250:
        return 250000UL;
    case SX126X_LORA_BW_500:
        return 500000UL;
    }

    return 0;
}

uint32_t sx126x_get_lora_time_on_air_in_ms(
    const sx126x_pkt_params_lora_t* pkt_p,
    const sx126x_mod_params_lora_t* mod_p )
{
    uint32_t numerator =
        1000U * sx126x_get_lora_time_on_air_numerator( pkt_p, mod_p );
    uint32_t denominator = sx126x_get_bandwidth_in_hz( mod_p->bw );
    // Perform integral ceil()
    return ( numerator + denominator - 1 ) / denominator;
}

static inline uint32_t sx126x_get_gfsk_crc_len_in_bytes(
    sx126x_gfsk_crc_types_t crc_type )
{
    switch( crc_type )
    {
    case SX126X_CRC_OFF:
        return 0;
    case SX126X_CRC_1_BYTES:
        return 1;
    case SX126X_CRC_2_BYTES:
        return 2;
    case SX126X_CRC_1_BYTES_INV:
        return 1;
    case SX126X_CRC_2_BYTES_INV:
        return 2;
    }

    return 0;
}

uint32_t sx126x_get_gfsk_time_on_air_numerator(
    const sx126x_pkt_params_gfsk_t* pkt_p )
{
    return pkt_p->pbl_len_in_bits +
           ( pkt_p->hdr_type == SX126X_GFSK_PKT_VAR_LEN ? 8 : 0 ) +
           pkt_p->sync_word_len_in_bits +
           ( ( pkt_p->pld_len_in_bytes +
               ( pkt_p->addr_cmp == SX126X_GFSK_ADDR_CMP_FILT_OFF ? 0 : 1 ) +
               sx126x_get_gfsk_crc_len_in_bytes( pkt_p->crc_type ) )
             << 3 );
}

uint32_t sx126x_get_gfsk_time_on_air_in_ms(
    const sx126x_pkt_params_gfsk_t* pkt_p,
    const sx126x_mod_params_gfsk_t* mod_p )
{
    uint32_t numerator = 1000U * sx126x_get_gfsk_time_on_air_numerator( pkt_p );
    uint32_t denominator = mod_p->br_in_bps;

    // Perform integral ceil()
    return ( numerator + denominator - 1 ) / denominator;
}

//
// Registers access
//

sx126x_status_t sx126x_cfg_rx_boosted( const void* context, const bool state )
{
    if( state == true )
    {
        return sx126x_write_register( context, SX126X_REG_RXGAIN,
                                      ( uint8_t[] ){ 0x96 }, 1 );
    }
    else
    {
        return sx126x_write_register( context, SX126X_REG_RXGAIN,
                                      ( uint8_t[] ){ 0x94 }, 1 );
    }
}

sx126x_status_t sx126x_set_gfsk_sync_word( const void*    context,
                                           const uint8_t* sync_word,
                                           const uint8_t  sync_word_len )
{
    sx126x_status_t status = SX126X_STATUS_ERROR;
    uint8_t         buf[8] = { 0 };

    if( sync_word_len <= 8 )
    {
        memcpy( buf, sync_word, sync_word_len );
        status = sx126x_write_register( context, SX126X_REG_SYNCWORDBASEADDRESS,
                                        buf, 8 );
    }

    return status;
}

sx126x_status_t sx126x_set_lora_sync_word( const void*   context,
                                           const uint8_t sync_word )
{
    uint8_t sync[] = { ( sync_word & 0xF0 ) + 0x04,
                       ( ( sync_word & 0x0F ) << 4 ) + 0x04 };

    return sx126x_write_register( context, SX126X_REG_LR_SYNCWORD, sync,
                                  sizeof( sync ) );
}

sx126x_status_t sx126x_set_gfsk_crc_seed( const void* context, uint16_t seed )
{
    uint8_t s[] = { ( uint8_t )( seed >> 8 ), ( uint8_t ) seed };

    return sx126x_write_register( context, SX126X_REG_CRCSEEDBASEADDR, s,
                                  sizeof( s ) );
}

sx126x_status_t sx126x_set_gfsk_crc_polynomial( const void*    context,
                                                const uint16_t polynomial )
{
    uint8_t poly[] = { ( uint8_t )( polynomial >> 8 ), ( uint8_t ) polynomial };

    return sx126x_write_register( context, SX126X_REG_CRCPOLYBASEADDR, poly,
                                  sizeof( poly ) );
}

sx126x_status_t sx126x_set_gfsk_whitening_seed( const void*    context,
                                                const uint16_t seed )
{
    sx126x_status_t status    = SX126X_STATUS_ERROR;
    uint8_t         reg_value = 0;

    // The SX126X_REG_WHITSEEDBASEADDR \ref LSBit is used for the seed
    // value. The 7 MSBits must not be modified.
    // Thus, we first need to read the current value and then change the LSB
    // according to the provided seed \ref value.
    status = sx126x_read_register( context, SX126X_REG_WHITSEEDBASEADDR,
                                   &reg_value, 1 );
    if( status == SX126X_STATUS_OK )
    {
        reg_value = ( reg_value & 0xFE ) | ( ( uint8_t )( seed >> 8 ) & 0x01 );
        status    = sx126x_write_register( context, SX126X_REG_WHITSEEDBASEADDR,
                                        &reg_value, 1 );
        if( status == SX126X_STATUS_OK )
        {
            reg_value = ( uint8_t ) seed;
            status    = sx126x_write_register(
                context, SX126X_REG_WHITSEEDBASEADDR + 1, &reg_value, 1 );
        }
    }

    return status;
}
