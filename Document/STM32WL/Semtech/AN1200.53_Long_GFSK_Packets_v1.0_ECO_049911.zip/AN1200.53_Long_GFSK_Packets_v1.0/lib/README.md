Overview
--------

This library facilitates transmission and reception of packets longer
than 255 bytes using Sx1261/2 transceivers.

This software depends on an unreleased sx126x driver which is subject
to change without notice. Please see the accompanying license
file. Once this driver is officially released, this software will be
updated.

For more information, see the Application Note that is packaged with
this software.


License
-------

This code library, the sx126x transceiver driver, and all example code is
provided according to the conditions found in the file license.md.
