#ifndef SX126X_LONG_PACKET_COMMON_H_
#define SX126X_LONG_PACKET_COMMON_H_

#include <stdbool.h>

#include "sx126x.h"
#include "sx126x_long_pkt/sx126x_long_pkt.h"

#define BUFFER_HEADER_MAX_LENGTH ( 100 )
#define BUFFER_LENGTH ( 8192 + 1024 )
#define HEADER_LEN ( 4 )
#define LOWER_PACKET_LEN ( 600 )
#define UPPER_PACKET_LEN ( 600 )
#define STOP_MARGIN_IN_MS ( 5 )

extern const sx126x_pa_cfg_params_t      pa_config_params_sx1261;
extern const sx126x_pa_cfg_params_t      pa_config_params_sx1262;
extern const sx126x_mod_params_gfsk_t    modulation_params_gfsk;
extern const uint8_t                     sync_word_gfsk[5];
extern const sx126x_pkt_params_gfsk_t    packet_params_gfsk;
extern sx126x_long_pkt_pkt_params_gfsk_t long_pkt_params_gfsk;

#ifdef __cplusplus
extern "C" {
#endif

void buffer_init( uint8_t* buffer, unsigned int len );
bool buffer_is_good( uint8_t* buffer, unsigned int len );
void radio_tx_init( const void* context, const sx126x_mod_params_gfsk_t* mod_params,
                    const sx126x_pa_cfg_params_t* pa_config_params );
void mcu_long_pkt_bitbang_activate( );
void radio_rx_init( const void* context, const sx126x_mod_params_gfsk_t* mod_params,
                    const sx126x_long_pkt_pkt_params_gfsk_t* long_pkt_params );
void common_add_packet_header( uint8_t* buffer, uint16_t packet_length );
bool common_packet_header_good( uint8_t* header, uint16_t* packet_length );

#ifdef __cplusplus
}
#endif

#endif  // SX126X_LONG_PACKET_COMMON_H_
