/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SRC_LONG_PACKET_STATE_H_
#define SRC_LONG_PACKET_STATE_H_

#include <stdint.h>

#include "sx126x_long_pkt_example_common/sx126x_long_pkt_example_common.h"
#include "sx126x_long_pkt/sx126x_long_pkt.h"
#include "sxlib/Timing/OneShotTimerBase/OneShotTimerBase_impl.h"

enum rx_state
{
    RX_STATE_HEADER,
    RX_STATE_BODY,
};

struct long_pkt_state
{
    // buffer_header_reservation must directly precede buffer!
    uint8_t buffer_header_reservation[BUFFER_HEADER_MAX_LENGTH];
    uint8_t buffer[BUFFER_LENGTH];

    unsigned int                    bad;
    unsigned int                    good;
    uint16_t                        packet_length;
    int16_t                         bytes_read;
    struct sx126x_long_pkt_rx_state lprxs;
    enum rx_state                   rx_state;

    struct sxlib_Timing_OneShotTimerBase timer;
};

#endif  // SRC_LONG_PACKET_STATE_H_
