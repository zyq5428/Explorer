/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SRC_LONG_PACKET_H_
#define SRC_LONG_PACKET_H_

#include "sx126x_long_pkt_example_irq/long_pkt_state.h"

struct long_pkt_config
{
    const void*  radio;
    unsigned int header_poll_interval_in_ticks;
    unsigned int body_poll_interval_in_ticks;
};

struct long_pkt_inst
{
    const struct long_pkt_config* config;
    struct long_pkt_state         state;
};

#ifdef __cplusplus
extern "C" {
#endif
void long_pkt_init( struct long_pkt_inst* inst, const struct long_pkt_config* config );
void long_pkt_start( struct long_pkt_inst* inst );
void long_pkt_handle_timer_event( struct long_pkt_inst* inst );
void long_pkt_handle_radio_event( struct long_pkt_inst* inst );

#ifdef __cplusplus
}
#endif

#endif  // SRC_LONG_PACKET_H_
