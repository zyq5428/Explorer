#include "sx126x_long_pkt_example_common/sx126x_long_pkt_example_common.h"
#include "misc.h"

uint8_t           buffer[BUFFER_LENGTH];
sx126x_irq_mask_t irq_status;

void send_packet( uint16_t packet_length )
{
    bool                            bit_to_send;
    struct sx126x_long_pkt_tx_state lptxs;

    // Change the packet length, and configure
    long_pkt_params_gfsk.long_pld_len_in_bytes = packet_length;
    sx126x_long_pkt_tx_set_gfsk_pkt_params( &radio_1, &long_pkt_params_gfsk );

    sx126x_long_pkt_tx_bits_init( &lptxs, &long_pkt_params_gfsk, sync_word_gfsk, buffer );
    sx126x_set_tx( &radio_1, 0 );

    while( sx126x_long_pkt_tx_bits_get( &lptxs, &bit_to_send ) )
    {
        send_bit_and_wait( bit_to_send );
    }

    // TX_DONE
    poll_on_radio_interrupt_and_clear( &radio_1, &irq_status );
}

int main( void )
{
    uint16_t packet_len = LOWER_PACKET_LEN;

    buffer_init( buffer, BUFFER_LENGTH );

    mcu_init( &radio_1 );
    sx126x_reset( &radio_1 );

    sx126x_long_pkt_tx_bitbang_activate( &radio_1, 0 );
    mcu_long_pkt_bitbang_activate( );

    radio_tx_init( &radio_1, &modulation_params_gfsk, &pa_config_params_sx1261 );

    while( 1 )
    {
        common_add_packet_header( buffer, packet_len );
        send_packet( packet_len );

        if( ++packet_len > UPPER_PACKET_LEN )
        {
            packet_len = LOWER_PACKET_LEN;
        }

        LL_mDelay( 128 );
    };
}
