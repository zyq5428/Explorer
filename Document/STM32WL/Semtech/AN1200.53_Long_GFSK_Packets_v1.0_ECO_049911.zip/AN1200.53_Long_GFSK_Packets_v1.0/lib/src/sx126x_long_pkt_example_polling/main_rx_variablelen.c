#include "sx126x_long_pkt_example_common/sx126x_long_pkt_example_common.h"
#include "misc.h"

#define FAST_FINAL_CHUNK

uint8_t           buffer[BUFFER_LENGTH];
sx126x_irq_mask_t irq_status;

volatile unsigned int bad  = 0;
volatile unsigned int good = 0;

static void signal_good_packet( )
{
    good++;
    led_rx_on( );
}

static void signal_bad_packet( )
{
    bad++;
    led_tx_on( );
}

int main( void )
{
    uint16_t packet_length;

    mcu_init( &radio_1 );
    sx126x_reset( &radio_1 );
    radio_rx_init( &radio_1, &modulation_params_gfsk, &long_pkt_params_gfsk );

    const unsigned int header_poll_interval_in_ms = ( HEADER_LEN * 8 * 1000 ) / modulation_params_gfsk.br_in_bps;
    const unsigned int body_poll_interval_in_ms   = ( 64 * 8 * 1000 ) / modulation_params_gfsk.br_in_bps;

#ifdef FAST_FINAL_CHUNK
    const unsigned int stop_margin_in_bytes = STOP_MARGIN_IN_MS * modulation_params_gfsk.br_in_bps / ( 8 * 1000 );
#endif

    while( 1 )
    {
        struct sx126x_long_pkt_rx_state lprxs;

        // Start long packet reception
        sx126x_long_pkt_set_rx( &radio_1, &lprxs, 0 );

        // SYNC_WORD_VALID
        poll_on_radio_interrupt_and_clear( &radio_1, &irq_status );
        if( irq_status != SX126X_IRQ_SYNC_WORD_VALID )
        {
            signal_bad_packet( );
            sx126x_long_pkt_rx_complete( &radio_1 );
            continue;
        }

        led_rx_off( );
        led_tx_off( );

        int16_t bytes_read = 0;
        while( bytes_read < HEADER_LEN )
        {
            uint8_t count;

            // Let device receive about HEADER_LEN bytes before polling
            LL_mDelay( header_poll_interval_in_ms );

            sx126x_long_pkt_rx_get_partial_payload( &radio_1, &lprxs, &buffer[bytes_read],
                                                    sizeof( buffer ) - bytes_read, &count );
            bytes_read += count;
        }

        if( !common_packet_header_good( buffer, &packet_length ) )
        {
            signal_bad_packet( );
            sx126x_long_pkt_rx_complete( &radio_1 );
            continue;
        }

        while( bytes_read < packet_length )
        {
            uint8_t count;

#ifdef FAST_FINAL_CHUNK
            uint8_t stop_offset = sx126x_long_pkt_rx_check_for_last( packet_length - bytes_read, stop_margin_in_bytes );

            if( stop_offset )
            {
                sx126x_long_pkt_rx_prepare_for_last( &radio_1, &lprxs, stop_offset );

                // RX_DONE
                poll_on_radio_interrupt_and_clear( &radio_1, &irq_status );

                sx126x_long_pkt_rx_get_partial_payload( &radio_1, &lprxs, &buffer[bytes_read],
                                                        packet_length - bytes_read, &count );
                bytes_read += count;

                break;
            }
            else
#endif  // FAST_FINAL_CHUNK
            {
                // Let device buffer get about half full before polling
                LL_mDelay( body_poll_interval_in_ms );

                sx126x_long_pkt_rx_get_partial_payload( &radio_1, &lprxs, &buffer[bytes_read],
                                                        packet_length - bytes_read, &count );
                bytes_read += count;
            }
        }

        sx126x_long_pkt_rx_complete( &radio_1 );

        if( !buffer_is_good( buffer, packet_length ) )
        {
            signal_bad_packet( );
            continue;
        }

        signal_good_packet( );
    };
}
