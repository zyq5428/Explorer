#include "sx126x_long_pkt_example_common/sx126x_long_pkt_example_common.h"
#include "misc.h"

uint8_t           buffer[BUFFER_LENGTH];
sx126x_irq_mask_t irq_status;

volatile unsigned int bad  = 0;
volatile unsigned int good = 0;

#if( UPPER_PACKET_LEN != LOWER_PACKET_LEN )
#error "UPPER_PACKET_LEN must be equal to LOWER_PACKET_LEN."
#endif

static void signal_good_packet( )
{
    good++;
    led_rx_on( );
}

static void signal_bad_packet( )
{
    bad++;
    led_tx_on( );
}

int main( void )
{
    mcu_init( &radio_1 );
    sx126x_reset( &radio_1 );
    radio_rx_init( &radio_1, &modulation_params_gfsk, &long_pkt_params_gfsk );

    while( 1 )
    {
        struct sx126x_long_pkt_rx_state lprxs;

        // Start long packet reception
        sx126x_long_pkt_set_rx( &radio_1, &lprxs, 0 );

        // SYNC_WORD_VALID
        poll_on_radio_interrupt_and_clear( &radio_1, &irq_status );
        if( irq_status != SX126X_IRQ_SYNC_WORD_VALID )
        {
            signal_bad_packet();
            sx126x_long_pkt_rx_complete( &radio_1 );
            continue;
        }

        led_rx_off( );
        led_tx_off( );

        int16_t bytes_read = 0;
        while( bytes_read < LOWER_PACKET_LEN )
        {
            uint8_t count;

            // Let device buffer get about half full before polling
            LL_mDelay( SX126X_SHORT_PACKET_MAX / 2 * 8 * 1000 / modulation_params_gfsk.br_in_bps );

            sx126x_long_pkt_rx_get_partial_payload( &radio_1, &lprxs, &buffer[bytes_read],
                                                    LOWER_PACKET_LEN - bytes_read, &count );
            bytes_read += count;
        }

        sx126x_long_pkt_rx_complete( &radio_1 );

        if( !buffer_is_good( buffer, LOWER_PACKET_LEN ) )
        {
            signal_bad_packet();
            continue;
        }

        signal_good_packet();
    };
}
