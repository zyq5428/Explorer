#include "sx126x_long_pkt_example_common/sx126x_long_pkt_example_common.h"

#define RF_FREQUENCY 868000000
#define RF_OUTPUT_POWER 0

const sx126x_pa_cfg_params_t pa_config_params_sx1262 = {
    .pa_duty_cycle = 0x04,
    .hp_max        = 0x07,
    .device_sel    = 0x00,
    .pa_lut        = 0x01,
};

const sx126x_pa_cfg_params_t pa_config_params_sx1261 = {
    .pa_duty_cycle = 0x04,
    .hp_max        = 0x00,
    .device_sel    = 0x01,
    .pa_lut        = 0x01,
};

const sx126x_mod_params_gfsk_t modulation_params_gfsk = {
    .br_in_bps    = 150000,
    .fdev_in_hz   = 100000,
    .mod_shape    = SX126X_GFSK_MOD_SHAPE_BT_05,
    .bw_dsb_param = SX126X_GFSK_BW_373600,
};

const uint8_t sync_word_gfsk[5] = { 0x97, 0x23, 0x52, 0x25, 0x56 };

const sx126x_pkt_params_gfsk_t packet_params_gfsk = {
    .pbl_len_in_bits       = 40,
    .pbl_min_det           = SX126X_GFSK_PBL_DET_32_BITS,
    .sync_word_len_in_bits = 40,
    .addr_cmp              = SX126X_GFSK_ADDR_CMP_FILT_OFF,
    .hdr_type              = SX126X_GFSK_PKT_FIX_LEN,
    // .pld_len_in_bytes      = 0,
    .crc_type = SX126X_CRC_OFF,
    .dc_free  = SX126X_DC_FREE_OFF,
};

sx126x_long_pkt_pkt_params_gfsk_t long_pkt_params_gfsk = {
    .pkt_params = &packet_params_gfsk,
    // .long_pld_len_in_bytes = 0,
};

void radio_tx_init( const void* context, const sx126x_mod_params_gfsk_t* mod_params,
                    const sx126x_pa_cfg_params_t* pa_config_params )
{
    sx126x_set_pkt_type( context, SX126X_PKT_TYPE_GFSK );
    sx126x_set_rf_freq( context, RF_FREQUENCY );
    sx126x_set_pa_cfg( context, pa_config_params );
    sx126x_set_tx_params( context, RF_OUTPUT_POWER, SX126X_RAMP_40_US );
    sx126x_set_gfsk_mod_params( context, mod_params );

    sx126x_set_dio_irq_params( context, SX126X_IRQ_TX_DONE, SX126X_IRQ_TX_DONE, SX126X_IRQ_NONE, SX126X_IRQ_NONE );
}

void radio_rx_init( const void* context, const sx126x_mod_params_gfsk_t* mod_params,
                    const sx126x_long_pkt_pkt_params_gfsk_t* long_pkt_params )
{
    sx126x_set_pkt_type( context, SX126X_PKT_TYPE_GFSK );
    sx126x_set_rf_freq( context, RF_FREQUENCY );

    sx126x_set_gfsk_mod_params( context, mod_params );

    sx126x_long_pkt_rx_set_gfsk_pkt_params( context, long_pkt_params->pkt_params );

    sx126x_set_dio_irq_params( context, SX126X_IRQ_SYNC_WORD_VALID | SX126X_IRQ_RX_DONE,
                               SX126X_IRQ_SYNC_WORD_VALID | SX126X_IRQ_RX_DONE, SX126X_IRQ_NONE, SX126X_IRQ_NONE );
}

void buffer_init( uint8_t* buffer, unsigned int len )
{
    for( unsigned int index = 0; index < len; index++ )
    {
        buffer[index] = ( uint8_t ) index;
    }
}

bool buffer_is_good( uint8_t* buffer, unsigned int len )
{
    for( unsigned int index = HEADER_LEN; index < len; index++ )
    {
        if( buffer[index] != ( uint8_t ) index )
        {
            return false;
        }
    }
    return true;
}

void common_add_packet_header( uint8_t* buffer, uint16_t packet_length )
{
    uint16_t crc = packet_length ^ 0xA55A;

    buffer[0] = ( uint8_t )( packet_length >> 8 );
    buffer[1] = ( uint8_t ) packet_length;
    buffer[2] = ( uint8_t )( crc >> 8 );
    buffer[3] = ( uint8_t ) crc;
}

bool common_packet_header_good( uint8_t* header, uint16_t* packet_length )
{
    *packet_length = ( header[0] << 8 ) + header[1];

    uint16_t crc = ( header[2] << 8 ) + header[3];
    if( ( *packet_length ^ 0xA55A ) == crc )
    {
        return true;
    }
    return false;
}
