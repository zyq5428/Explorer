/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <string.h>

#include "sx126x_long_pkt/sx126x_long_pkt.h"
#include "sx126x_long_pkt_example_irq/long_pkt.h"
#include "sx126x_long_pkt_example_irq/long_pkt_state.h"
#include "sx126x_long_pkt_example_common/sx126x_long_pkt_example_common.h"
#include "utils/sx126x_ral.h"
#include "utils/leds.h"
#include "sxlib/Debug/Log/Log.h"
#include "sxlib/Debug/Assert/Assert.h"
#include "sxlib/Timing/OneShotTimer/Generic_OneShotTimer.h"
#include "app_defs.h"

#include "sxlib/System/SleepInhibition/SleepInhibition.h"
#include "Module/SpiControllerLongPacketBitbang0/sxlib/Comm/Spi/Spi.h"
#include "sxlib/Comm/Spi/Spi_impl.h"
#include "sx126x_bsp.h"

#define RADIO_ENABLE_SLEEP

static void send_packet( struct long_pkt_inst* inst, uint16_t packet_length )
{
    // The hardware optimizations in this code expect the preamble and sync word
    // to be complete byte sequences.
    sxlib_assert( long_pkt_params_gfsk.pkt_params->pbl_len_in_bits % 8 == 0 );
    sxlib_assert( long_pkt_params_gfsk.pkt_params->sync_word_len_in_bits % 8 == 0 );

    unsigned int sync_word_len_in_bytes = ( long_pkt_params_gfsk.pkt_params->sync_word_len_in_bits ) / 8;

    unsigned int pbl_len_in_bytes = ( long_pkt_params_gfsk.pkt_params->pbl_len_in_bits ) / 8;

    unsigned int header_size = sync_word_len_in_bytes + pbl_len_in_bytes;

    sxlib_assert( header_size <= BUFFER_HEADER_MAX_LENGTH );

    // Place preamble bytes immediately before the sync word
    for( int i = 0; i < pbl_len_in_bytes; ++i )
    {
        *( inst->state.buffer - sync_word_len_in_bytes - pbl_len_in_bytes + i ) = 0x55;
    }

    // Place sync word bytes immediately before the payload
    for( int i = 0; i < sync_word_len_in_bytes; ++i )
    {
        *( inst->state.buffer - sync_word_len_in_bytes + i ) = sync_word_gfsk[i];
    }

    // Change the packet length, and configure
    long_pkt_params_gfsk.long_pld_len_in_bytes = packet_length;
    sx126x_long_pkt_tx_set_gfsk_pkt_params( inst->config->radio, &long_pkt_params_gfsk );

    // Deep sleep must be avoided while DMA is running
    sxlib_System_SleepInhibition_inhibit_sleep( SXLIB_SYSTEM_SLEEPINHIBITION_CLASS_0, 0x01 );

    // Get DMA ready to transfer data when clock arrives
    HAL_SPI_Transmit_DMA( &sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller.HAL_handle,
                          &inst->state.buffer[0] - header_size, header_size + packet_length );

    // Start transmission, which will clock out the data
    sx126x_set_tx( inst->config->radio, 0 );
}

/**
 * Start first step of transmission
 *
 * @param [in] inst Pointer to application instance
 */
static void long_pkt_launch( struct long_pkt_inst* inst )
{
    LED_TX_ON;
    common_add_packet_header( inst->state.buffer, inst->state.packet_length );
    send_packet( inst, inst->state.packet_length );
}

/**
 * Initialize the app
 *
 * @param [in] inst Pointer to application instance
 * @param [in] config Pointer to application configuration
 */
void long_pkt_init( struct long_pkt_inst* inst, const struct long_pkt_config* config )
{
    SXLIB_LOG( SXLIB_LOG_COMM, ( "Long packet TX" SXLIB_LOG_EOL ) );

    // Set up the instance state
    inst->config = config;
    memset( &inst->state, 0, sizeof( inst->state ) );

    // Initialize the timer to call the timer handler, below
    inst->state.timer.callable.arg      = inst;
    inst->state.timer.callable.callback = long_pkt_handle_timer_event;

    // Make sure this is called before MCU SPI MISO is configured as an output.
    // The device starts as a master. This way, MISO floats. When first write
    // is attempted, the configuration changes.
    sx126x_long_pkt_tx_bitbang_activate( inst->config->radio, 0 );

    // Slave initialization NOT performed in the BSP, to avoid fight. Do here.
    sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller_init_all( );

    // Configure the radio for reception
    radio_tx_init( inst->config->radio, &modulation_params_gfsk, &pa_config_params_sx1261 );

    // Fill TX buffer with identifiable data
    buffer_init( inst->state.buffer, BUFFER_LENGTH );

    // Set packet length of first packet
    inst->state.packet_length = LOWER_PACKET_LEN;
}

/**
 * Start the app
 *
 * @param [in] inst Pointer to application instance
 */
void long_pkt_start( struct long_pkt_inst* inst ) { long_pkt_launch( inst ); }

/**
 * Handle a radio interrupt
 *
 * @param [in] inst Pointer to application instance
 */
void long_pkt_handle_radio_event( struct long_pkt_inst* inst )
{
    sx126x_irq_mask_t flags;
    sx126x_get_and_clear_irq_status( inst->config->radio, &flags );

    if( flags & SX126X_IRQ_TX_DONE )
    {
        LED_TX_OFF;
        SXLIB_LOG( SXLIB_LOG_COMM, ( "D" ) );

        // Done with SPI Controller for now
        sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller_deinit_all( );

        // Now that DMA is done, deep sleep is permitted
        sxlib_System_SleepInhibition_allow_sleep( SXLIB_SYSTEM_SLEEPINHIBITION_CLASS_0, 0x01 );

#if defined RADIO_ENABLE_SLEEP
        sx126x_set_sleep( inst->config->radio, SX126X_SLEEP_CFG_WARM_START );
#endif

        // Inter-TX delay
        sxlib_Timing_OneShotTimer_insert( &inst->state.timer, 128 );
    }
}

/**
 * Handle a timer event. Here, the timer is used to add a delay between
 * transmissions.
 *
 * @param [in] inst Pointer to application instance
 */
void long_pkt_handle_timer_event( struct long_pkt_inst* inst )
{
    // Send next packet with a different length
    if( ++inst->state.packet_length > UPPER_PACKET_LEN )
    {
        inst->state.packet_length = LOWER_PACKET_LEN;
    }

#if defined RADIO_ENABLE_SLEEP
    sx126x_bsp_wakeup( inst->config->radio );

    // When the radio wakes up from a warm start, this needs to be called again.
    sx126x_long_pkt_tx_bitbang_activate( inst->config->radio, 0 );
#endif

    // The SPI controller needs to be reinitialized before DMA will work again
    sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller_init_all( );

    // Start over
    long_pkt_launch( inst );
}
