/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <string.h>

#include "sx126x_long_pkt/sx126x_long_pkt.h"
#include "sx126x_long_pkt_example_irq/long_pkt.h"
#include "sx126x_long_pkt_example_irq/long_pkt_state.h"
#include "sx126x_long_pkt_example_common/sx126x_long_pkt_example_common.h"
#include "utils/sx126x_ral.h"
#include "utils/leds.h"
#include "sxlib/Debug/Log/Log.h"
#include "sxlib/Debug/Assert/Assert.h"
#include "sxlib/Timing/OneShotTimer/Generic_OneShotTimer.h"
#include "app_defs.h"

/**
 * Start first step of reception
 *
 * @param [in] inst Pointer to application instance
 */
static void long_pkt_rx_launch( struct long_pkt_inst* inst )
{
    memset( inst->state.buffer, 0xA5, sizeof( inst->state.buffer ) );

    // Start long packet reception
    sx126x_long_pkt_set_rx( inst->config->radio, &inst->state.lprxs, 0 );

    // Get ready to read header
    inst->state.rx_state   = RX_STATE_HEADER;
    inst->state.bytes_read = 0;
}

static void signal_good_packet( struct long_pkt_inst* inst )
{
    inst->state.good++;
    LED_RX_ON;
    SXLIB_LOG( SXLIB_LOG_COMM, ( "   GOOD [%d]" SXLIB_LOG_EOL, inst->state.packet_length ) );
}

static void signal_bad_packet( struct long_pkt_inst* inst )
{
    inst->state.bad++;
    LED_TX_ON;
    SXLIB_LOG( SXLIB_LOG_COMM, ( "   BAD" SXLIB_LOG_EOL ) );
}

static void handle_rx_complete( struct long_pkt_inst* inst )
{
    sx126x_long_pkt_rx_complete( inst->config->radio );

    if( buffer_is_good( inst->state.buffer, inst->state.packet_length ) )
    {
        signal_good_packet( inst );
    }
    else
    {
        signal_bad_packet( inst );
    }

    long_pkt_rx_launch( inst );
}

static void start_radio_polling_timer( struct long_pkt_inst* inst, uint32_t ticks )
{
    sxlib_Timing_OneShotTimer_insert( &inst->state.timer, ticks );
}

/**
 * Initialize the app
 *
 * @param [in] inst Pointer to application instance
 * @param [in] config Pointer to application configuration
 */
void long_pkt_init( struct long_pkt_inst* inst, const struct long_pkt_config* config )
{
    SXLIB_LOG( SXLIB_LOG_COMM, ( "Long packet" SXLIB_LOG_EOL ) );

    // Set up the instance state
    inst->config = config;
    memset( &inst->state, 0, sizeof( inst->state ) );

    // Initialize the timer to call the timer handler, below
    inst->state.timer.callable.arg      = inst;
    inst->state.timer.callable.callback = long_pkt_handle_timer_event;

    // Configure the radio for reception
    radio_rx_init( inst->config->radio, &modulation_params_gfsk, &long_pkt_params_gfsk );
}

/**
 * Start the app
 *
 * @param [in] inst Pointer to application instance
 */
void long_pkt_start( struct long_pkt_inst* inst ) { long_pkt_rx_launch( inst ); }

/**
 * Handle a radio interrupt
 *
 * @param [in] inst Pointer to application instance
 */
void long_pkt_handle_radio_event( struct long_pkt_inst* inst )
{
    sx126x_irq_mask_t flags;
    sx126x_get_and_clear_irq_status( inst->config->radio, &flags );

    if( flags & SX126X_IRQ_SYNC_WORD_VALID )
    {
        LED_RX_OFF;
        LED_TX_OFF;

        SXLIB_LOG( SXLIB_LOG_COMM, ( "S" ) );
        start_radio_polling_timer( inst, inst->config->header_poll_interval_in_ticks );
    }
    else if( flags & SX126X_IRQ_RX_DONE )
    {
        SXLIB_LOG( SXLIB_LOG_COMM, ( "D" ) );

        uint8_t count;
        sx126x_long_pkt_rx_get_partial_payload( inst->config->radio, &inst->state.lprxs,
                                                &inst->state.buffer[inst->state.bytes_read],
                                                inst->state.packet_length - inst->state.bytes_read, &count );
        inst->state.bytes_read += count;
        handle_rx_complete( inst );
    }
}

/**
 * Handle a timer event. Here, the timer is used to periodically poll the radio
 * for new data.
 *
 * @param [in] inst Pointer to application instance
 */
void long_pkt_handle_timer_event( struct long_pkt_inst* inst )
{
    uint8_t count;

    if( inst->state.rx_state == RX_STATE_HEADER )
    {
        SXLIB_LOG( SXLIB_LOG_COMM, ( "." ) );
        sx126x_long_pkt_rx_get_partial_payload( inst->config->radio, &inst->state.lprxs,
                                                &inst->state.buffer[inst->state.bytes_read],
                                                sizeof( inst->state.buffer ) - inst->state.bytes_read, &count );
        inst->state.bytes_read += count;

        if( inst->state.bytes_read < HEADER_LEN )
        {
            start_radio_polling_timer( inst, inst->config->header_poll_interval_in_ticks );
        }
        else
        {
            if( !common_packet_header_good( inst->state.buffer, &inst->state.packet_length ) )
            {
                SXLIB_LOG( SXLIB_LOG_COMM, ( "   " SXLIB_LOG_EOL ) );
                sx126x_long_pkt_rx_complete( inst->config->radio );
                signal_bad_packet( inst );
                long_pkt_rx_launch( inst );
                return;
            }

            if( inst->state.bytes_read < inst->state.packet_length )
            {
                SXLIB_LOG( SXLIB_LOG_COMM, ( "B" ) );
                inst->state.rx_state = RX_STATE_BODY;
                start_radio_polling_timer( inst, inst->config->body_poll_interval_in_ticks );
            }
            else
            {
                handle_rx_complete( inst );
            }
        }
    }
    else if( inst->state.rx_state == RX_STATE_BODY )
    {
        SXLIB_LOG( SXLIB_LOG_COMM, ( "." ) );
        sx126x_long_pkt_rx_get_partial_payload( inst->config->radio, &inst->state.lprxs,
                                                &inst->state.buffer[inst->state.bytes_read],
                                                sizeof( inst->state.buffer ) - inst->state.bytes_read, &count );
        inst->state.bytes_read += count;

        if( inst->state.bytes_read < inst->state.packet_length )
        {
            int stop_margin_in_bytes = STOP_MARGIN_IN_MS * modulation_params_gfsk.br_in_bps / ( 8 * 1000 );

            uint8_t stop_offset = sx126x_long_pkt_rx_check_for_last( inst->state.packet_length - inst->state.bytes_read,
                                                                     stop_margin_in_bytes );

            if( stop_offset )
            {
                SXLIB_LOG( SXLIB_LOG_COMM, ( "f" ) );
                sx126x_long_pkt_rx_prepare_for_last( inst->config->radio, &inst->state.lprxs, stop_offset );
            }
            else
            {
                start_radio_polling_timer( inst, inst->config->body_poll_interval_in_ticks );
            }
        }
        else
        {
            handle_rx_complete( inst );
        }
    }
}
