/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include "sxlib/Extern/HAL.h"
#include "Module/SpiControllerLongPacketBitbang0/sxlib/Comm/Spi/Spi.h"
#include "sxlib/Comm/Spi/Spi_impl.h"

void SPI2_IRQHandler(void)
{
    HAL_SPI_IRQHandler(&sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller.HAL_handle);
}

void DMA1_Channel5_IRQHandler(void)
{
  HAL_DMA_IRQHandler(sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller.HAL_handle.hdmatx);
}
