/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include "sxlib/Extern/HAL.h"

#include "sxlib/System/EventsBase/EventsBase.h"

extern LPTIM_HandleTypeDef                  sxlib_Timing_LowPowerContinuous_lptimer;
extern struct sxlib_System_EventsBase_state sxlib_TimingOneShotTimer_event_state;

void LPTIM1_IRQHandler( void )
{
    HAL_LPTIM_IRQHandler( &sxlib_Timing_LowPowerContinuous_lptimer );
}

void HAL_LPTIM_CompareMatchCallback( LPTIM_HandleTypeDef* hlptim )
{
    NVIC_DisableIRQ( LPTIM1_IRQn );
    sxlib_System_EventsBase_event_set( &sxlib_TimingOneShotTimer_event_state );
}
