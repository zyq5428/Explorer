/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SRC_UTILS_LEDS_H_
#define SRC_UTILS_LEDS_H_

#include "app_defs.h"

#ifdef ENABLE_LEDS
#include "sxlib/Gpio/Led/Led.h"
#define LED_TX_ON                                                 \
    do                                                            \
    {                                                             \
        sxlib_Gpio_Led_on( &sxlib_Module_RadioLeds_Gpio_Led_TX ); \
    } while( 0 )
#define LED_TX_OFF                                                 \
    do                                                             \
    {                                                              \
        sxlib_Gpio_Led_off( &sxlib_Module_RadioLeds_Gpio_Led_TX ); \
    } while( 0 )
#define LED_TX_TOGGLE                                                 \
    do                                                                \
    {                                                                 \
        sxlib_Gpio_Led_toggle( &sxlib_Module_RadioLeds_Gpio_Led_TX ); \
    } while( 0 )
#define LED_RX_ON                                                 \
    do                                                            \
    {                                                             \
        sxlib_Gpio_Led_on( &sxlib_Module_RadioLeds_Gpio_Led_RX ); \
    } while( 0 )
#define LED_RX_OFF                                                 \
    do                                                             \
    {                                                              \
        sxlib_Gpio_Led_off( &sxlib_Module_RadioLeds_Gpio_Led_RX ); \
    } while( 0 )
#define LED_RX_TOGGLE                                                 \
    do                                                                \
    {                                                                 \
        sxlib_Gpio_Led_toggle( &sxlib_Module_RadioLeds_Gpio_Led_RX ); \
    } while( 0 )
#else
#define LED_TX_ON \
    do            \
    {             \
    } while( 0 )
#define LED_TX_OFF \
    do             \
    {              \
    } while( 0 )
#define LED_TX_TOGGLE \
    do                \
    {                 \
    } while( 0 )
#define LED_RX_ON \
    do            \
    {             \
    } while( 0 )
#define LED_RX_OFF \
    do             \
    {              \
    } while( 0 )
#define LED_RX_TOGGLE \
    do                \
    {                 \
    } while( 0 )
#endif

#endif  // SRC_UTILS_LEDS_H_
