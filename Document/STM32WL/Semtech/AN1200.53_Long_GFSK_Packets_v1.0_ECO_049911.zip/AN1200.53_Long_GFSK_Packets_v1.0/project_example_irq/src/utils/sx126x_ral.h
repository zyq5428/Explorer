/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SRC_UTILS_SX126X_RAL_H_
#define SRC_UTILS_SX126X_RAL_H_

#include "sx126x.h"

#ifdef __cplusplus
extern "C" {
#endif

sx126x_status_t sx126x_get_and_clear_irq_status( const void* context, sx126x_irq_mask_t* irq );
sx126x_status_t sx126x_set_pkt_payload( const void* context, const uint8_t* buffer, const uint16_t size );

#ifdef __cplusplus
}
#endif

#endif  // SRC_UTILS_SX126X_RAL_H_
