#include <stdint.h>

#include "utils/sx126x_ral.h"

// TODO: This should be in sx126x radio driver
sx126x_status_t sx126x_get_and_clear_irq_status( const void* context, sx126x_irq_mask_t* irq )
{
    sx126x_irq_mask_t sx126x_irq_mask = SX126X_IRQ_NONE;

    sx126x_status_t status = sx126x_get_irq_status( context, &sx126x_irq_mask );

    if( ( status == SX126X_STATUS_OK ) && ( sx126x_irq_mask != 0 ) )
    {
        status = sx126x_clear_irq_status( context, sx126x_irq_mask );
        if( status == SX126X_STATUS_OK )
        {
            if( irq != 0 )
            {
                *irq = sx126x_irq_mask;
            }
        }
    }
    return status;
}

sx126x_status_t sx126x_set_pkt_payload( const void* context, const uint8_t* buffer, const uint16_t size )
{
    return sx126x_write_buffer( context, 0x00, buffer, size );
}
