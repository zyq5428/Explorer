/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include "sxlib/System/EventsBase/Generic_EventsBase.h"
#include "sxlib/System/EventsBase/Rtos_EventsBase.h"
#include "sxlib/Timing/ClockSetup/Generic_ClockSetup.h"
#include "sxlib/System/Startup/Startup_impl.h"
#include "sxlib/Timing/OneShotTimer/Generic_OneShotTimer.h"

#include "sxlib/System/BSP/BSP.h"

#include "sxlib/Radio/Sx126x/Sx126x.h"
#include "sx126x_long_pkt_example_irq/long_pkt.h"
#include "sx126x_long_pkt_example_common/sx126x_long_pkt_example_common.h"
#include "sxlib/Timing/OneShotTimer/Generic_OneShotTimer.h"

struct long_pkt_inst   long_pkt0;
struct long_pkt_config long_pkt_config0 = {
    .radio = &sxlib_Module_Radio0_Radio,
};

void sxlib_System_Sleep_reconfigure_after_sleep( int sleep_type )
{
    if( sleep_type == 1 )
    {
        sxlib_Timing_ClockSetup_max( );
    }
}

void Main( struct sxlib_System_Startup_args* startup_args )
{
    sxlib_Timing_ClockSetup_max( );
    sxlib_System_BSP_init_all( startup_args->system_events, SXLIB_SYSTEM_BSP_INIT_CLOCK_FREQ_1024, false );

    unsigned int N = sxlib_Timing_OneShotTimer_get_tick_freq_in_log2( );

    long_pkt_config0.header_poll_interval_in_ticks = ( ( HEADER_LEN * 8 ) << N ) / modulation_params_gfsk.br_in_bps;
    long_pkt_config0.body_poll_interval_in_ticks   = ( ( 64 * 8 ) << N ) / modulation_params_gfsk.br_in_bps;

    long_pkt_init( &long_pkt0, &long_pkt_config0 );
    long_pkt_start( &long_pkt0 );

    while( 1 )
    {
        sxlib_System_EventsBase_eventmask events = sxlib_System_EventsBase_wait_on_any_event(
            startup_args->system_events, SXLIB_SYSTEM_EVENTSBASE_RADIO0_IRQ_MASK | SXLIB_SYSTEM_EVENTSBASE_TIMER_MASK );

        if( events & SXLIB_SYSTEM_EVENTSBASE_TIMER_MASK )
        {
            sxlib_Timing_OneShotTimer_process( 28 * 1024 );
        }
        if( events & SXLIB_SYSTEM_EVENTSBASE_RADIO0_IRQ_MASK )
        {
            long_pkt_handle_radio_event( &long_pkt0 );
        }
    }
}

int main( ) { sxlib_System_Startup( Main ); }
