/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_ARCH_CORTEXM_MCUFAMILY_STM32_SXLIB_SYSTEM_IRQLINE_IRQLINE_IMPL_H_
#define SXLIB_INCLUDE_ARCH_CORTEXM_MCUFAMILY_STM32_SXLIB_SYSTEM_IRQLINE_IRQLINE_IMPL_H_

#include <stdint.h>

#include <sxlib/System/EventsBase/EventsBase_impl.h>
#include <sxlib/Extern/HAL.h>
#include <sxlib/System/IRQLine/McuFamily_IRQLine.h>

struct sxlib_System_IRQLine_config
{
    // base must be the first element of this structure
    struct sxlib_System_EventsBase_config base;
    uint32_t                              mode;
    GPIO_TypeDef*                         port;
    IRQn_Type                             IRQn;
    uint8_t                               pull;
    uint8_t                               pin;
    uint8_t                               speed;
};

struct sxlib_System_IRQLine_inst
{
    // base must be the first element of this structure
    struct sxlib_System_EventsBase_state base;
};

#endif  // SXLIB_INCLUDE_ARCH_CORTEXM_MCUFAMILY_STM32_SXLIB_SYSTEM_IRQLINE_IRQLINE_IMPL_H_
