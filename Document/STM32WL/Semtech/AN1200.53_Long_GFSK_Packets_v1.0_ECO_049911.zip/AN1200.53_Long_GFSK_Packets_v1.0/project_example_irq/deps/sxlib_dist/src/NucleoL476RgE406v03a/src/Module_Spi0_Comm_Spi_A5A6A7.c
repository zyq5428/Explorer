/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <../CortexM/McuFamily/STM32/sxlib/Comm/Spi/Spi_impl.h>
#include <Module/Spi0/sxlib/Comm/Spi/Spi.h>

const struct sxlib_Comm_Spi_controller_init sxlib_Module_Spi0_Comm_Spi_controller_initdata = {
    .HAL_init = {
        .BaudRatePrescaler = SPI_BAUDRATEPRESCALER_4,
        .Direction         = SPI_DIRECTION_2LINES,
        .CLKPhase          = SPI_PHASE_1EDGE,
        .CLKPolarity       = SPI_POLARITY_LOW,
        .DataSize          = SPI_DATASIZE_8BIT,
        .FirstBit          = SPI_FIRSTBIT_MSB,
        .TIMode            = SPI_TIMODE_DISABLE,
        .CRCCalculation    = SPI_CRCCALCULATION_DISABLE,
        .CRCPolynomial     = 7,
        .CRCLength         = SPI_CRC_LENGTH_8BIT,
        .NSS               = SPI_NSS_SOFT,
        .NSSPMode          = SPI_NSS_PULSE_DISABLE,
        .Mode = SPI_MODE_MASTER,
    },
};

const struct sxlib_Comm_Spi_controller_config sxlib_Module_Spi0_Comm_Spi_controller_config = {
    .sck_port  = GPIOA,
    .miso_port = GPIOA,
    .mosi_port = GPIOA,

    .sck_alternate  = GPIO_AF5_SPI1,
    .miso_alternate = GPIO_AF5_SPI1,
    .mosi_alternate = GPIO_AF5_SPI1,

    .sck_pin  = 5,
    .miso_pin = 6,
    .mosi_pin = 7,

    .flags = 0,
    // .spi_IRQn = SPIx_IRQn,
};

struct sxlib_Comm_Spi_controller sxlib_Module_Spi0_Comm_Spi_controller;

void sxlib_Module_Spi0_Comm_Spi_controller_init_all( )
{
    sxlib_Comm_Spi_controller_init( &sxlib_Module_Spi0_Comm_Spi_controller, SPI1,
                                    &sxlib_Module_Spi0_Comm_Spi_controller_initdata,
                                    &sxlib_Module_Spi0_Comm_Spi_controller_config );
}

void sxlib_Module_Spi0_Comm_Spi_controller_deinit_all( )
{
    sxlib_Comm_Spi_controller_deinit( &sxlib_Module_Spi0_Comm_Spi_controller );
}
