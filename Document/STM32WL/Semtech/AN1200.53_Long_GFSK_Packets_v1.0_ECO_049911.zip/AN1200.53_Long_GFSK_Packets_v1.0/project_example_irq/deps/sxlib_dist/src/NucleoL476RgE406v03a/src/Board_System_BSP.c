/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <sxlib/Debug/Log/Log.h>
#include <sxlib/Comm/Uart/Uart.h>
#include <sxlib/Comm/Spi/Spi.h>
#include <sxlib/Gpio/Output/Output.h>
#include <sxlib/Gpio/Led/Led.h>
#include <sxlib/System/IRQLine/IRQLine_impl.h>
#include <sxlib/System/Sleep/Generic_Sleep.h>
#include <sxlib/Extern/HAL.h>
#include <sxlib/Timing/LowPowerContinuous/Generic_LowPowerContinuous.h>
#include <sxlib/Timing/OneShotTimer/Generic_OneShotTimer.h>

#include <sxlib/System/BSP/Generic_BSP.h>

void sxlib_System_BSP_init_all( sxlib_System_Events_id_t events, unsigned int base_2_clock_freq_exponent, bool lcd )
{
    HAL_Init( );

    __HAL_RCC_PWR_CLK_ENABLE( );

    __HAL_RCC_GPIOA_CLK_ENABLE( );
    __HAL_RCC_GPIOB_CLK_ENABLE( );
    __HAL_RCC_GPIOC_CLK_ENABLE( );
    __HAL_RCC_USART2_CLK_ENABLE( );
    __HAL_RCC_SPI1_CLK_ENABLE( );

    sxlib_System_BSP_BoardVariant_preinit( events, base_2_clock_freq_exponent, lcd );

    sxlib_System_Sleep_init_all( );
    sxlib_Comm_Uart_init_all( );
    sxlib_Debug_Log_init( );

    sxlib_Comm_Spi_controller_init_all( );
    sxlib_Comm_Spi_device_init_all( );
    sxlib_Gpio_Output_init_all( );
    sxlib_Gpio_Led_init_all( );
    sxlib_System_IRQLine_init_all( events );
    sxlib_Timing_LowPowerContinuous_init( base_2_clock_freq_exponent );
    sxlib_Timing_OneShotTimer_init( events );

    sxlib_System_BSP_BoardVariant_postinit( events, base_2_clock_freq_exponent, lcd );
}
