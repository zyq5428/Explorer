/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_ARCH_CORTEXM4_MCUFAMILY_STM32L4XX_MCU_STM32L476XX_BOARD_SXLIB_SYSTEM_IRQLINE_BOARD_IRQLINE_IMPL_H_
#define SXLIB_INCLUDE_ARCH_CORTEXM4_MCUFAMILY_STM32L4XX_MCU_STM32L476XX_BOARD_SXLIB_SYSTEM_IRQLINE_BOARD_IRQLINE_IMPL_H_

#include <sxlib/System/IRQLine/Generic_IRQLine.h>
#include <Module/RadioIRQLineGpio0/sxlib/System/IRQLine/IRQLine_impl.h>
#include <sxlib/System/EventsBase/Generic_EventsBase.h>

static inline void sxlib_System_IRQLine_init_all( sxlib_System_Events_id_t flags )
{
    sxlib_Module_RadioIRQLineGpio0_System_IRQLine_init_all( flags );
}

static inline void sxlib_System_IRQLine_set_all_on_pin_match( uint32_t pin_mask )
{
    sxlib_Module_RadioIRQLineGpio0_System_IRQLine_set_all_on_pin_match( pin_mask );
}

#endif  // SXLIB_INCLUDE_ARCH_CORTEXM4_MCUFAMILY_STM32L4XX_MCU_STM32L476XX_BOARD_SXLIB_SYSTEM_IRQLINE_BOARD_IRQLINE_IMPL_H_
