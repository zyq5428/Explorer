/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_MODULE_SPI0_SXLIB_COMM_SPI_SPI_H_
#define SXLIB_INCLUDE_MODULE_SPI0_SXLIB_COMM_SPI_SPI_H_

extern struct sxlib_Comm_Spi_controller sxlib_Module_Spi0_Comm_Spi_controller;

#ifdef __cplusplus
extern "C" {
#endif
void sxlib_Module_Spi0_Comm_Spi_controller_init_all( );
void sxlib_Module_Spi0_Comm_Spi_controller_deinit_all( );
#ifdef __cplusplus
}
#endif

#endif  // SXLIB_INCLUDE_MODULE_SPI0_SXLIB_COMM_SPI_SPI_H_
