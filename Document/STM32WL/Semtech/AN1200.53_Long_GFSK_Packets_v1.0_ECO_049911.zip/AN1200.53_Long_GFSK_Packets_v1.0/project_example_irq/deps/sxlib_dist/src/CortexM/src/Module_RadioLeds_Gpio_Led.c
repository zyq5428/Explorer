/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <Module/RadioLeds/sxlib/Gpio/Led/Led.h>
#include <sxlib/Gpio/Led/Led_impl.h>

const struct sxlib_Gpio_Led_dev sxlib_Module_RadioLeds_Gpio_Led_TX = {
    // Arduino A4
    .port  = GPIOC,
    .pin   = 1,
    .flags = 0,
};

const struct sxlib_Gpio_Led_dev sxlib_Module_RadioLeds_Gpio_Led_RX = {
    // Arduino A5
    .port  = GPIOC,
    .pin   = 0,
    .flags = 0,
};
