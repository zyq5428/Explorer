/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <../CortexM/McuFamily/STM32/sxlib/System/IRQLine/IRQLine_impl.h>
#include <sxlib/Extern/HAL.h>
#include <Module/RadioIRQLineGpio0/sxlib/System/IRQLine/IRQLine_impl.h>

const struct sxlib_System_IRQLine_config sxlib_Module_RadioIRQLineGpio0_System_IRQLine_config_busy = {
    .base = {
        .id = SXLIB_SYSTEM_EVENTSBASE_RADIO0_BUSY,
    },
    .mode = GPIO_MODE_IT_FALLING,
    .port = GPIOB,
    .IRQn = SXLIB_MODULE_RALSXRADIO0_SYSTEM_IRQLINE_EXTI_IRQn_BUSY,
    .pull = GPIO_NOPULL,
    .pin = 3,
    .speed = GPIO_SPEED_FREQ_MEDIUM,
};

const struct sxlib_System_IRQLine_config sxlib_Module_RadioIRQLineGpio0_System_IRQLine_config_irq = {
    .base = {
        .id = SXLIB_SYSTEM_EVENTSBASE_RADIO0_IRQ,
    },
    .mode = GPIO_MODE_IT_RISING,
    .port = GPIOB,
    .IRQn = SXLIB_MODULE_RALSXRADIO0_SYSTEM_IRQLINE_EXTI_IRQn_IRQ,
    .pull = GPIO_NOPULL,
    .pin = 4,
    .speed = GPIO_SPEED_FREQ_MEDIUM,
};

struct sxlib_System_IRQLine_inst sxlib_Module_RadioIRQLineGpio0_System_IRQLine_busy;
struct sxlib_System_IRQLine_inst sxlib_Module_RadioIRQLineGpio0_System_IRQLine_irq;
