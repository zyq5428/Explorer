/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <sxlib/Extern/HAL.h>
#include <sxlib/System/Sleep/Generic_Sleep.h>
#include <sxlib/System/SleepInhibition/Generic_SleepInhibition.h>

// For __WEAK macro for CortexM
#include <./cmsis_compiler.h>

void sxlib_System_Sleep_init_all( )
{
    // For some reason, this is necessary to enter stop2 mode.  Fix
    // this.

    GPIO_InitTypeDef GPIO_InitStruct;

    __HAL_RCC_GPIOD_CLK_ENABLE( );

    GPIO_InitStruct.Mode  = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Pin   = GPIO_PIN_All;

    HAL_GPIO_Init( GPIOD, &GPIO_InitStruct );

    __HAL_RCC_GPIOD_CLK_DISABLE( );
}

__WEAK void sxlib_System_Sleep_reconfigure_after_sleep( int sleep_type ) {}

void sxlib_System_Sleep_enter( )
{
#ifdef SXLIB_SYSTEM_SLEEP_DISABLE_DEEPSLEEP
    int deep_sleep = 0;
#else
    int deep_sleep = 1;

    if( sxlib_System_SleepInhibition_get_mask( SXLIB_SYSTEM_SLEEPINHIBITION_CLASS_0 ) )
    {
        deep_sleep = 0;
    }

    if( deep_sleep )
    {
        SET_BIT( SCB->SCR, ( ( uint32_t ) SCB_SCR_SLEEPDEEP_Msk ) );
    }
    else
#endif
    {
        CLEAR_BIT( SCB->SCR, ( ( uint32_t ) SCB_SCR_SLEEPDEEP_Msk ) );
    }

    MODIFY_REG( PWR->CR1, PWR_CR1_LPMS, PWR_CR1_LPMS_STOP2 );

    __WFI( );
    __enable_irq( );

    sxlib_System_Sleep_reconfigure_after_sleep( deep_sleep );
}
