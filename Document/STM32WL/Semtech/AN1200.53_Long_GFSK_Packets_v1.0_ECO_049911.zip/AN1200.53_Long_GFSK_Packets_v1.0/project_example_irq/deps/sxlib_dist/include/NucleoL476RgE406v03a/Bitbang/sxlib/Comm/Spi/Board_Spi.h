/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_ARCH_CORTEXM4_MCUFAMILY_STM32L4XX_MCU_STM32L476XX_BOARD_BOARDVARIANT_SXLIB_COMM_SPI_BOARDVARIANT_SPI_H_
#define SXLIB_INCLUDE_ARCH_CORTEXM4_MCUFAMILY_STM32L4XX_MCU_STM32L476XX_BOARD_BOARDVARIANT_SXLIB_COMM_SPI_BOARDVARIANT_SPI_H_

#include <Module/Spi0/sxlib/Comm/Spi/Spi.h>
#include <Module/SpiControllerLongPacketBitbang0/sxlib/Comm/Spi/Spi.h>
#include <Module/SpiDeviceRadio0/sxlib/Comm/Spi/Spi.h>

static inline void sxlib_Comm_Spi_controller_init_all( )
{
    sxlib_Module_Spi0_Comm_Spi_controller_init_all( );

    // Defer the initialization until sx126x is properly configured
    // sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller_init_all();
}

static inline void sxlib_Comm_Spi_controller_deinit_all( )
{
    sxlib_Module_Spi0_Comm_Spi_controller_deinit_all( );

    // Defer the initialization until sx126x is properly configured
    // sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller_deinit_all();
}

static inline void sxlib_Comm_Spi_device_init_all( ) { sxlib_Module_SpiDeviceRadio0_Comm_Spi_device_init_all( ); }

#endif  // SXLIB_INCLUDE_ARCH_CORTEXM4_MCUFAMILY_STM32L4XX_MCU_STM32L476XX_BOARD_BOARDVARIANT_SXLIB_COMM_SPI_BOARDVARIANT_SPI_H_
