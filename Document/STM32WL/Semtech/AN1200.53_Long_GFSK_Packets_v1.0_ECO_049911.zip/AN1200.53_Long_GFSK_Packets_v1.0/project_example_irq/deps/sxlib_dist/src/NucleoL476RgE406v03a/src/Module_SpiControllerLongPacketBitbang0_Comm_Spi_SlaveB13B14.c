/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <../CortexM/McuFamily/STM32/sxlib/Comm/Spi/Spi_impl.h>
#include <Module/SpiControllerLongPacketBitbang0/sxlib/Comm/Spi/Spi.h>

const struct sxlib_Comm_Spi_controller_init sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller_initdata = {
    .HAL_init = {
        .BaudRatePrescaler = SPI_BAUDRATEPRESCALER_4,
        .Direction         = SPI_DIRECTION_2LINES,
        .CLKPhase          = SPI_PHASE_1EDGE,
        .CLKPolarity       = SPI_POLARITY_LOW,
        .DataSize          = SPI_DATASIZE_8BIT,
        .FirstBit          = SPI_FIRSTBIT_MSB,
        .TIMode            = SPI_TIMODE_DISABLE,
        .CRCCalculation    = SPI_CRCCALCULATION_DISABLE,
        .CRCPolynomial     = 7,
        .CRCLength         = SPI_CRC_LENGTH_8BIT,
        .NSS               = SPI_NSS_SOFT,
        .NSSPMode          = SPI_NSS_PULSE_DISABLE,
        .Mode = SPI_MODE_SLAVE,
    },
};

DMA_HandleTypeDef sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller_DMA_tx_handle;

const struct sxlib_Comm_Spi_controller_DMA_config
    sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller_DMA_tx_config = {
        .handle   = &sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller_DMA_tx_handle,
        .channel  = DMA1_Channel5,
        .request  = 1,
        .dma_IRQn = DMA1_Channel5_IRQn,
    };

const struct sxlib_Comm_Spi_controller_config
    sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller_config = {
        // mosi is not needed.

        .sck_port  = GPIOB,
        .miso_port = GPIOB,
        .mosi_port = 0,

        .sck_alternate  = GPIO_AF5_SPI2,
        .miso_alternate = GPIO_AF5_SPI2,
        // .mosi_alternate = 0,

        .sck_pin  = 13,
        .miso_pin = 14,
        // .mosi_pin = 0,

        .flags    = SXLIB_COMM_SPI_CONTROLLER_CONFIG_FLAGS_ENABLE_IRQ,
        .spi_IRQn = SPI2_IRQn,

        .DMA_tx_config = &sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller_DMA_tx_config,
    };

struct sxlib_Comm_Spi_controller sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller;

void sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller_init_all( )
{
    sxlib_Comm_Spi_controller_init( &sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller, SPI2,
                                    &sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller_initdata,
                                    &sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller_config );
}

void sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller_deinit_all( )
{
    sxlib_Comm_Spi_controller_deinit( &sxlib_Module_SpiControllerLongPacketBitbang0_Comm_Spi_controller );
}
