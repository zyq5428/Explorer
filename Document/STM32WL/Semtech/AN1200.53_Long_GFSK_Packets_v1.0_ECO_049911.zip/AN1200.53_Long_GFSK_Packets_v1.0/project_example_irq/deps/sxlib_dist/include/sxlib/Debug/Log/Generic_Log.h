/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_GENERIC_SXLIB_DEBUG_LOG_GENERIC_LOG_H_
#define SXLIB_INCLUDE_GENERIC_SXLIB_DEBUG_LOG_GENERIC_LOG_H_

#define SXLIB_LOG_LEVEL_NONE ( 0 )

#define SXLIB_LOG_APP ( 1000 )
#define SXLIB_LOG_COMM ( 2000 )
#define SXLIB_LOG_SXLIB ( 3000 )

/** If SXLIB_LOG_LEVEL is 0, logging will be copmiled out */
#ifndef SXLIB_LOG_LEVEL
#define SXLIB_LOG_LEVEL 0
#endif

#ifdef SXLIB_LOG_WINDOWS
#define SXLIB_LOG_EOL "\r\n"
#else
#define SXLIB_LOG_EOL "\n"
#endif

#define SXLIB_LOG( level, print_args )      \
    do                                      \
    {                                       \
        if( SXLIB_LOG_LEVEL >= level )      \
        {                                   \
            sxlib_Debug_Log_log print_args; \
        }                                   \
    } while( 0 )

#ifdef __cplusplus
extern "C" {
#endif
void sxlib_Debug_Log_log( const char* format, ... );
void sxlib_Debug_Log_init( );
#ifdef __cplusplus
}
#endif

#endif  // SXLIB_INCLUDE_GENERIC_SXLIB_DEBUG_LOG_GENERIC_LOG_H_
