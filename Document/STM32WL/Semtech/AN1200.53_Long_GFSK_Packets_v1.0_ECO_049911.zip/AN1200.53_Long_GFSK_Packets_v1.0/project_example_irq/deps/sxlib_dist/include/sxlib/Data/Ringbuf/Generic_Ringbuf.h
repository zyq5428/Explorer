/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_GENERIC_SXLIB_DATA_RINGBUF_GENERIC_RINGBUF_H_
#define SXLIB_INCLUDE_GENERIC_SXLIB_DATA_RINGBUF_GENERIC_RINGBUF_H_

#include <stdint.h>
#include <stdbool.h>

struct sxlib_data_ringbuf_s
{
    uint8_t* data;
    uint16_t begin;      // Least recently added byte
    uint16_t end;        // One past the most recently added byte
    uint16_t mask;       // Bufblocks - 1
    uint16_t blocksize;  // Number of bytes per block
};

#ifdef __cplusplus
extern "C" {
#endif

/* bufblocks is 2^N for some integer N.
 * max: 2^15 * blocksize on machine with 16-bit int.
 * max: 2^16 * blocksize on other machines.
 * buf must have space for blocksize * bufblocks bytes.
 */
void         sxlib_data_ringbuf_init( struct sxlib_data_ringbuf_s* rb, uint8_t* buf, unsigned int bufblocks,
                                      unsigned int blocksize );
unsigned int sxlib_data_ringbuf_add_segment( struct sxlib_data_ringbuf_s* rb, const uint8_t* src,
                                             unsigned int num_blocks );
void         sxlib_data_ringbuf_add( struct sxlib_data_ringbuf_s* rb, const uint8_t* src, unsigned int num_blocks );
unsigned int sxlib_data_ringbuf_remove_segment( struct sxlib_data_ringbuf_s* rb, uint8_t* dest,
                                                unsigned int max_blocks );
unsigned int sxlib_data_ringbuf_remove( struct sxlib_data_ringbuf_s* rb, uint8_t* dest, unsigned int max_blocks );

// If true, this means that adding bytes will result in data loss
static inline bool sxlib_data_ringbuf_full( struct sxlib_data_ringbuf_s* rb )
{
    return rb->begin == ( ( rb->end + 1 ) & rb->mask );
}

static inline bool sxlib_data_ringbuf_empty( struct sxlib_data_ringbuf_s* rb ) { return rb->begin == rb->end; }

static inline unsigned int sxlib_data_ringbuf_count( struct sxlib_data_ringbuf_s* rb )
{
    return ( rb->end - rb->begin ) & rb->mask;
}

#ifdef __cplusplus
}
#endif

#endif  // SXLIB_INCLUDE_GENERIC_SXLIB_DATA_RINGBUF_GENERIC_RINGBUF_H_
