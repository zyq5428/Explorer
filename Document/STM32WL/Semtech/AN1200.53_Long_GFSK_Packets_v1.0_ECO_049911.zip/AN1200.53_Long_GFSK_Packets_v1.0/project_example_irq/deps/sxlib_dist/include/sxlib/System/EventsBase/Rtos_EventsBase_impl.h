/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_RTOS_NONE_SXLIB_SYSTEM_EVENTSBASE_RTOS_EVENTSBASE_IMPL_H_
#define SXLIB_INCLUDE_RTOS_NONE_SXLIB_SYSTEM_EVENTSBASE_RTOS_EVENTSBASE_IMPL_H_

#include <stdint.h>
#include <sxlib/System/EventsBase/EventsBase.h>

typedef uint32_t sxlib_System_EventsBase_BackingStore_t;

struct sxlib_System_EventsBase_config
{
    /** Event event source must have a unique id within its flags between 0 and 30 */
    uint8_t id;
};

struct sxlib_System_EventsBase_state
{
    const struct sxlib_System_EventsBase_config* config;
    volatile sxlib_System_EventsBase_eventmask*  flags;
};

static inline volatile sxlib_System_EventsBase_eventmask* get_events( sxlib_System_EventsBase_events_t e )
{
    return ( ( volatile sxlib_System_EventsBase_eventmask* ) e );
}

#endif  // SXLIB_INCLUDE_RTOS_NONE_SXLIB_SYSTEM_EVENTSBASE_RTOS_EVENTSBASE_IMPL_H_
