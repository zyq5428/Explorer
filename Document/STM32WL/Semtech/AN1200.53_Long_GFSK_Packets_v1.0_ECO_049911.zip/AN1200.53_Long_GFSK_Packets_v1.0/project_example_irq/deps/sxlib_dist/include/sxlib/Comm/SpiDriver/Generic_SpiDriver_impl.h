/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_GENERIC_SXLIB_COMM_SPIDRIVER_GENERIC_SPIDRIVER_IMPL_H_
#define SXLIB_INCLUDE_GENERIC_SXLIB_COMM_SPIDRIVER_GENERIC_SPIDRIVER_IMPL_H_

#include <stdint.h>

#include <sxlib/Comm/SpiDriver/Generic_SpiDriver.h>

typedef void ( *sxlib_Comm_SpiDriver_CS_fptr )( const void* dev );
typedef void ( *sxlib_Comm_SpiDriver_nCS_fptr )( const void* dev );
typedef void ( *sxlib_Comm_SpiDriver_read_fptr )( const void* dev, uint8_t* data, unsigned int len );
typedef void ( *sxlib_Comm_SpiDriver_write_fptr )( const void* dev, const uint8_t* data, unsigned int len );

struct sxlib_Comm_SpiDriver_inst
{
    sxlib_Comm_SpiDriver_CS_fptr    CS;
    sxlib_Comm_SpiDriver_nCS_fptr   nCS;
    sxlib_Comm_SpiDriver_read_fptr  read;
    sxlib_Comm_SpiDriver_write_fptr write;
};

#endif  // SXLIB_INCLUDE_GENERIC_SXLIB_COMM_SPIDRIVER_GENERIC_SPIDRIVER_IMPL_H_
