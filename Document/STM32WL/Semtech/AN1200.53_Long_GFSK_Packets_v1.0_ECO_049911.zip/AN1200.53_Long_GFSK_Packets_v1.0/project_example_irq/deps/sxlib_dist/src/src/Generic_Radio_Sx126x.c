/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <sxlib/Radio/Sx126x/Generic_Sx126x_impl.h>
#include <sxlib/System/IRQLine/IRQLine.h>
#include <sxlib/Comm/Spi/Generic_Spi.h>
#include <sxlib/Debug/Assert/Assert.h>
#include <sxlib/Gpio/Output/Generic_Output.h>
#include <sxlib/Timing/Busywait/Generic_Busywait.h>

#include <./sx126x_bsp.h>

void sxlib_Radio_Sx126x_init( const struct sxlib_Radio_Sx126x_inst* inst )
{
    sx126x_status_t status;

    sx126x_bsp_reset( inst );

    status = sx126x_set_standby( inst, SX126X_STANDBY_CFG_RC );
    sxlib_assert( status == SX126X_STATUS_OK );

    status = sx126x_set_reg_mode( inst, SX126X_REG_MODE_DCDC );
    sxlib_assert( status == SX126X_STATUS_OK );
}

sx126x_bsp_status_t sx126x_bsp_write( const void* context, const uint8_t* command, const uint16_t command_length,
                                      const uint8_t* data, const uint16_t data_length )
{
    const struct sxlib_Radio_Sx126x_inst* inst = ( const struct sxlib_Radio_Sx126x_inst* ) context;

    sxlib_System_IRQLine_wait_on_event( inst->spi_radio.reset_irq.radio_IRQ_inst );
    sxlib_Comm_Spi_CS( inst->spi_radio.spi );
    sxlib_Comm_Spi_write( inst->spi_radio.spi, command, command_length );
    if( data_length > 0 )
    {
        sxlib_Comm_Spi_write( inst->spi_radio.spi, data, data_length );
    }
    sxlib_System_IRQLine_clear( inst->spi_radio.reset_irq.radio_IRQ_inst );
    sxlib_Comm_Spi_nCS( inst->spi_radio.spi );

    // If busy is still low after CS rises, the Sx1265 is ready for next cmd.
    if( sxlib_System_IRQLine_read_gpio_state( inst->spi_radio.reset_irq.radio_IRQ_inst ) == 0 )
    {
        sxlib_System_IRQLine_set( inst->spi_radio.reset_irq.radio_IRQ_inst );
    }

    return SX126X_BSP_STATUS_OK;
}

sx126x_bsp_status_t sx126x_bsp_read( const void* context, const uint8_t* command, const uint16_t command_length,
                                     uint8_t* data, const uint16_t data_length )
{
    const struct sxlib_Radio_Sx126x_inst* inst = ( const struct sxlib_Radio_Sx126x_inst* ) context;

    sxlib_System_IRQLine_wait_on_event( inst->spi_radio.reset_irq.radio_IRQ_inst );
    sxlib_Comm_Spi_CS( inst->spi_radio.spi );
    sxlib_Comm_Spi_write( inst->spi_radio.spi, command, command_length );
    if( data_length > 0 )
    {
        sxlib_Comm_Spi_read( inst->spi_radio.spi, data, data_length );
    }
    sxlib_System_IRQLine_clear( inst->spi_radio.reset_irq.radio_IRQ_inst );
    sxlib_Comm_Spi_nCS( inst->spi_radio.spi );

    // If busy is still low after CS rises, the Sx1265 is ready for next cmd.
    if( sxlib_System_IRQLine_read_gpio_state( inst->spi_radio.reset_irq.radio_IRQ_inst ) == 0 )
    {
        sxlib_System_IRQLine_set( inst->spi_radio.reset_irq.radio_IRQ_inst );
    }

    return SX126X_BSP_STATUS_OK;
}

sx126x_bsp_status_t sx126x_bsp_wakeup( const void* context )
{
    const struct sxlib_Radio_Sx126x_inst* inst = ( const struct sxlib_Radio_Sx126x_inst* ) context;

    sxlib_Comm_Spi_CS( inst->spi_radio.spi );
    sxlib_Comm_Spi_nCS( inst->spi_radio.spi );

    return SX126X_BSP_STATUS_OK;
}

void sxral_Radio_Sx126x_reset( const struct sxlib_Radio_Sx126x_inst* inst )
{
    sxlib_Radio_ResetIRQ_reset( &inst->spi_radio.reset_irq );
}

void sx126x_bsp_reset( const void* context )
{
    const struct sxlib_Radio_Sx126x_inst* inst = ( const struct sxlib_Radio_Sx126x_inst* ) context;

    sxral_Radio_Sx126x_reset( inst );
}
