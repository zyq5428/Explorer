/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <stdint.h>

#include <sxlib/Timing/LowPowerContinuous/Generic_LowPowerContinuous.h>
#include <sxlib/Debug/Assert/Assert.h>
#include <sxlib/Extern/HAL.h>
#include <sxlib/Extern/Stm32lLl.h>

LPTIM_HandleTypeDef sxlib_Timing_LowPowerContinuous_lptimer;

static uint16_t sxlib_Timing_LowPowerContinuous_last_time;

uint16_t sxlib_Timing_LowPowerContinuous_get_hardware_time( )
{
    uint16_t t_old;
    uint16_t t = LPTIM1->CNT;

    do
    {
        t_old = t;
        t     = LPTIM1->CNT;
    } while( t != t_old );

    return t;
}

sxlib_Timing_LowPowerContinuous_hardware_time_t sxlib_Timing_LowPowerContinuous_get_time_delta(
    sxlib_Timing_LowPowerContinuous_hardware_time_t* last )
{
    uint16_t current = sxlib_Timing_LowPowerContinuous_get_hardware_time( );
    uint16_t delta   = current - *last;
    *last            = current;
    return delta;
}

/*
 * It takes more than three LPTIM clock periods to change CMP or
 * ARR. Also, if we want CMP to be changed with no delay, I don't
 * believe it is possible to be certain of what is programmed into CMP
 * if we are close to a LPTIM clock boundary.
 */
int sxlib_Timing_LowPowerContinuous_get_minimum_delay( ) { return 5; }

/*
 * It is assumed here that time is more than LowPowerContinuous_minimum_delay
 * LPTIM periods in the future. Otherwise, this will fail.
 *
 * Before calling, make sure the LPTIM IRQ is disabled, with
 * something like LowPowerContinuous_stop().
 */
void sxlib_Timing_LowPowerContinuous_start_interval_timer( uint16_t delta )
{
    uint16_t deadline, condition;

    deadline = sxlib_Timing_LowPowerContinuous_get_hardware_time( ) + delta;
    LL_LPTIM_ClearFlag_CMPOK( LPTIM1 );
    LL_LPTIM_SetCompare( LPTIM1, deadline );
    while( !LL_LPTIM_IsActiveFlag_CMPOK( LPTIM1 ) )
        ;
    LPTIM1->ICR = LPTIM_FLAG_CMPM;
    NVIC_ClearPendingIRQ( LPTIM1_IRQn );
    condition = sxlib_Timing_LowPowerContinuous_get_hardware_time( ) - deadline;

    // We missed the deadline. Just set the interrupt and go on.
    if( condition <= 0x8000 )
    {
        LPTIM1->ISR = LPTIM_FLAG_CMPM;
    }

    NVIC_EnableIRQ( LPTIM1_IRQn );
}

void sxlib_Timing_LowPowerContinuous_stop_interval_timer( ) { NVIC_DisableIRQ( LPTIM1_IRQn ); }

void sxlib_Timing_LowPowerContinuous_set_clock_frequency( unsigned int base_2_clock_freq_exponent )
{
    sxlib_assert( base_2_clock_freq_exponent <= 15 );
    sxlib_assert( base_2_clock_freq_exponent > 7 );
    LPTIM1->CFGR &= ~LPTIM_CFGR_PRESC_Msk;
    LPTIM1->CFGR |= ( ( 15 - base_2_clock_freq_exponent ) << LPTIM_CFGR_PRESC_Pos );
}

unsigned int sxlib_Timing_LowPowerContinuous_get_clock_frequency( )
{
    return 15 - ( ( LPTIM1->CFGR & LPTIM_CFGR_PRESC_Msk ) >> LPTIM_CFGR_PRESC_Pos );
}

void sxlib_Timing_LowPowerContinuous_init( unsigned int base_2_clock_freq_exponent )
{
    RCC_OscInitTypeDef RCC_OscInitStruct;

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE;

    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
    RCC_OscInitStruct.LSEState     = RCC_LSE_ON;
    HAL_RCC_OscConfig( &RCC_OscInitStruct );

    __HAL_RCC_LPTIM1_CLK_ENABLE( );
    __HAL_RCC_LPTIM1_FORCE_RESET( );
    __HAL_RCC_LPTIM1_RELEASE_RESET( );

    // Set RCC/LPTIM1SEL to LSE
    RCC->CCIPR &= ~RCC_CCIPR_LPTIM1SEL_Msk;
    RCC->CCIPR |= ( 3 << RCC_CCIPR_LPTIM1SEL_Pos );

#ifdef SXTOOLS_McuFamily_STM32L4xx
    // Keep LPTIM1 running during sleep/halt modes
    RCC->APB1SMENR1 |= RCC_APB1SMENR1_LPTIM1SMEN;
#endif

    sxlib_Timing_LowPowerContinuous_lptimer.Instance = LPTIM1;

    sxlib_Timing_LowPowerContinuous_lptimer.Init.Clock.Source  = LPTIM_CLOCKSOURCE_APBCLOCK_LPOSC;
    sxlib_Timing_LowPowerContinuous_lptimer.Init.CounterSource = LPTIM_COUNTERSOURCE_INTERNAL;

    // Default, 1 mibi-second
    sxlib_Timing_LowPowerContinuous_lptimer.Init.Clock.Prescaler = LPTIM_PRESCALER_DIV1;
    sxlib_Timing_LowPowerContinuous_lptimer.Init.Trigger.Source  = LPTIM_TRIGSOURCE_SOFTWARE;
    sxlib_Timing_LowPowerContinuous_lptimer.Init.OutputPolarity  = LPTIM_OUTPUTPOLARITY_HIGH;
    sxlib_Timing_LowPowerContinuous_lptimer.Init.UpdateMode      = LPTIM_UPDATE_IMMEDIATE;

    HAL_LPTIM_Init( &sxlib_Timing_LowPowerContinuous_lptimer );
    sxlib_Timing_LowPowerContinuous_set_clock_frequency( base_2_clock_freq_exponent );

    __HAL_LPTIM_ENABLE( &sxlib_Timing_LowPowerContinuous_lptimer );
    __HAL_LPTIM_AUTORELOAD_SET( &sxlib_Timing_LowPowerContinuous_lptimer, 0xFFFF );
    __HAL_LPTIM_START_CONTINUOUS( &sxlib_Timing_LowPowerContinuous_lptimer );

    LPTIM1->ICR = LPTIM_FLAG_CMPM;
    __HAL_LPTIM_ENABLE_IT( &sxlib_Timing_LowPowerContinuous_lptimer, LPTIM_IT_CMPM );

    sxlib_Timing_LowPowerContinuous_last_time = sxlib_Timing_LowPowerContinuous_get_hardware_time( );
}
