/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <sxlib/Extern/HAL.h>
#include <sxlib/System/BSP/Generic_BSP.h>
#include <sxlib/Radio/Sx126x/Sx126x.h>

void sxlib_System_BSP_BoardVariant_preinit( sxlib_System_Events_id_t events, unsigned int base_2_clock_freq_exponent,
                                            bool lcd )
{
    __HAL_RCC_SPI2_CLK_ENABLE( );
    __HAL_RCC_DMA1_CLK_ENABLE( );
}

void sxlib_System_BSP_BoardVariant_postinit( sxlib_System_Events_id_t events, unsigned int base_2_clock_freq_exponent,
                                             bool lcd )
{
    sxlib_Radio_Sx126x_init_all( );
}
