/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_ARCH_CORTEXM4_MCUFAMILY_STM32L4XX_MCU_STM32L476XX_BOARD_SXLIB_MODULE_RALSXRADIO0_SXLIB_SYSTEM_IRQLINE_BOARD_IRQLINE_IMPL_H_
#define SXLIB_INCLUDE_ARCH_CORTEXM4_MCUFAMILY_STM32L4XX_MCU_STM32L476XX_BOARD_SXLIB_MODULE_RALSXRADIO0_SXLIB_SYSTEM_IRQLINE_BOARD_IRQLINE_IMPL_H_

#include <Module/RadioIRQLineGpio0/sxlib/System/IRQLine/Generic_IRQLine_impl.h>
#include <Module/RadioIRQLineGpio0/sxlib/System/IRQLine/IRQLine.h>

#define SXLIB_MODULE_RALSXRADIO0_SYSTEM_IRQLINE_EXTI_IRQn_BUSY EXTI3_IRQn
#define SXLIB_MODULE_RALSXRADIO0_SYSTEM_IRQLINE_EXTI_IRQn_IRQ EXTI4_IRQn

#endif  // SXLIB_INCLUDE_ARCH_CORTEXM4_MCUFAMILY_STM32L4XX_MCU_STM32L476XX_BOARD_SXLIB_MODULE_RALSXRADIO0_SXLIB_SYSTEM_IRQLINE_BOARD_IRQLINE_IMPL_H_
