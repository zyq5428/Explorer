/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_GENERIC_SXLIB_SYSTEM_IRQLINE_GENERIC_IRQLINE_H_
#define SXLIB_INCLUDE_GENERIC_SXLIB_SYSTEM_IRQLINE_GENERIC_IRQLINE_H_

struct sxlib_System_IRQLine_inst;

#ifdef __cplusplus
extern "C" {
#endif
/** Called from ISR */
unsigned int sxlib_System_IRQLine_read_gpio_state( struct sxlib_System_IRQLine_inst* inst );
void         sxlib_System_IRQLine_set( struct sxlib_System_IRQLine_inst* inst );

void                                  sxlib_System_IRQLine_clear( struct sxlib_System_IRQLine_inst* inst );
void                                  sxlib_System_IRQLine_wait_on_event( struct sxlib_System_IRQLine_inst* inst );
struct sxlib_System_EventsBase_state* sxlib_System_IRQLine_getEventsBase( struct sxlib_System_IRQLine_inst* inst );
#ifdef __cplusplus
}
#endif

#endif  // SXLIB_INCLUDE_GENERIC_SXLIB_SYSTEM_IRQLINE_GENERIC_IRQLINE_H_
