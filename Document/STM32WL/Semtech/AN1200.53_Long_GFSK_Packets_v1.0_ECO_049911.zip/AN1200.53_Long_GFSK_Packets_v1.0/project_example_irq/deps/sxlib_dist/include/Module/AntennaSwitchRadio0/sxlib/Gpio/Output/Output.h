/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_MODULE_ANTENNASWITCHRADIO0_SXLIB_GPIO_OUTPUT_OUTPUT_H_
#define SXLIB_INCLUDE_MODULE_ANTENNASWITCHRADIO0_SXLIB_GPIO_OUTPUT_OUTPUT_H_

#include <sxlib/Gpio/Output/McuFamily_Output.h>

extern const struct sxlib_Gpio_Output_inst sxlib_Module_AntennaSwitchRadio0_Gpio_Output;

static inline void sxlib_Module_AntennaSwitchRadio0_Gpio_Output_init_all( )
{
    sxlib_Gpio_Output_init( &sxlib_Module_AntennaSwitchRadio0_Gpio_Output, SXLIB_GPIO_OUTPUT_HIGH );
}

#endif  // SXLIB_INCLUDE_MODULE_ANTENNASWITCHRADIO0_SXLIB_GPIO_OUTPUT_OUTPUT_H_
