/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_RTOS_NONE_SXLIB_SYSTEM_EVENTSBASE_EVENTSBASE_IMPL_H_
#define SXLIB_INCLUDE_RTOS_NONE_SXLIB_SYSTEM_EVENTSBASE_EVENTSBASE_IMPL_H_

#include <sxlib/System/EventsBase/Rtos_EventsBase_impl.h>

#endif  // SXLIB_INCLUDE_RTOS_NONE_SXLIB_SYSTEM_EVENTSBASE_EVENTSBASE_IMPL_H_
