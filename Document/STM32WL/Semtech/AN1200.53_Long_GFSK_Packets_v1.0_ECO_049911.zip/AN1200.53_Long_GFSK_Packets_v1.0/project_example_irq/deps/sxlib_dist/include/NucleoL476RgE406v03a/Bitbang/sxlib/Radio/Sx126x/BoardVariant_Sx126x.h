/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_ARCH_CORTEXM4_MCUFAMILY_STM32L4XX_MCU_STM32L476XX_BOARD_BOARDVARIANT_SXLIB_RADIO_SX126X_BOARDVARIANT_SX126X_H_
#define SXLIB_INCLUDE_ARCH_CORTEXM4_MCUFAMILY_STM32L4XX_MCU_STM32L476XX_BOARD_BOARDVARIANT_SXLIB_RADIO_SX126X_BOARDVARIANT_SX126X_H_

#include <Module/LeanSx126xRadio0/sxlib/Radio/Sx126x/Sx126x.h>

static inline void sxlib_Radio_Sx126x_init_all( ) { sxlib_Module_LeanSx126xRadio0_Radio_Sx126x_init_all( ); }

#endif  // SXLIB_INCLUDE_ARCH_CORTEXM4_MCUFAMILY_STM32L4XX_MCU_STM32L476XX_BOARD_BOARDVARIANT_SXLIB_RADIO_SX126X_BOARDVARIANT_SX126X_H_
