/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_MODULE_NUCLEO64A_SXLIB_COMM_SPI_SPI_H_
#define SXLIB_INCLUDE_MODULE_NUCLEO64A_SXLIB_COMM_SPI_SPI_H_

#include <../CortexM/McuFamily/STM32/sxlib/Comm/Spi/Spi.h>

extern struct sxlib_Comm_Spi_controller sxlib_Module_Nucleo64a_Comm_Spi_controller_SPI1;

#ifdef __cplusplus
extern "C" {
#endif
void sxlib_Module_Nucleo64a_Comm_Spi_controller_init_all( );
void sxlib_Module_Nucleo64a_Comm_Spi_controller_deinit_all( );
#ifdef __cplusplus
}
#endif

#endif  // SXLIB_INCLUDE_MODULE_NUCLEO64A_SXLIB_COMM_SPI_SPI_H_
