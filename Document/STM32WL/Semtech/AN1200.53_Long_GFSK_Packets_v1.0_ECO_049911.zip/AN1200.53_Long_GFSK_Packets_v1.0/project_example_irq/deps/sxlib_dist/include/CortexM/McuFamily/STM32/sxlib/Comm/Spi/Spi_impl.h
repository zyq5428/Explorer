/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_ARCH_CORTEXM_MCUFAMILY_STM32_SXLIB_COMM_SPI_SPI_IMPL_H_
#define SXLIB_INCLUDE_ARCH_CORTEXM_MCUFAMILY_STM32_SXLIB_COMM_SPI_SPI_IMPL_H_

#include <stdint.h>

#include <../CortexM/McuFamily/STM32/sxlib/Comm/Spi/Spi.h>
#include <sxlib/Comm/Spi/Generic_Spi.h>
#include <sxlib/Extern/McuFamily_HAL.h>

#define SXLIB_COMM_SPI_CONTROLLER_CONFIG_FLAGS_ENABLE_IRQ_Pos ( 0 )
#define SXLIB_COMM_SPI_CONTROLLER_CONFIG_FLAGS_ENABLE_IRQ \
    ( 0x01UL << SXLIB_COMM_SPI_CONTROLLER_CONFIG_FLAGS_ENABLE_IRQ_Pos )

// NOTE: The fields in comments are reserved by the STM32 HAL!!
// #define SXLIB_COMM_SPI_DEVICE_CONFIG_FLAGS_PHASE_2EDGE_Pos (0)
// #define SXLIB_COMM_SPI_DEVICE_CONFIG_FLAGS_POLARITY_HIGH_Pos (1)
// #define SXLIB_COMM_SPI_DEVICE_CONFIG_FLAGS_MSTR_Pos (2)
// #define SXLIB_COMM_SPI_DEVICE_CONFIG_FLAGS_RATE_Pos (3)
#define SXLIB_COMM_SPI_DEVICE_CONFIG_FLAGS_CS_ACTIVE_HIGH_Pos ( 6 )
#define SXLIB_COMM_SPI_DEVICE_CONFIG_FLAGS_CS_ACTIVE_HIGH_Msk \
    ( 0x01UL << SXLIB_COMM_SPI_DEVICE_CONFIG_FLAGS_CS_ACTIVE_HIGH_Pos )
#define SXLIB_COMM_SPI_DEVICE_CONFIG_FLAGS_CS_ACTIVE_HIGH SXLIB_COMM_SPI_DEVICE_CONFIG_FLAGS_CS_ACTIVE_HIGH_Msk
// #define SXLIB_COMM_SPI_DEVICE_CONFIG_FLAGS_LSBFIRST_Pos (7)
// #define SXLIB_COMM_SPI_DEVICE_CONFIG_FLAGS_SSI_Pos (8)

// This can be const
struct sxlib_Comm_Spi_controller_init
{
    SPI_InitTypeDef HAL_init;
};

extern const DMA_InitTypeDef sxlib_Comm_Dpi_DMA_tx_init;
extern const DMA_InitTypeDef sxlib_Comm_Dpi_DMA_rx_init;

struct sxlib_Comm_Spi_controller_DMA_config
{
    DMA_HandleTypeDef*   handle;
    DMA_Channel_TypeDef* channel;
    uint32_t             request;
    IRQn_Type            dma_IRQn;
};

struct sxlib_Comm_Spi_controller_config
{
    GPIO_TypeDef* sck_port;
    GPIO_TypeDef* miso_port;
    GPIO_TypeDef* mosi_port;

    const struct sxlib_Comm_Spi_controller_DMA_config* DMA_rx_config;
    const struct sxlib_Comm_Spi_controller_DMA_config* DMA_tx_config;

    IRQn_Type spi_IRQn;

    uint8_t flags;

    uint8_t sck_alternate;
    uint8_t miso_alternate;
    uint8_t mosi_alternate;

    uint8_t sck_pin;
    uint8_t miso_pin;
    uint8_t mosi_pin;
};

struct sxlib_Comm_Spi_controller
{
    // handle MUST be the first element of this struct
    SPI_HandleTypeDef HAL_handle;

    const struct sxlib_Comm_Spi_controller_config* config;

    // For device configuration caching
    const struct sxlib_Comm_Spi_device_inst* last_device;
};

// This can be const
struct sxlib_Comm_Spi_device_config
{
    GPIO_TypeDef* ss_port;
    uint16_t      flags;
    uint8_t       ss_pin;
};

// This can be const
struct sxlib_Comm_Spi_device_inst
{
    struct sxlib_Comm_Spi_controller*          cont;
    const struct sxlib_Comm_Spi_device_config* config;
};

#endif  // SXLIB_INCLUDE_ARCH_CORTEXM_MCUFAMILY_STM32_SXLIB_COMM_SPI_SPI_IMPL_H_
