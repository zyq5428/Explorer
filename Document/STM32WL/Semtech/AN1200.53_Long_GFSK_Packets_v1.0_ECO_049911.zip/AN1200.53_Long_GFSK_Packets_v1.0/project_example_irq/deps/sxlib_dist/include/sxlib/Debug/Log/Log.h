/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_GENERIC_SXLIB_DEBUG_LOG_LOG_H_
#define SXLIB_INCLUDE_GENERIC_SXLIB_DEBUG_LOG_LOG_H_

#include <sxlib/Debug/Log/Generic_Log.h>

#endif  // SXLIB_INCLUDE_GENERIC_SXLIB_DEBUG_LOG_LOG_H_
