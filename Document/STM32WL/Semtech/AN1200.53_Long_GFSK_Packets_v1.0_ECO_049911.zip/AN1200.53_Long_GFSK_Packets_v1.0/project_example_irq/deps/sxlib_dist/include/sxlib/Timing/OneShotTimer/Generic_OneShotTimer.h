/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_GENERIC_SXLIB_TIMING_ONESHOTTIMER_GENERIC_ONESHOTTIMER_H_
#define SXLIB_INCLUDE_GENERIC_SXLIB_TIMING_ONESHOTTIMER_GENERIC_ONESHOTTIMER_H_

#include <stdint.h>

#include <sxlib/Timing/OneShotTimerBase/Generic_OneShotTimerBase.h>
#include <sxlib/System/EventsBase/Generic_EventsBase.h>

typedef struct sxlib_Timing_OneShotTimerBase* sxlib_Timing_OneShotTimer_t;

#ifdef __cplusplus
extern "C" {
#endif

void         sxlib_Timing_OneShotTimer_insert( sxlib_Timing_OneShotTimer_t timer, int ticks );
int          sxlib_Timing_OneShotTimer_delete( sxlib_Timing_OneShotTimer_t timer );
void         sxlib_Timing_OneShotTimer_process( int max_wait );
void         sxlib_Timing_OneShotTimer_init( sxlib_System_Events_id_t events );
unsigned int sxlib_Timing_OneShotTimer_get_tick_freq_in_log2( );
uint32_t     sxlib_Timing_OneShotTimer_mibisec_to_ticks( uint32_t x );
uint32_t     sxlib_Timing_OneShotTimer_ticks_to_mibisec( uint32_t x );
uint32_t     sxlib_Timing_OneShotTimer_millisec_to_ticks( uint32_t x );
uint32_t     sxlib_Timing_OneShotTimer_ticks_to_millisec( uint32_t x );

#ifdef __cplusplus
}
#endif

#endif  // SXLIB_INCLUDE_GENERIC_SXLIB_TIMING_ONESHOTTIMER_GENERIC_ONESHOTTIMER_H_
