/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_ARCH_CORTEXM4_MCUFAMILY_STM32L4XX_MCU_STM32L476XX_BOARD_NUCLEOL476RGE406V03ANODISPLAY_SXLIB_COMM_SPIDRIVER_SPIDRIVER_H_
#define SXLIB_INCLUDE_ARCH_CORTEXM4_MCUFAMILY_STM32L4XX_MCU_STM32L476XX_BOARD_NUCLEOL476RGE406V03ANODISPLAY_SXLIB_COMM_SPIDRIVER_SPIDRIVER_H_

#include <sxlib/Comm/SpiDriver/Board_SpiDriver.h>

#endif  // SXLIB_INCLUDE_ARCH_CORTEXM4_MCUFAMILY_STM32L4XX_MCU_STM32L476XX_BOARD_NUCLEOL476RGE406V03ANODISPLAY_SXLIB_COMM_SPIDRIVER_SPIDRIVER_H_
