/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <sxlib/Debug/Assert/Assert.h>
#include <../CortexM/McuFamily/STM32/sxlib/Comm/Uart/Uart_impl.h>

// ST HAL requires these to be implemented for configuration
void HAL_UART_MspInit( UART_HandleTypeDef* huart )
{
    struct sxlib_Comm_Uart_inst* cont = ( struct sxlib_Comm_Uart_inst* ) huart;

    GPIO_InitTypeDef GPIO_InitStruct;

    GPIO_InitStruct.Mode  = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull  = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;

    if( cont->config->tx_port )
    {
        GPIO_InitStruct.Pin       = ( 1 << cont->config->tx_pin );
        GPIO_InitStruct.Alternate = cont->config->tx_alternate;
        HAL_GPIO_Init( cont->config->tx_port, &GPIO_InitStruct );
    }

    if( cont->config->rx_port )
    {
        GPIO_InitStruct.Pin       = ( 1 << cont->config->rx_pin );
        GPIO_InitStruct.Alternate = cont->config->rx_alternate;
        HAL_GPIO_Init( cont->config->rx_port, &GPIO_InitStruct );
    }
}

// ST HAL requires these to be implemented for configuration
void HAL_UART_MspDeInit( UART_HandleTypeDef* huart )
{
    struct sxlib_Comm_Uart_inst* cont = ( struct sxlib_Comm_Uart_inst* ) huart;

#ifdef __HAL_RCC_USART1_FORCE_RESET
    if( huart->Instance == USART1 )
    {
        __HAL_RCC_USART1_FORCE_RESET( );
        __HAL_RCC_USART1_RELEASE_RESET( );
    }
#endif
#ifdef __HAL_RCC_USART2_FORCE_RESET
    if( huart->Instance == USART2 )
    {
        __HAL_RCC_USART2_FORCE_RESET( );
        __HAL_RCC_USART2_RELEASE_RESET( );
    }
#endif
#ifdef __HAL_RCC_USART3_FORCE_RESET
    if( huart->Instance == USART3 )
    {
        __HAL_RCC_USART3_FORCE_RESET( );
        __HAL_RCC_USART3_RELEASE_RESET( );
    }
#endif

    if( cont->config->tx_port )
    {
        HAL_GPIO_DeInit( cont->config->tx_port, ( 1 << cont->config->tx_pin ) );
    }

    if( cont->config->rx_port )
    {
        HAL_GPIO_DeInit( cont->config->rx_port, ( 1 << cont->config->rx_pin ) );
    }
}

void sxlib_Comm_Uart_init( struct sxlib_Comm_Uart_inst* inst, USART_TypeDef* hw_inst,
                           const struct sxlib_Comm_Uart_init* init, const struct sxlib_Comm_Uart_config* config )
{
    inst->config = config;

    inst->HAL_handle.Instance = hw_inst;
    inst->HAL_handle.Init     = init->HAL_init;

    HAL_StatusTypeDef retval = HAL_UART_Init( &inst->HAL_handle );
    ( void ) retval;
    sxlib_assert( retval == HAL_OK );
}

void sxlib_Comm_Uart_write( struct sxlib_Comm_Uart_inst* dev, const uint8_t* data, unsigned int len )
{
    HAL_StatusTypeDef retval = HAL_UART_Transmit( &dev->HAL_handle, ( uint8_t* ) data, len, HAL_MAX_DELAY );
    ( void ) retval;
    sxlib_assert( retval == HAL_OK );
}
