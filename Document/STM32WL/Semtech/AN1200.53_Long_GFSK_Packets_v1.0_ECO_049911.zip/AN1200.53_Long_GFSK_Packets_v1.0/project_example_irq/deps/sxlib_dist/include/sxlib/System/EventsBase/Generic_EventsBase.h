/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_GENERIC_SXLIB_SYSTEM_EVENTSBASE_GENERIC_EVENTSBASE_H_
#define SXLIB_INCLUDE_GENERIC_SXLIB_SYSTEM_EVENTSBASE_GENERIC_EVENTSBASE_H_

#include <stdint.h>

// Reserved system event IDs: ID <= 30
#define SXLIB_SYSTEM_EVENTSBASE_TIMER ( 30 )
#define SXLIB_SYSTEM_EVENTSBASE_DEBOUNCER ( 29 )
#define SXLIB_SYSTEM_EVENTSBASE_RADIO0_BUSY ( 28 )
#define SXLIB_SYSTEM_EVENTSBASE_RADIO0_IRQ ( 27 )
#define SXLIB_SYSTEM_EVENTSBASE_RADIO1_BUSY ( 26 )
#define SXLIB_SYSTEM_EVENTSBASE_RADIO1_IRQ ( 25 )

#define SXLIB_SYSTEM_EVENTSBASE_TIMER_MASK ( 1 << SXLIB_SYSTEM_EVENTSBASE_TIMER )
#define SXLIB_SYSTEM_EVENTSBASE_DEBOUNCER_MASK ( 1 << SXLIB_SYSTEM_EVENTSBASE_DEBOUNCER )
#define SXLIB_SYSTEM_EVENTSBASE_RADIO0_BUSY_MASK ( 1 << SXLIB_SYSTEM_EVENTSBASE_RADIO0_BUSY )
#define SXLIB_SYSTEM_EVENTSBASE_RADIO0_IRQ_MASK ( 1 << SXLIB_SYSTEM_EVENTSBASE_RADIO0_IRQ )
#define SXLIB_SYSTEM_EVENTSBASE_RADIO1_BUSY_MASK ( 1 << SXLIB_SYSTEM_EVENTSBASE_RADIO1_BUSY )
#define SXLIB_SYSTEM_EVENTSBASE_RADIO1_IRQ_MASK ( 1 << SXLIB_SYSTEM_EVENTSBASE_RADIO1_IRQ )

typedef void* sxlib_System_Events_id_t;

// TODO(dhoover): Fix this. It should just be a return type from the set/clear methods, nothing to do with event storage
// and manipulation.
typedef volatile uint32_t sxlib_System_EventsBase_eventmask;

struct sxlib_System_EventsBase_config;
struct sxlib_System_EventsBase_state;

typedef void* sxlib_System_EventsBase_events_t;

#ifdef __cplusplus
extern "C" {
#endif
sxlib_System_EventsBase_eventmask sxlib_System_EventsBase_event_set( struct sxlib_System_EventsBase_state* event );
sxlib_System_EventsBase_eventmask sxlib_System_EventsBase_event_clear( struct sxlib_System_EventsBase_state* event );
sxlib_System_EventsBase_eventmask sxlib_System_EventsBase_wait_on_event( struct sxlib_System_EventsBase_state* event );
sxlib_System_EventsBase_eventmask sxlib_System_EventsBase_wait_on_any_event( sxlib_System_EventsBase_events_t  events,
                                                                             sxlib_System_EventsBase_eventmask mask );
#ifdef __cplusplus
}
#endif

#endif  // SXLIB_INCLUDE_GENERIC_SXLIB_SYSTEM_EVENTSBASE_GENERIC_EVENTSBASE_H_
