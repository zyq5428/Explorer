/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <../CortexM/McuFamily/STM32/sxlib/Comm/Uart/Uart_impl.h>
#include <Module/Uart0/sxlib/Comm/Uart/Uart.h>

const struct sxlib_Comm_Uart_init sxlib_Module_Uart0_Comm_Uart_init = {
    .HAL_init =
        {
            .BaudRate   = 115200,
            .WordLength = UART_WORDLENGTH_8B,
            .StopBits   = UART_STOPBITS_1,
            .Parity     = UART_PARITY_NONE,
            .HwFlowCtl  = UART_HWCONTROL_NONE,
            .Mode       = UART_MODE_TX_RX,
        },
};

const struct sxlib_Comm_Uart_config sxlib_Module_Uart0_Comm_Uart_config = {
    .tx_port = GPIOA,
    .rx_port = GPIOA,

    .tx_alternate = GPIO_AF7_USART2,
    .rx_alternate = GPIO_AF7_USART2,

    .tx_pin = 2,
    .rx_pin = 3,
};

struct sxlib_Comm_Uart_inst sxlib_Module_Uart0_Comm_Uart_inst;

void sxlib_Module_Uart0_Comm_Uart_init_all( )
{
    sxlib_Comm_Uart_init( &sxlib_Module_Uart0_Comm_Uart_inst, USART2, &sxlib_Module_Uart0_Comm_Uart_init,
                          &sxlib_Module_Uart0_Comm_Uart_config );
}
