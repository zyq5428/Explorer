/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <sxlib/Timing/Busywait/Generic_Busywait.h>

#include <sxlib/Extern/HAL.h>

void sxlib_Timing_Busywait_precise_waitMibiSec( uint16_t mibiSec )
{
    HAL_Delay( SXLIB_TIMING_MIBISEC_TO_MILLISEC( mibiSec ) );
}

void sxlib_Timing_Busywait_precise_waitMilliSec( uint16_t milliSec ) { HAL_Delay( milliSec ); }
