/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_GENERIC_SXLIB_RADIO_SX126X_GENERIC_SX126X_H_
#define SXLIB_INCLUDE_GENERIC_SXLIB_RADIO_SX126X_GENERIC_SX126X_H_

#include <sx126x.h>

struct sxlib_Radio_Sx126x_inst;

#ifdef __cplusplus
extern "C" {
#endif
void sxlib_Radio_Sx126x_reset( const struct sxlib_Radio_Sx126x_inst* inst );
void sxlib_Radio_Sx126x_init( const struct sxlib_Radio_Sx126x_inst* inst );
void sxlib_Radio_Sx126x_wake( const struct sxlib_Radio_Sx126x_inst* inst );
#ifdef __cplusplus
}
#endif

#endif  // SXLIB_INCLUDE_GENERIC_SXLIB_RADIO_SX126X_GENERIC_SX126X_H_
