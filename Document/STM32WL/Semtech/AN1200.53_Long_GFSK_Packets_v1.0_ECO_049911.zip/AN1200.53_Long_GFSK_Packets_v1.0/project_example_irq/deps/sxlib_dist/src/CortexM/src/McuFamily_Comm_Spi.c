/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <sxlib/Debug/Assert/Assert.h>
#include <../CortexM/McuFamily/STM32/sxlib/Comm/Spi/Spi_impl.h>

const DMA_InitTypeDef sxlib_Comm_Dpi_DMA_tx_init = {
    .Request             = 0,
    .Direction           = DMA_MEMORY_TO_PERIPH,
    .PeriphInc           = DMA_PINC_DISABLE,
    .MemInc              = DMA_MINC_ENABLE,
    .PeriphDataAlignment = DMA_PDATAALIGN_BYTE,
    .MemDataAlignment    = DMA_MDATAALIGN_BYTE,
    .Mode                = DMA_NORMAL,
    .Priority            = DMA_PRIORITY_LOW,
};

const DMA_InitTypeDef sxlib_Comm_Dpi_DMA_rx_init = {
    .Request             = 0,
    .Direction           = DMA_PERIPH_TO_MEMORY,
    .PeriphInc           = DMA_PINC_DISABLE,
    .MemInc              = DMA_MINC_ENABLE,
    .PeriphDataAlignment = DMA_PDATAALIGN_BYTE,
    .MemDataAlignment    = DMA_MDATAALIGN_BYTE,
    .Mode                = DMA_NORMAL,
    .Priority            = DMA_PRIORITY_HIGH,
};

// ST HAL requires these to be implemented for configuration
void HAL_SPI_MspInit( SPI_HandleTypeDef* hspi )
{
    struct sxlib_Comm_Spi_controller* cont = ( struct sxlib_Comm_Spi_controller* ) hspi;

    GPIO_InitTypeDef GPIO_InitStruct;

    GPIO_InitStruct.Mode  = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull  = GPIO_PULLDOWN;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;

    /* SPI SCK GPIO pin configuration  */
    if( cont->config->sck_port )
    {
        GPIO_InitStruct.Pin       = ( 1 << cont->config->sck_pin );
        GPIO_InitStruct.Alternate = cont->config->sck_alternate;
        HAL_GPIO_Init( cont->config->sck_port, &GPIO_InitStruct );
    }

    /* SPI MISO GPIO pin configuration  */
    if( cont->config->miso_port )
    {
        GPIO_InitStruct.Pin       = ( 1 << cont->config->miso_pin );
        GPIO_InitStruct.Alternate = cont->config->miso_alternate;
        HAL_GPIO_Init( cont->config->miso_port, &GPIO_InitStruct );
    }

    /* SPI MOSI GPIO pin configuration  */
    if( cont->config->mosi_port )
    {
        GPIO_InitStruct.Pin       = ( 1 << cont->config->mosi_pin );
        GPIO_InitStruct.Alternate = cont->config->mosi_alternate;
        HAL_GPIO_Init( cont->config->mosi_port, &GPIO_InitStruct );
    }

    if( cont->config->DMA_rx_config )
    {
        cont->config->DMA_rx_config->handle->Instance     = cont->config->DMA_rx_config->channel;
        cont->config->DMA_tx_config->handle->Init         = sxlib_Comm_Dpi_DMA_rx_init;
        cont->config->DMA_tx_config->handle->Init.Request = cont->config->DMA_rx_config->request;
        HAL_DMA_Init( cont->config->DMA_rx_config->handle );
        __HAL_LINKDMA( hspi, hdmarx, *cont->config->DMA_rx_config->handle );
        HAL_NVIC_EnableIRQ( cont->config->DMA_rx_config->dma_IRQn );
    }

    if( cont->config->DMA_tx_config )
    {
        cont->config->DMA_tx_config->handle->Instance     = cont->config->DMA_tx_config->channel;
        cont->config->DMA_tx_config->handle->Init         = sxlib_Comm_Dpi_DMA_tx_init;
        cont->config->DMA_tx_config->handle->Init.Request = cont->config->DMA_tx_config->request;
        HAL_DMA_Init( cont->config->DMA_tx_config->handle );
        __HAL_LINKDMA( hspi, hdmatx, *cont->config->DMA_tx_config->handle );
        HAL_NVIC_EnableIRQ( cont->config->DMA_tx_config->dma_IRQn );
    }

    if( cont->config->flags & SXLIB_COMM_SPI_CONTROLLER_CONFIG_FLAGS_ENABLE_IRQ )
    {
        HAL_NVIC_EnableIRQ( cont->config->spi_IRQn );
    }
}

// ST HAL requires these to be implemented for configuration
void HAL_SPI_MspDeInit( SPI_HandleTypeDef* hspi )
{
    struct sxlib_Comm_Spi_controller* cont = ( struct sxlib_Comm_Spi_controller* ) hspi;

#ifdef __HAL_RCC_SPI1_FORCE_RESET
    if( hspi->Instance == SPI1 )
    {
        __HAL_RCC_SPI1_FORCE_RESET( );
        __HAL_RCC_SPI1_RELEASE_RESET( );
    }
#endif
#ifdef __HAL_RCC_SPI2_FORCE_RESET
    if( hspi->Instance == SPI2 )
    {
        __HAL_RCC_SPI2_FORCE_RESET( );
        __HAL_RCC_SPI2_RELEASE_RESET( );
    }
#endif
#ifdef __HAL_RCC_SPI3_FORCE_RESET
    if( hspi->Instance == SPI3 )
    {
        __HAL_RCC_SPI3_FORCE_RESET( );
        __HAL_RCC_SPI3_RELEASE_RESET( );
    }
#endif
#ifdef __HAL_RCC_SPI4_FORCE_RESET
    if( hspi->Instance == SPI4 )
    {
        __HAL_RCC_SPI4_FORCE_RESET( );
        __HAL_RCC_SPI4_RELEASE_RESET( );
    }
#endif

    if( cont->config->sck_port )
    {
        HAL_GPIO_DeInit( cont->config->sck_port, ( 1 << cont->config->sck_pin ) );
    }

    if( cont->config->miso_port )
    {
        HAL_GPIO_DeInit( cont->config->miso_port, ( 1 << cont->config->miso_pin ) );
    }

    if( cont->config->mosi_port )
    {
        HAL_GPIO_DeInit( cont->config->mosi_port, ( 1 << cont->config->mosi_pin ) );
    }

    if( cont->config->DMA_rx_config )
    {
        HAL_DMA_DeInit( cont->config->DMA_rx_config->handle );
        HAL_NVIC_DisableIRQ( cont->config->DMA_rx_config->dma_IRQn );
    }

    if( cont->config->DMA_tx_config )
    {
        HAL_DMA_DeInit( cont->config->DMA_tx_config->handle );
        HAL_NVIC_DisableIRQ( cont->config->DMA_tx_config->dma_IRQn );
    }

    if( cont->config->flags & SXLIB_COMM_SPI_CONTROLLER_CONFIG_FLAGS_ENABLE_IRQ )
    {
        HAL_NVIC_DisableIRQ( cont->config->spi_IRQn );
    }
}

void sxlib_Comm_Spi_controller_init( struct sxlib_Comm_Spi_controller* cont, SPI_TypeDef* hw_cont,
                                     const struct sxlib_Comm_Spi_controller_init*   init,
                                     const struct sxlib_Comm_Spi_controller_config* config )
{
    cont->last_device = 0;
    cont->config      = config;

    cont->HAL_handle.Instance = hw_cont;
    cont->HAL_handle.Init     = init->HAL_init;

    HAL_StatusTypeDef retval = HAL_SPI_Init( &cont->HAL_handle );
    ( void ) retval;
    sxlib_assert( retval == HAL_OK );
}

void sxlib_Comm_Spi_controller_deinit( struct sxlib_Comm_Spi_controller* cont )
{
    HAL_StatusTypeDef retval = HAL_SPI_DeInit( &cont->HAL_handle );
    ( void ) retval;
    sxlib_assert( retval == HAL_OK );
}

void sxlib_Comm_Spi_device_init( const struct sxlib_Comm_Spi_device_inst* device )
{
    GPIO_InitTypeDef init = {
        .Pin   = ( 1 << device->config->ss_pin ),
        .Mode  = GPIO_MODE_OUTPUT_PP,
        .Pull  = GPIO_NOPULL,
        .Speed = GPIO_SPEED_FREQ_MEDIUM,
    };
    HAL_GPIO_Init( device->config->ss_port, &init );
    sxlib_Comm_Spi_nCS( device );
}

int sxlib_Comm_Spi_CS( const struct sxlib_Comm_Spi_device_inst* dev )
{
    HAL_GPIO_WritePin(
        dev->config->ss_port, ( 1 << dev->config->ss_pin ),
        ( dev->config->flags & SXLIB_COMM_SPI_DEVICE_CONFIG_FLAGS_CS_ACTIVE_HIGH ) ? GPIO_PIN_SET : GPIO_PIN_RESET );
    return ( 0 );
}

void sxlib_Comm_Spi_nCS( const struct sxlib_Comm_Spi_device_inst* dev )
{
    HAL_GPIO_WritePin(
        dev->config->ss_port, ( 1 << dev->config->ss_pin ),
        ( dev->config->flags & SXLIB_COMM_SPI_DEVICE_CONFIG_FLAGS_CS_ACTIVE_HIGH ) ? GPIO_PIN_RESET : GPIO_PIN_SET );
}

static void sxlib_Comm_Spi_configure( const struct sxlib_Comm_Spi_device_inst* dev )
{
    if( dev->cont->last_device != dev )
    {
        // Device speed, phase, and polarity are cached here
        uint32_t cr1 = ( ( uint32_t ) dev->config->flags & ~SXLIB_COMM_SPI_DEVICE_CONFIG_FLAGS_CS_ACTIVE_HIGH_Msk ) |
                       dev->cont->HAL_handle.Init.Direction | ( dev->cont->HAL_handle.Init.NSS & SPI_CR1_SSM ) |
                       dev->cont->HAL_handle.Init.CRCCalculation;
        WRITE_REG( dev->cont->HAL_handle.Instance->CR1, cr1 );
        dev->cont->last_device = dev;
    }
}

void sxlib_Comm_Spi_read( const struct sxlib_Comm_Spi_device_inst* dev, uint8_t* data, unsigned int len )
{
    sxlib_Comm_Spi_configure( dev );
    HAL_StatusTypeDef retval = HAL_SPI_Receive0( &dev->cont->HAL_handle, data, len, HAL_MAX_DELAY );
    ( void ) retval;
    sxlib_assert( retval == HAL_OK );
}

void sxlib_Comm_Spi_write( const struct sxlib_Comm_Spi_device_inst* dev, const uint8_t* data, unsigned int len )
{
    sxlib_Comm_Spi_configure( dev );
    HAL_StatusTypeDef retval = HAL_SPI_Transmit( &dev->cont->HAL_handle, ( uint8_t* ) data, len, HAL_MAX_DELAY );
    ( void ) retval;
    sxlib_assert( retval == HAL_OK );
}

void sxlib_Comm_Spi_readwrite( const struct sxlib_Comm_Spi_device_inst* dev, uint8_t* data, unsigned int len )
{
    sxlib_Comm_Spi_configure( dev );
    HAL_StatusTypeDef retval = HAL_SPI_TransmitReceive( &dev->cont->HAL_handle, data, data, len, HAL_MAX_DELAY );
    ( void ) retval;
    sxlib_assert( retval == HAL_OK );
}
