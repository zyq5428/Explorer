/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <string.h>

#include <sxlib/System/Startup/Startup_impl.h>
#include <sxlib/System/EventsBase/Rtos_EventsBase_impl.h>

// Reduce size of generated code when using C++ exceptions
char* __cxa_demangle( const char* mangled_name, char* output_buffer, size_t* length, int* status )
{
    strcpy( ( char* ) mangled_name, output_buffer );
    return output_buffer;
}

void initialise_monitor_handles( void );

static sxlib_System_EventsBase_BackingStore_t events_backing_store;
struct sxlib_System_Startup_args              sxlib_System_Startup_args_inst;

void sxlib_System_Startup( app_main_fptr app_main )
{
#ifdef ENABLE_SEMIHOSTING
    initialise_monitor_handles( );
#endif

    sxlib_System_Startup_args_inst.system_events = &events_backing_store;
    app_main( &sxlib_System_Startup_args_inst );
    while( 1 )
    {
    }
}
