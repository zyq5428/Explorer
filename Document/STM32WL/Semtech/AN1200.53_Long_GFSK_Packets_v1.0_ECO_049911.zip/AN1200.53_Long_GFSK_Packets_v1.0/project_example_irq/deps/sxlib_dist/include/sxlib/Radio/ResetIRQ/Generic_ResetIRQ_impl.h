/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_GENERIC_SXLIB_RADIO_RESETIRQ_GENERIC_RESETIRQ_IMPL_H_
#define SXLIB_INCLUDE_GENERIC_SXLIB_RADIO_RESETIRQ_GENERIC_RESETIRQ_IMPL_H_

#include <sxlib/Radio/ResetIRQ/Generic_ResetIRQ.h>
#include <sxlib/System/IRQLine/Generic_IRQLine.h>
#include <sxlib/Gpio/Output/Generic_Output.h>

struct sxlib_Radio_ResetIRQ_inst
{
    struct sxlib_System_IRQLine_inst*    radio_IRQ_inst;
    const struct sxlib_Gpio_Output_inst* radio_reset_output;
};

#endif  // SXLIB_INCLUDE_GENERIC_SXLIB_RADIO_RESETIRQ_GENERIC_RESETIRQ_IMPL_H_
