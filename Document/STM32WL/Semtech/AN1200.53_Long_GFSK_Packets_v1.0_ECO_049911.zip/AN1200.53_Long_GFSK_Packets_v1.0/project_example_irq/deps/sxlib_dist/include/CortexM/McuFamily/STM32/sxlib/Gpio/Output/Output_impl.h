/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_ARCH_CORTEXM_MCUFAMILY_STM32_SXLIB_GPIO_OUTPUT_OUTPUT_IMPL_H_
#define SXLIB_INCLUDE_ARCH_CORTEXM_MCUFAMILY_STM32_SXLIB_GPIO_OUTPUT_OUTPUT_IMPL_H_

#include <../CortexM/McuFamily/STM32/sxlib/Gpio/Output/Output.h>
#include <sxlib/Extern/McuFamily_HAL.h>

struct sxlib_Gpio_Output_inst
{
    GPIO_TypeDef* port;
    uint8_t       pin;
};

#endif  // SXLIB_INCLUDE_ARCH_CORTEXM_MCUFAMILY_STM32_SXLIB_GPIO_OUTPUT_OUTPUT_IMPL_H_
