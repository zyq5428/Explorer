/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_GENERIC_SXLIB_SYSTEM_BSP_GENERIC_BSP_H_
#define SXLIB_INCLUDE_GENERIC_SXLIB_SYSTEM_BSP_GENERIC_BSP_H_

#include <stdbool.h>

#include <sxlib/System/EventsBase/Generic_EventsBase.h>

#define SXLIB_SYSTEM_BSP_INIT_CLOCK_FREQ_128 ( 7 )
#define SXLIB_SYSTEM_BSP_INIT_CLOCK_FREQ_256 ( 8 )
#define SXLIB_SYSTEM_BSP_INIT_CLOCK_FREQ_512 ( 9 )
#define SXLIB_SYSTEM_BSP_INIT_CLOCK_FREQ_1024 ( 10 )
#define SXLIB_SYSTEM_BSP_INIT_CLOCK_FREQ_2048 ( 11 )
#define SXLIB_SYSTEM_BSP_INIT_CLOCK_FREQ_4096 ( 12 )
#define SXLIB_SYSTEM_BSP_INIT_CLOCK_FREQ_8192 ( 13 )
#define SXLIB_SYSTEM_BSP_INIT_CLOCK_FREQ_16384 ( 14 )
#define SXLIB_SYSTEM_BSP_INIT_CLOCK_FREQ_32768 ( 15 )

#ifdef __cplusplus
extern "C" {
#endif
void sxlib_System_BSP_init_all( sxlib_System_Events_id_t events, unsigned int base_2_clock_freq_exponent, bool lcd );
void sxlib_System_BSP_BoardVariant_preinit( sxlib_System_Events_id_t events, unsigned int base_2_clock_freq_exponent,
                                            bool lcd );
void sxlib_System_BSP_BoardVariant_postinit( sxlib_System_Events_id_t events, unsigned int base_2_clock_freq_exponent,
                                             bool lcd );
#ifdef __cplusplus
}
#endif

#endif  // SXLIB_INCLUDE_GENERIC_SXLIB_SYSTEM_BSP_GENERIC_BSP_H_
