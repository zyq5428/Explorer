/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <sxlib/System/Sleep/Generic_Sleep.h>
#include <sxlib/System/EventsBase/EventsBase_impl.h>
#include <sxlib/Extern/HAL.h>

void sxlib_System_EventsBase_init( struct sxlib_System_EventsBase_state* event, sxlib_System_Events_id_t flags )
{
    event->flags = flags;
}

/** \note This can be called from interrupt service routines or user code. \TODO This should be optimized for Cortex M4.
 */
sxlib_System_EventsBase_eventmask sxlib_System_EventsBase_event_set( struct sxlib_System_EventsBase_state* event )
{
    sxlib_System_EventsBase_eventmask retval;

    uint32_t primask = __get_PRIMASK( );
    __disable_irq( );

    retval = *event->flags;
    *event->flags |= ( 1 << event->config->id );

    if( primask == 0U )
    {
        __enable_irq( );
    }

    return ( retval );
}

/** \note This can be called from interrupt service routines or user code. \TODO This should be optimized for Cortex M4.
 */
sxlib_System_EventsBase_eventmask sxlib_System_EventsBase_event_clear( struct sxlib_System_EventsBase_state* event )
{
    sxlib_System_EventsBase_eventmask retval;

    uint32_t primask = __get_PRIMASK( );
    __disable_irq( );

    retval = *event->flags;
    *event->flags &= ~( 1 << event->config->id );

    if( primask == 0U )
    {
        __enable_irq( );
    }

    return ( retval );
}

sxlib_System_EventsBase_eventmask sxlib_System_EventsBase_wait_on_any_event( sxlib_System_EventsBase_events_t  events,
                                                                             sxlib_System_EventsBase_eventmask mask )
{
    sxlib_System_EventsBase_eventmask retval;

    volatile sxlib_System_EventsBase_eventmask* e = get_events( events );

    while( 1 )
    {
        __disable_irq( );
        if( *e & mask )
        {
            retval = *e;
            *e &= ~mask;
            break;
        }
        else
        {
#if( 1 )
            sxlib_System_Sleep_enter( );
#else
            __enable_irq( );
#endif
        }
    }

    __enable_irq( );
    return ( retval );
    ;
}

sxlib_System_EventsBase_eventmask sxlib_System_EventsBase_wait_on_event( struct sxlib_System_EventsBase_state* event )
{
    return ( sxlib_System_EventsBase_wait_on_any_event( ( void* ) event->flags, ( 1 << event->config->id ) ) );
}
