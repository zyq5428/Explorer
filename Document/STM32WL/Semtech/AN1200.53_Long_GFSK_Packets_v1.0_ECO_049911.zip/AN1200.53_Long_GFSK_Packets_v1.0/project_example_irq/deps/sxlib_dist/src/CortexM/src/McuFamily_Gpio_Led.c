/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <sxlib/Gpio/Led/McuFamily_Led_impl.h>
#include <sxlib/Extern/McuFamily_HAL.h>
#include <sxlib/Extern/Stm32lLl.h>

void sxlib_Gpio_Led_init( const struct sxlib_Gpio_Led_dev* dev )
{
    GPIO_InitTypeDef init = {
        .Pin   = ( 1 << dev->pin ),
        .Mode  = GPIO_MODE_OUTPUT_PP,
        .Pull  = GPIO_NOPULL,
        .Speed = GPIO_SPEED_FREQ_LOW,
    };
    HAL_GPIO_Init( dev->port, &init );
}

void sxlib_Gpio_Led_on( const struct sxlib_Gpio_Led_dev* dev )
{
    if( dev->flags & SXLIB_GPIO_LED_DEV_FLAGS_ACTIVE_LOW )
    {
        LL_GPIO_ResetOutputPin( dev->port, ( 1 << dev->pin ) );
    }
    else
    {
        LL_GPIO_SetOutputPin( dev->port, ( 1 << dev->pin ) );
    }
}

void sxlib_Gpio_Led_off( const struct sxlib_Gpio_Led_dev* dev )
{
    if( dev->flags & SXLIB_GPIO_LED_DEV_FLAGS_ACTIVE_LOW )
    {
        LL_GPIO_SetOutputPin( dev->port, ( 1 << dev->pin ) );
    }
    else
    {
        LL_GPIO_ResetOutputPin( dev->port, ( 1 << dev->pin ) );
    }
}

void sxlib_Gpio_Led_toggle( const struct sxlib_Gpio_Led_dev* dev )
{
    if( LL_GPIO_IsOutputPinSet( dev->port, ( 1 << dev->pin ) ) )
    {
        LL_GPIO_ResetOutputPin( dev->port, ( 1 << dev->pin ) );
    }
    else
    {
        LL_GPIO_SetOutputPin( dev->port, ( 1 << dev->pin ) );
    }
}
