/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <../CortexM/McuFamily/STM32/sxlib/Gpio/Output/Output_impl.h>

const struct sxlib_Gpio_Output_inst sxlib_Module_AntennaSwitchRadio0_Gpio_Output = {
    // Arduino A3 --> STM32 PB0
    .port = GPIOB,
    .pin  = 0,
};
