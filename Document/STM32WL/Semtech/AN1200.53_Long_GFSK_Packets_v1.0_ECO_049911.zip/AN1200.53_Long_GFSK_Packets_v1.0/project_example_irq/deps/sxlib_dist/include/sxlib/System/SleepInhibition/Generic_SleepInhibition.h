/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_GENERIC_SXLIB_SYSTEM_SLEEPINHIBITION_GENERIC_SLEEPINHIBITION_H_
#define SXLIB_INCLUDE_GENERIC_SXLIB_SYSTEM_SLEEPINHIBITION_GENERIC_SLEEPINHIBITION_H_

#include <stdint.h>

enum sxlib_System_SleepInhibition_class
{
    SXLIB_SYSTEM_SLEEPINHIBITION_CLASS_0,
    SXLIB_SYSTEM_SLEEPINHIBITION_CLASS_1,
    SXLIB_SYSTEM_SLEEPINHIBITION_CLASS_2,
    SXLIB_SYSTEM_SLEEPINHIBITION_SENTINEL,
};

#ifdef __cplusplus
extern "C" {
#endif
void     sxlib_System_SleepInhibition_init( );
uint32_t sxlib_System_SleepInhibition_get_mask( enum sxlib_System_SleepInhibition_class class );
void     sxlib_System_SleepInhibition_inhibit_sleep( enum sxlib_System_SleepInhibition_class class, uint32_t mask );
void     sxlib_System_SleepInhibition_allow_sleep( enum sxlib_System_SleepInhibition_class class, uint32_t mask );
#ifdef __cplusplus
}
#endif

#endif  // SXLIB_INCLUDE_GENERIC_SXLIB_SYSTEM_SLEEPINHIBITION_GENERIC_SLEEPINHIBITION_H_
