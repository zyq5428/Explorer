/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <stdarg.h>
#include <stdio.h>

#include <sxlib/Debug/Log/Generic_Log.h>
#include <Module/Uart0/sxlib/Comm/Uart/Uart.h>

#ifndef SXLIB_DEBUG_LOG_MAX_LENGTH
#define SXLIB_DEBUG_LOG_MAX_LENGTH ( 160 )
#endif

int vsnprintf( char* str, size_t size, const char* format, va_list ap );

void sxlib_Debug_Log_init( ) {}

void sxlib_Debug_Log_log( const char* format, ... )
{
    int  len;
    char buf[SXLIB_DEBUG_LOG_MAX_LENGTH];

    va_list argp;
    va_start( argp, format );
    len = vsnprintf( buf, sizeof( buf ), format, argp );
    va_end( argp );

    if( len >= sizeof( buf ) )
    {
        len = sizeof( buf ) - 1;
    }
    sxlib_Comm_Uart_write( &sxlib_Module_Uart0_Comm_Uart_inst, ( uint8_t* ) buf, len );
}
