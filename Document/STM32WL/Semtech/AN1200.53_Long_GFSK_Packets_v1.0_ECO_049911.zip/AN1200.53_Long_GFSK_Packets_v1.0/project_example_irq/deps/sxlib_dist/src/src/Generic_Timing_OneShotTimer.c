/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
// Add macros for choosing time delays for this timer...

#include <sxlib/Timing/OneShotTimer/Generic_OneShotTimer.h>
#include <sxlib/Timing/OneShotTimerBase/Generic_OneShotTimerBase_impl.h>
#include <sxlib/Timing/LowPowerContinuous/Generic_LowPowerContinuous.h>
#include <sxlib/Timing/SystemTime/Generic_SystemTime.h>

// TODO: Clean this up
uint16_t sxlib_Timing_LowPowerContinuous_get_hardware_time( );

static struct sxlib_Timing_OneShotTimerBase            one_shot_timer_base = { 0 };
static sxlib_Timing_LowPowerContinuous_hardware_time_t last_hardware_time;

sxlib_Timing_SystemTime_absolute_time_t sxlib_Timing_OneShotTimer_system_time;

#include <sxlib/System/EventsBase/Rtos_EventsBase_impl.h>
#include <sxlib/System/EventsBase/EventsBase_impl.h>
const struct sxlib_System_EventsBase_config sxlib_TimingOneShotTimer_EventsBase_config = {
    .id = SXLIB_SYSTEM_EVENTSBASE_TIMER,
};

struct sxlib_System_EventsBase_state sxlib_TimingOneShotTimer_event_state = {
    .config = &sxlib_TimingOneShotTimer_EventsBase_config,
};

sxlib_Timing_SystemTime_absolute_time_t sxlib_Timing_SystemTime_get_time( )
{
    uint32_t delta = sxlib_Timing_LowPowerContinuous_get_time_delta( &last_hardware_time );
    sxlib_Timing_OneShotTimer_system_time += delta;

    sxlib_Timing_OneShotTimerBase_update( &one_shot_timer_base, delta );
    return sxlib_Timing_OneShotTimer_system_time;
}

/*
 * NOTE: update_time must not only update the SystemTime, but it must
 * also call OneShotTimerBase_update().
 *
 * sxlib_Timing_OneShotTimer_sxlib_Timing_SystemTime_get_system_time_internal() needs to be
 * fixed because it doesn't expose delta, which is needed.
 */

// This is not necessary if there is no OS, or if the timer task has
// higher priority than everything else.
#define ENTER_CRITICAL_SECTION( ) \
    do                            \
    {                             \
    } while( 0 )
#define LEAVE_CRITICAL_SECTION( ) \
    do                            \
    {                             \
    } while( 0 )

void sxlib_Timing_OneShotTimer_insert( sxlib_Timing_OneShotTimer_t timer, int ticks )
{
    ENTER_CRITICAL_SECTION( );
    sxlib_Timing_SystemTime_get_time( );
    sxlib_Timing_OneShotTimerBase_insert( &one_shot_timer_base, timer, ticks );
    sxlib_System_EventsBase_event_set( &sxlib_TimingOneShotTimer_event_state );
    LEAVE_CRITICAL_SECTION( );
}

int sxlib_Timing_OneShotTimer_delete( sxlib_Timing_OneShotTimer_t timer )
{
    int retval;

    ENTER_CRITICAL_SECTION( );
    sxlib_Timing_SystemTime_get_time( );
    retval = sxlib_Timing_OneShotTimerBase_delete( &one_shot_timer_base, timer );
    sxlib_System_EventsBase_event_set( &sxlib_TimingOneShotTimer_event_state );
    LEAVE_CRITICAL_SECTION( );

    return retval;
}

int sxlib_Timing_OneShotTimer_process_once( )
{
    int ticks_until_event;

    ENTER_CRITICAL_SECTION( );
    sxlib_Timing_SystemTime_get_time( );
    sxlib_Timing_OneShotTimerBase_execute_callables( &one_shot_timer_base );
    ticks_until_event = sxlib_Timing_OneShotTimerBase_get_delta( &one_shot_timer_base );
    LEAVE_CRITICAL_SECTION( );
    return ticks_until_event;
}

// min_wait should correspond to a longer time duration than 4 cycles
// of the LPTIMER timebase. For 32kHz clock: 122us.
void sxlib_Timing_OneShotTimer_process( int max_wait )
{
    int ticks_until_event;
    int min_wait = sxlib_Timing_LowPowerContinuous_get_minimum_delay( );

    do
    {
        ticks_until_event = sxlib_Timing_OneShotTimer_process_once( );
    } while( ticks_until_event == 0 );

    if( ticks_until_event == ONE_SHOT_TIMER_WAIT_FOREVER )
    {
        return;
    }

    if( ticks_until_event < min_wait )
    {
        // TODO: Implement with low latency systick timer.
        // sxlib_Timing_LowLatencyContinuous_start( ticks_until_event );
        sxlib_Timing_LowPowerContinuous_start_interval_timer( min_wait );
    }
    else
    {
        if( ticks_until_event > max_wait )
        {
            ticks_until_event = max_wait;
        }
        sxlib_Timing_LowPowerContinuous_start_interval_timer( ticks_until_event );
    }
}

void sxlib_Timing_OneShotTimer_init( sxlib_System_Events_id_t events )
{
    sxlib_TimingOneShotTimer_event_state.flags = events;
}

unsigned int sxlib_Timing_OneShotTimer_get_tick_freq_in_log2( )
{
    return sxlib_Timing_LowPowerContinuous_get_clock_frequency( );
}

uint32_t sxlib_Timing_OneShotTimer_mibisec_to_ticks( uint32_t x )
{
    unsigned int N = sxlib_Timing_LowPowerContinuous_get_clock_frequency( );

    if( N >= 10 )
    {
        return x << ( N - 10 );
    }
    else
    {
        return x >> ( 10 - N );
    }
}

uint32_t sxlib_Timing_OneShotTimer_ticks_to_mibisec( uint32_t x )
{
    unsigned int N = sxlib_Timing_LowPowerContinuous_get_clock_frequency( );

    if( 10 >= N )
    {
        return x << ( 10 - N );
    }
    else
    {
        return x >> ( N - 10 );
    }
}

uint32_t sxlib_Timing_OneShotTimer_millisec_to_ticks( uint32_t x )
{
    return ( x << sxlib_Timing_LowPowerContinuous_get_clock_frequency( ) ) / 1000;
}

uint32_t sxlib_Timing_OneShotTimer_ticks_to_millisec( uint32_t x )
{
    return ( x * 1000 ) >> sxlib_Timing_LowPowerContinuous_get_clock_frequency( );
}
