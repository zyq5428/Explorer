/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_GENERIC_SXLIB_GPIO_OUTPUT_GENERIC_OUTPUT_H_
#define SXLIB_INCLUDE_GENERIC_SXLIB_GPIO_OUTPUT_GENERIC_OUTPUT_H_

#include <stdint.h>

struct sxlib_Gpio_Output_inst;

typedef enum
{
    SXLIB_GPIO_OUTPUT_LOW = 0U,
    SXLIB_GPIO_OUTPUT_HIGH,
} sxlib_Gpio_Output_state;

#ifdef __cplusplus
extern "C" {
#endif
void sxlib_Gpio_Output_set( const struct sxlib_Gpio_Output_inst* inst, sxlib_Gpio_Output_state high );
#ifdef __cplusplus
}
#endif

#endif  // SXLIB_INCLUDE_GENERIC_SXLIB_GPIO_OUTPUT_GENERIC_OUTPUT_H_
