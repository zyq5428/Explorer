/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_GENERIC_SXLIB_TIMING_BUSYWAIT_GENERIC_BUSYWAIT_H_
#define SXLIB_INCLUDE_GENERIC_SXLIB_TIMING_BUSYWAIT_GENERIC_BUSYWAIT_H_

#include <stdint.h>

#define SXLIB_TIMING_MILLISEC_TO_MIBISEC( x ) ( ( ( ( uint32_t ) x ) << 10 ) / 1000 )
#define SXLIB_TIMING_MIBISEC_TO_MILLISEC( x ) ( ( ( ( uint32_t ) x ) * 1000 ) >> 10 )

#ifdef __cplusplus
extern "C" {
#endif
/** The mibiSec time unit is (1.0/1024) seconds, which is slightly
 * shorter than 1ms. For durations known at compile-time, use
 * sxlib_Timing_Busywait_precise_waitMibiSec(x) or
 * sxlib_Timing_Busywait_precise_waitMibiSec(SXLIB_TIMING_MILLISEC_TO_MIBISEC(x)).
 */
void sxlib_Timing_Busywait_precise_waitMibiSec( uint16_t mibiSec );

/** Applications should preferentially use waitMibiSec because
 * it can be optimized for very-low-power applications.
 */
void sxlib_Timing_Busywait_precise_waitMilliSec( uint16_t milliSec );

/** Version of sxlib_Timing_Busywait_precise_waitMibiSec that can sleep */
void sxlib_Timing_Busywait_waitMibiSec( uint16_t mibiSec );

/** Version of sxlib_Timing_Busywait_precise_waitMilliSec that can sleep */
void sxlib_Timing_Busywait_waitMilliSec( uint16_t milliSec );

#ifdef __cplusplus
}
#endif

#endif  // SXLIB_INCLUDE_GENERIC_SXLIB_TIMING_BUSYWAIT_GENERIC_BUSYWAIT_H_
