/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_GENERIC_SXLIB_TIMING_ONESHOTTIMERBASE_GENERIC_ONESHOTTIMERBASE_H_
#define SXLIB_INCLUDE_GENERIC_SXLIB_TIMING_ONESHOTTIMERBASE_GENERIC_ONESHOTTIMERBASE_H_

#define ONE_SHOT_TIMER_BASE_STATUS_OK ( 0 )
#define ONE_SHOT_TIMER_BASE_STATUS_INEXISTENT ( 1 )

#define ONE_SHOT_TIMER_WAIT_FOREVER ( -1 )

struct sxlib_Timing_OneShotTimerBase;

#ifdef __cplusplus
extern "C" {
#endif

void sxlib_Timing_OneShotTimerBase_insert( struct sxlib_Timing_OneShotTimerBase* root,
                                           struct sxlib_Timing_OneShotTimerBase* timer, int ticks );
void sxlib_Timing_OneShotTimerBase_execute_callables( struct sxlib_Timing_OneShotTimerBase* root );
int  sxlib_Timing_OneShotTimerBase_delete( struct sxlib_Timing_OneShotTimerBase* root,
                                           struct sxlib_Timing_OneShotTimerBase* timer );
void sxlib_Timing_OneShotTimerBase_update( struct sxlib_Timing_OneShotTimerBase* root, int ticks );
int  sxlib_Timing_OneShotTimerBase_get_delta( struct sxlib_Timing_OneShotTimerBase* root );

#ifdef __cplusplus
}
#endif

#endif  // SXLIB_INCLUDE_GENERIC_SXLIB_TIMING_ONESHOTTIMERBASE_GENERIC_ONESHOTTIMERBASE_H_
