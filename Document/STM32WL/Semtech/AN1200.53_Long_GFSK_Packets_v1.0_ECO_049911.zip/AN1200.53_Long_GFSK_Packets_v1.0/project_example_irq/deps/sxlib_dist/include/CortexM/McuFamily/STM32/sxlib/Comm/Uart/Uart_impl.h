/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_ARCH_CORTEXM_MCUFAMILY_STM32_SXLIB_COMM_UART_UART_IMPL_H_
#define SXLIB_INCLUDE_ARCH_CORTEXM_MCUFAMILY_STM32_SXLIB_COMM_UART_UART_IMPL_H_

#include <stdint.h>

#include <../CortexM/McuFamily/STM32/sxlib/Comm/Uart/Uart.h>
#include <sxlib/Extern/McuFamily_HAL.h>

// This can be const
struct sxlib_Comm_Uart_init
{
    UART_InitTypeDef HAL_init;
};

struct sxlib_Comm_Uart_config
{
    GPIO_TypeDef* tx_port;
    GPIO_TypeDef* rx_port;

    uint8_t tx_alternate;
    uint8_t rx_alternate;

    uint8_t tx_pin;
    uint8_t rx_pin;
};

struct sxlib_Comm_Uart_inst
{
    // handle MUST be the first element of this struct so that HAL_UART_MspInit() can find the config.
    UART_HandleTypeDef HAL_handle;

    const struct sxlib_Comm_Uart_config* config;
};

#endif  // SXLIB_INCLUDE_ARCH_CORTEXM_MCUFAMILY_STM32_SXLIB_COMM_UART_UART_IMPL_H_
