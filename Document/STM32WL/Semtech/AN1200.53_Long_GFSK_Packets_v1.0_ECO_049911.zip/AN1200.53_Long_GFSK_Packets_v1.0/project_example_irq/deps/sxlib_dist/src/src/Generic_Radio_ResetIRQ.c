/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <sxlib/Radio/ResetIRQ/Generic_ResetIRQ_impl.h>
#include <sxlib/Debug/Assert/Assert.h>
#include <sxlib/Timing/Busywait/Generic_Busywait.h>

void sxlib_Radio_ResetIRQ_reset( const struct sxlib_Radio_ResetIRQ_inst* inst )
{
    if( inst->radio_reset_output )
    {
        sxlib_Gpio_Output_set( inst->radio_reset_output, SXLIB_GPIO_OUTPUT_LOW );
        sxlib_Timing_Busywait_waitMibiSec( SXLIB_TIMING_MILLISEC_TO_MIBISEC( 1 ) );
        sxlib_System_IRQLine_clear( inst->radio_IRQ_inst );
        sxlib_Gpio_Output_set( inst->radio_reset_output, SXLIB_GPIO_OUTPUT_HIGH );
        // All radio operations wait for the not-busy event.
        // Do not wait on it here, because that will clear it.
        // sxlib_System_IRQLine_wait_on_event(inst->radio_IRQ_inst);
    }
}
