/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <sxlib/System/SleepInhibition/Generic_SleepInhibition.h>
#include <sxlib/Extern/HAL.h>

static uint32_t sxlib_System_SleepInhibition_masks[SXLIB_SYSTEM_SLEEPINHIBITION_SENTINEL];

void sxlib_System_SleepInhibition_init( )
{
    uint32_t primask = __get_PRIMASK( );
    __disable_irq( );

    for( int i = 0; i < SXLIB_SYSTEM_SLEEPINHIBITION_SENTINEL; ++i )
    {
        sxlib_System_SleepInhibition_masks[i] = 0;
    }

    if( primask == 0U )
    {
        __enable_irq( );
    }
}

uint32_t sxlib_System_SleepInhibition_get_mask( enum sxlib_System_SleepInhibition_class class )
{
    // Interrupts will be disabled when this is called, and when it returns
    return sxlib_System_SleepInhibition_masks[class];
}

void sxlib_System_SleepInhibition_inhibit_sleep( enum sxlib_System_SleepInhibition_class class, uint32_t mask )
{
    uint32_t primask = __get_PRIMASK( );
    __disable_irq( );

    sxlib_System_SleepInhibition_masks[class] |= mask;

    if( primask == 0U )
    {
        __enable_irq( );
    }
}

void sxlib_System_SleepInhibition_allow_sleep( enum sxlib_System_SleepInhibition_class class, uint32_t mask )
{
    uint32_t primask = __get_PRIMASK( );
    __disable_irq( );

    sxlib_System_SleepInhibition_masks[class] &= ~mask;

    if( primask == 0U )
    {
        __enable_irq( );
    }
}
