/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <string.h>
#include <sxlib/Data/Ringbuf/Generic_Ringbuf.h>

void sxlib_data_ringbuf_init( struct sxlib_data_ringbuf_s* rb, uint8_t* buf, unsigned int bufblocks,
                              unsigned int blocksize )
{
    rb->data  = buf;
    rb->begin = rb->end = 0;
    rb->mask            = ( uint16_t )( bufblocks - 1 );
    rb->blocksize       = blocksize;
}

// May need to be called twice. Returns number of bytes really added.
unsigned int sxlib_data_ringbuf_add_segment( struct sxlib_data_ringbuf_s* rb, const uint8_t* src,
                                             unsigned int num_blocks )
{
    unsigned int tail_capacity = ( unsigned int ) rb->mask + 1 - rb->end;
    int          count         = ( rb->end - rb->begin ) & rb->mask;

    if( num_blocks > tail_capacity ) num_blocks = tail_capacity;

    memcpy( &rb->data[rb->end * rb->blocksize], src, num_blocks * rb->blocksize );
    rb->end = ( rb->end + num_blocks ) & rb->mask;

    // Manage overflow
    if( ( ( unsigned int ) count ) + num_blocks > rb->mask )
    {
        rb->begin = ( rb->end + 1 ) & rb->mask;
    }

    return num_blocks;
}

void sxlib_data_ringbuf_add( struct sxlib_data_ringbuf_s* rb, const uint8_t* src, unsigned int num_blocks )
{
    unsigned int   n   = 0;
    const uint8_t* buf = src;

    while( n < num_blocks )
    {
        unsigned int count = sxlib_data_ringbuf_add_segment( rb, buf, num_blocks - n );
        buf += count * rb->blocksize;
        n += count;
    }
}

unsigned int sxlib_data_ringbuf_remove_segment( struct sxlib_data_ringbuf_s* rb, uint8_t* dest,
                                                unsigned int max_blocks )
{
    int n = ( int ) rb->end - rb->begin;

    if( n == 0 )
    {
        return 0;
    }

    if( n < 0 )
    {
        n = rb->mask + 1 - rb->begin;
    }

    if( n > max_blocks )
    {
        n = max_blocks;
    }

    memcpy( dest, &rb->data[rb->begin * rb->blocksize], n * rb->blocksize );
    rb->begin = ( rb->begin + n ) & rb->mask;

    // Number of blocks removed
    return n;
}

unsigned int sxlib_data_ringbuf_remove( struct sxlib_data_ringbuf_s* rb, uint8_t* dest, unsigned int max_blocks )
{
    unsigned int count;
    unsigned int n   = 0;
    uint8_t*     buf = dest;

    do
    {
        count = sxlib_data_ringbuf_remove_segment( rb, buf, max_blocks - n );
        buf += count * rb->blocksize;
        n += count;
    } while( n < max_blocks && count != 0 );

    // Number of blocks removed
    return n;
}
