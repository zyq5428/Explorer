/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <sxlib/Radio/SpiRadio/Generic_SpiRadio_impl.h>
#include <sxlib/Radio/Sx126x/Generic_Sx126x_impl.h>

#include <Module/RadioIRQLineGpio0/sxlib/System/IRQLine/IRQLine.h>
#include <Module/RadioIRQLineGpio0/sxlib/Gpio/Output/Output.h>
#include <Module/SpiDeviceRadio0/sxlib/Comm/Spi/Spi.h>
#include <Module/LeanSx126xRadio0/sxlib/Radio/Sx126x/Sx126x.h>

const struct sxlib_Radio_Sx126x_inst
    sxlib_Module_Radio0_Radio = { .spi_radio = {
                                      .spi       = &sxlib_Module_SpiDeviceRadio0_Comm_Spi_device,
                                      .reset_irq = {
                                          .radio_IRQ_inst     = &sxlib_Module_RadioIRQLineGpio0_System_IRQLine_busy,
                                          .radio_reset_output = &sxlib_Module_RadioIRQLineGpio0_Gpio_Output_NRESET,
                                      } } };
