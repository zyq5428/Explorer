/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */

#include <sxlib/Timing/OneShotTimerBase/Generic_OneShotTimerBase_impl.h>
#include <sxlib/Debug/Assert/Assert.h>

void sxlib_Timing_OneShotTimerBase_insert( struct sxlib_Timing_OneShotTimerBase* root,
                                           struct sxlib_Timing_OneShotTimerBase* timer, int ticks )
{
    struct sxlib_Timing_OneShotTimerBase* i = root;

    if( root->next )
    {
        int cumulated_time = i->delta;
        sxlib_assert( i->next != timer );

        while( i->next && ( cumulated_time <= ticks ) )
        {
            i = i->next;
            cumulated_time += i->delta;
        }

        timer->next  = i->next;
        timer->delta = cumulated_time - ticks;

        i->next = timer;
        i->delta -= timer->delta;
    }
    else
    {
        timer->next  = 0;
        timer->delta = -ticks;
        root->next   = timer;
        root->delta  = ticks;
    }
}

void sxlib_Timing_OneShotTimerBase_execute_callables( struct sxlib_Timing_OneShotTimerBase* root )
{
    while( root->next && !root->delta )
    {
        struct sxlib_Timing_OneShotTimerBase_callable* callable = &root->next->callable;

        // First remove this timer entry so that the callable can safely
        // manipulate the timers, for instance, to insert itself again.
        root->delta = root->next->delta;
        root->next  = root->next->next;

        callable->callback( callable->arg );
    }

    if( !root->next )
    {
        root->delta = 0;
    }
}

int sxlib_Timing_OneShotTimerBase_delete( struct sxlib_Timing_OneShotTimerBase* root,
                                          struct sxlib_Timing_OneShotTimerBase* timer )
{
    struct sxlib_Timing_OneShotTimerBase* i = root;

    while( i->next != timer )
    {
        if( !i->next ) return ( ONE_SHOT_TIMER_BASE_STATUS_INEXISTENT );
        i = i->next;
    }

    i->delta += timer->delta;
    i->next = timer->next;

    if( !root->next )
    {
        root->delta = 0;
    }
    return ( ONE_SHOT_TIMER_BASE_STATUS_OK );
}

void sxlib_Timing_OneShotTimerBase_update( struct sxlib_Timing_OneShotTimerBase* root, int ticks )
{
    struct sxlib_Timing_OneShotTimerBase* i = root;

    while( i->next && ( ticks > 0 ) )
    {
        // If your code hangs here, you have inserted the same timer twice.
        if( ticks <= i->delta )
        {
            i->delta -= ticks;
            return;
        }
        else
        {
            ticks -= i->delta;
            i->delta = 0;
            i        = i->next;
        }
    }
}

int sxlib_Timing_OneShotTimerBase_get_delta( struct sxlib_Timing_OneShotTimerBase* root )
{
    // TODO: Make this iterate until non-zero.
    if( root->next )
    {
        return root->delta;
    }
    else
    {
        return ONE_SHOT_TIMER_WAIT_FOREVER;
    }
}
