/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_MODULE_RALSXRADIO0_SXLIB_SYSTEM_IRQLINE_GENERIC_IRQLINE_H_
#define SXLIB_INCLUDE_MODULE_RALSXRADIO0_SXLIB_SYSTEM_IRQLINE_GENERIC_IRQLINE_H_

#include <sxlib/System/IRQLine/McuFamily_IRQLine.h>
#include <sxlib/System/EventsBase/Generic_EventsBase.h>

extern const struct sxlib_System_IRQLine_config sxlib_Module_RadioIRQLineGpio0_System_IRQLine_config_busy;
extern const struct sxlib_System_IRQLine_config sxlib_Module_RadioIRQLineGpio0_System_IRQLine_config_irq;
extern struct sxlib_System_IRQLine_inst         sxlib_Module_RadioIRQLineGpio0_System_IRQLine_busy;
extern struct sxlib_System_IRQLine_inst         sxlib_Module_RadioIRQLineGpio0_System_IRQLine_irq;

static inline void sxlib_Module_RadioIRQLineGpio0_System_IRQLine_init_all( sxlib_System_Events_id_t flags )
{
    sxlib_System_IRQLine_init( &sxlib_Module_RadioIRQLineGpio0_System_IRQLine_busy,
                               &sxlib_Module_RadioIRQLineGpio0_System_IRQLine_config_busy, flags );
    sxlib_System_IRQLine_init( &sxlib_Module_RadioIRQLineGpio0_System_IRQLine_irq,
                               &sxlib_Module_RadioIRQLineGpio0_System_IRQLine_config_irq, flags );
}

#endif  // SXLIB_INCLUDE_MODULE_RALSXRADIO0_SXLIB_SYSTEM_IRQLINE_GENERIC_IRQLINE_H_
