/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <sxlib/Gpio/Output/McuFamily_Output_impl.h>
#include <sxlib/Extern/McuFamily_HAL.h>
#include <sxlib/Extern/Stm32lLl.h>

void sxlib_Gpio_Output_init( const struct sxlib_Gpio_Output_inst* inst, sxlib_Gpio_Output_state high )
{
    GPIO_InitTypeDef init = {
        .Pin   = ( 1 << inst->pin ),
        .Mode  = GPIO_MODE_OUTPUT_PP,
        .Pull  = GPIO_NOPULL,
        .Speed = GPIO_SPEED_FREQ_MEDIUM,
    };
    sxlib_Gpio_Output_set( inst, high );
    HAL_GPIO_Init( inst->port, &init );
}

void sxlib_Gpio_Output_set( const struct sxlib_Gpio_Output_inst* inst, sxlib_Gpio_Output_state high )
{
    HAL_GPIO_WritePin( inst->port, ( 1 << inst->pin ), ( GPIO_PinState ) high );
}
