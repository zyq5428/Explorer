/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <sxlib/System/IRQLine/McuFamily_IRQLine_impl.h>
#include <sxlib/System/EventsBase/Rtos_EventsBase.h>

void sxlib_System_IRQLine_init( struct sxlib_System_IRQLine_inst*         inst,
                                const struct sxlib_System_IRQLine_config* config, sxlib_System_Events_id_t flags )
{
    GPIO_InitTypeDef GPIO_InitStructure;
    inst->base.config = &config->base;

    GPIO_InitStructure.Mode  = config->mode;
    GPIO_InitStructure.Pull  = config->pull;
    GPIO_InitStructure.Pin   = ( 1 << config->pin );
    GPIO_InitStructure.Speed = config->speed;
    HAL_GPIO_Init( config->port, &GPIO_InitStructure );

    sxlib_System_EventsBase_init( &inst->base, flags );
    sxlib_System_IRQLine_clear( inst );

    HAL_NVIC_EnableIRQ( config->IRQn );
}

unsigned int sxlib_System_IRQLine_read_gpio_state( struct sxlib_System_IRQLine_inst* inst )
{
    const struct sxlib_System_IRQLine_config* config = ( const struct sxlib_System_IRQLine_config* ) inst->base.config;

    return HAL_GPIO_ReadPin( config->port, ( 1 << config->pin ) ) != 0;
}

void sxlib_System_IRQLine_set( struct sxlib_System_IRQLine_inst* inst )
{
    sxlib_System_EventsBase_event_set( &inst->base );
}

void sxlib_System_IRQLine_wait_on_event( struct sxlib_System_IRQLine_inst* inst )
{
    sxlib_System_EventsBase_wait_on_event( &inst->base );
}

void sxlib_System_IRQLine_clear( struct sxlib_System_IRQLine_inst* inst )
{
    NVIC_ClearPendingIRQ( ( ( struct sxlib_System_IRQLine_config* ) inst->base.config )->IRQn );
    sxlib_System_EventsBase_event_clear( &inst->base );
}

int sxlib_System_IRQLine_match_pin( struct sxlib_System_IRQLine_inst* inst, uint32_t pin_mask )
{
    return ( pin_mask == ( 1 << ( ( struct sxlib_System_IRQLine_config* ) inst->base.config )->pin ) );
}

struct sxlib_System_EventsBase_state* sxlib_System_IRQLine_getEventsBase( struct sxlib_System_IRQLine_inst* inst )
{
    return ( &inst->base );
}

int sxlib_System_IRQLine_set_on_pin_match( struct sxlib_System_IRQLine_inst* inst, uint32_t pin_mask )
{
    int retval = sxlib_System_IRQLine_match_pin( inst, pin_mask );
    if( retval )
    {
        sxlib_System_IRQLine_set( inst );
    }
    return retval;
}
