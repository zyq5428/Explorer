/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#include <Module/Nucleo64a/sxlib/Gpio/Led/Led.h>
#include <sxlib/Gpio/Led/Led_impl.h>

const struct sxlib_Gpio_Led_dev sxlib_Module_Nucleo64a_Gpio_Led_led0 = {
    .port  = GPIOC,
    .pin   = 10,
    .flags = 0,
};

const struct sxlib_Gpio_Led_dev sxlib_Module_Nucleo64a_Gpio_Led_led1 = {
    .port  = GPIOC,
    .pin   = 12,
    .flags = 0,
};
