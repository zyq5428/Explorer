/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_ARCH_CORTEXM4_MCUFAMILY_STM32L4XX_SXLIB_GPIO_LED_MCUFAMILY_LED_IMPL_H_
#define SXLIB_INCLUDE_ARCH_CORTEXM4_MCUFAMILY_STM32L4XX_SXLIB_GPIO_LED_MCUFAMILY_LED_IMPL_H_

#include <../CortexM/McuFamily/STM32/sxlib/Gpio/Led/Led_impl.h>

#endif  // SXLIB_INCLUDE_ARCH_CORTEXM4_MCUFAMILY_STM32L4XX_SXLIB_GPIO_LED_MCUFAMILY_LED_IMPL_H_
