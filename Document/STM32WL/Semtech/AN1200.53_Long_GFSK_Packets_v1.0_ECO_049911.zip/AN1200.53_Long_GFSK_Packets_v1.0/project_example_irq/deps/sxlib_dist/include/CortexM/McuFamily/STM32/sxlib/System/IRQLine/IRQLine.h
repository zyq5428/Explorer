/*!
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2019-2019 Semtech
 *
 * \endcode
 *
 * \authors    Semtech WSP Applications Team
 */
#ifndef SXLIB_INCLUDE_ARCH_CORTEXM_MCUFAMILY_STM32_SXLIB_SYSTEM_IRQLINE_IRQLINE_H_
#define SXLIB_INCLUDE_ARCH_CORTEXM_MCUFAMILY_STM32_SXLIB_SYSTEM_IRQLINE_IRQLINE_H_

#include <stdint.h>

#include <sxlib/System/IRQLine/Generic_IRQLine.h>
#include <sxlib/System/EventsBase/Generic_EventsBase.h>

struct sxlib_System_IRQLine_config;

#ifdef __cplusplus
extern "C" {
#endif
void sxlib_System_IRQLine_init( struct sxlib_System_IRQLine_inst*         inst,
                                const struct sxlib_System_IRQLine_config* config, sxlib_System_Events_id_t flags );
int  sxlib_System_IRQLine_match_pin( struct sxlib_System_IRQLine_inst* inst, uint32_t pin_mask );
int  sxlib_System_IRQLine_set_on_pin_match( struct sxlib_System_IRQLine_inst* inst, uint32_t pin_mask );
#ifdef __cplusplus
}
#endif

#endif  // SXLIB_INCLUDE_ARCH_CORTEXM_MCUFAMILY_STM32_SXLIB_SYSTEM_IRQLINE_IRQLINE_H_
